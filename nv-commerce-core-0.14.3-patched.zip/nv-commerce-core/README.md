# NV Commerce Core (v0.11.9)

WooCommerce plugin for Nordiska Varuhuset:

- Cart-wide bulk discount tiers (2/3/4+ quantity)
- Kaching-style bundle deal cards (Single/Duo/Trio layout)
- Mix & match variation selectors per deal slot (#1, #2, #3)
- One-click add selected bundle deal to cart
- Most-popular badge + labels + subtitle tokens (`{pct}`)
- Hybrid bonus thumbnail previews inside deal cards:
  - Tier 1: single enlarged thumbnail + inline title
  - Tier 2: 3 enlarged thumbnails + right-aligned details link
  - Tier 3: 5 enlarged thumbnails + right-aligned details link
  - Titles shown in expanded details panel for tier 2/3
- Product-level JSON override for custom deal bars
- Product meta fields used by NV Store Theme PDP template (`v0.9.0+`)
- Migrated Smart Upsell module (checkout + sidecart carousel)
- Nordic Pricing module with manual NO/DK/FI product and variation prices
- Country detection controls (geolocation, billing, shipping) and optional storefront switcher
- Theme-aware bundle mount integration for `nv_theme_bundle_widget`
- Sidecart selector compatibility for `#nvSideCart` and `.nv-side-cart-body`
- Migrated sidecart AJAX endpoints:
  - `wc_ajax=nv_get_cart_contents`
  - `wc_ajax=update_cart_item`
- Sidecart admin-ajax fallbacks:
  - `action=nvcc_get_cart_contents`
  - `action=nvcc_update_cart_item`
- Legacy Smart Upsell AJAX endpoints:
  - `action=nv_smart_upsell_data`
  - `action=nv_smart_upsell_add`

## Includes

- `nv-commerce-core.php`
- `assets/css/nv-commerce-core.css`
- `assets/js/nv-commerce-core.js`
- `assets/css/nv-smart-upsell.css`
- `assets/js/nv-smart-upsell.js`
- `includes/class-nvcc-smart-upsell-module.php`
- `includes/class-nvcc-nordic-pricing-module.php`

## Admin Settings

WooCommerce -> NV Commerce Core

- Enable/disable bulk discount
- Discount label
- Tier quantity + percent values
- Enable/disable variation bundle widget
- Bundle subtitle and CTA text
- Widget variant style A/B/C
- Popular and default deal index
- 3 deal bars (qty, title, subtitle, badge, label)
- Bonus preview controls:
  - enable/disable thumbnail previews
  - style: auto / strip / grid
  - thumbnail image size
  - details CTA text

Settings -> NV Smart Upsell

- Enable/disable upsell in checkout
- Enable/disable upsell in sidecart
- Optional legacy item-level bulk engine (for sidecart line discounts)
- Product pools, badges, category filter and dynamic tier headlines

## Product-Level Meta Box

On each product edit page:

- Bulk mode: inherit / enable / disable
- Bundle mode: inherit / enable / disable
- Optional override percentages for tier levels
- Optional bundle deals JSON override
- Per-deal bonus fields:
  - Bonus text
  - Bonus selectors (`id:`, `slug:`, `sku:`)
- PDP content helpers:
  - Benefits list
  - Trust badges list
  - FAQ list (`Question::Answer` per row)
  - Story blocks JSON

## Installation

1. Zip plugin folder as `nv-commerce-core-v0.9.6-bundle-render-fallback-atc-guard.zip`.
2. Upload in WordPress: Plugins -> Add New -> Upload Plugin.
3. Deactivate older `NV Commerce Core` versions first (if installed as separate versioned folders).
4. Activate plugin.
5. Deactivate `NV Smart Upsell Carousel` (old standalone plugin).
6. Keep `NV Commerce Core` active and configure:
   - WooCommerce -> NV Commerce Core
   - Settings -> NV Smart Upsell
7. Open sidecart + checkout and verify upsell + cart update flows.

## v0.9.6 Notes

- Added a fail-safe fallback for product purchase flow:
  - Default WooCommerce Add to Cart is now hidden only after the bundle widget has successfully rendered.
  - If bundle rendering fails or the shortcode/widget mount is missing, default Add to Cart remains visible so checkout is still possible.
- Preserved approved bundle layout and behavior when bundle rendering succeeds.

## v0.9.2 Notes

- Added a safe runtime collision guard: if `Nestly_NVCC_Commerce_Core_Runtime` is already loaded (for example by an older active copy), the second-loaded copy now exits early instead of crashing activation.
- Prevents `Cannot redeclare class Nestly_NVCC_Commerce_Core_Runtime` activation fatals when multiple NV Commerce Core copies are present.

## v0.9.5 Notes

- Added shortcode registration fallback bridge at `init` priority 5 so `[nvcc_variation_bundle]` and `[nvcc_bundle_widget]` still resolve when runtime collisions prevent normal shortcode registration.
- Added runtime-instance discovery helper that can bind shortcode rendering to an already-loaded `Nestly_NVCC_Commerce_Core_Runtime` instance.
- Prevents raw shortcode token leakage in Elementor text-editor contexts when duplicate-class environments are present.

## v0.9.1 Notes

- Updated bonus preview layout for cleaner bundle cards:
  - Tier 1 now hides the details toggle and shows one larger thumbnail with its title inline.
  - Tier 2 now keeps thumbnails compact and moves `+ Visa alla ...` to the right side of the preview row.
  - Tier 3 now shows only 5 thumbnails in collapsed state and moves `+ Visa alla ...` to the right side of the preview row.
- Tier 2 and Tier 3 bonus titles now appear only inside the expandable accordion panel (not in collapsed preview).
- Increased bonus thumbnail size and reduced thumbnail corner radius for a cleaner premium look.

## v0.9.0 Notes

- Added centralized **Offer Campaigns** manager in plugin settings:
  - product selectors (`id:`, `slug:`, `sku:`)
  - category selectors (`id:` or slug)
  - campaign priority and any/all match mode
  - reusable 3-tier deal setup per campaign
  - one-click campaign duplication in admin UI
- Campaign-level deal config now overrides global/legacy product-level deals for matched products.
- Added optional campaign-specific bundle headline text.
- Product-level deal controls are now explicitly marked **legacy/optional** with per-product toggle (`auto/yes/no`).
- Added timer and BOGO setting sanitization guards in settings save flow.

## v0.9.3 Notes

- Fixed duplicate bonus thumbnails in expanded bundle cards:
  - Tier 2 now hides the `Visa alla...` toggle when there is nothing more to reveal.
  - Expanded bonus state now suppresses the compact strip so thumbnails are not shown twice.
- Preserved compact approved mobile/desktop layout while keeping the existing expansion UX.

## v0.8.10 Notes

- Added class-based visibility guard for bonus detail panels:
  - Panels now default to hidden via CSS unless explicitly opened with `.is-open`.
  - JS now toggles both `hidden` and `.is-open` to prevent accidental panel visibility drift.
- Keeps compact approved layout while blocking duplicate preview+panel rendering in collapsed state.

## v0.8.6 Notes

- Added optional per-offer bonus headline behavior:
  - Leave bonus headline empty to hide it and use the space for thumbnails.
  - Add a custom headline when needed on any offer.
- Added per-offer custom short titles for bonus items (`Bonus korta titlar`) so long product names can be replaced by compact visible labels.
- Updated default "show all" CTA to compact link text with count token support (`+ Visa alla {count} böcker ▼`).
- Enlarged bonus thumbnails and variation thumbnails for better visual balance in compact cards.
- Updated thumbnail corner radius in the bonus/variation section for a softer, cleaner look.

## v0.8.8 Notes

- Fixed duplicate bonus thumbnail rendering where collapsed bonus cards could show both preview and expanded panel at the same time.
- Added explicit hidden-state guard for bonus detail panels in CSS and JS to avoid conflicts with global `[hidden]` overrides.

## v0.8.9 Notes

- Hardened bonus panel initialization so all detail panels are force-collapsed on first render, even if third-party scripts remove the native `hidden` attribute before NV Commerce Core binds events.
- Reset bonus toggle state (`aria-expanded` and close-label text) on init to keep collapsed/expanded UI parity consistent across desktop and mobile.

## v0.8.7 Notes

- Added Nordic Pricing runtime for country-specific manual pricing in NO, DK, and FI.
- Added product meta box fields for simple products and per-variation Nordic prices.
- Added Nordic Pricing admin submenu under Commerce Core settings.
- Added currency/symbol/price decimal switching tied to active Nordic country.
- Added optional manual country/currency switcher with session+cookie persistence.

## v0.8.5 Notes

- Added hybrid bonus thumbnail renderer (A for lower tiers, C for premium tier).
- Added `Se innehåll` details toggle for bonus visibility without expanding default mobile height.
- Added per-product deal-level bonus selector fields in the product meta box.
- Added fallback bridge to read selectors from NV Order Bonuses when per-product selectors are empty.
- Preserved compact mobile layout, centered deal badges, and variation thumbnail sync behavior.

## Notes

- Bulk discount is applied as a negative WooCommerce fee.
- Per-product percentage overrides are applied automatically when only one eligible parent product group is in cart.
- For mixed carts, global tier percentages are used.
- If legacy Smart Upsell bulk is enabled, Commerce Core fee-bulk is automatically skipped to avoid double-discount.
