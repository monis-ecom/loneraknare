<?php
/**
 * NV Commerce Core - Smart Upsell compatibility module.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Nestly_NVCC_Smart_Upsell_Runtime')) {
    final class Nestly_NVCC_Smart_Upsell_Runtime {
        private const OPTION_KEY = 'nv_smart_upsell_settings';
        private const NONCE_ACTION = 'nv_smart_upsell_nonce';
        private const VERSION = NVCC_VERSION;
        private const MENU_SLUG = 'nestly-smart-upsell-settings';
        private const CORE_MENU_SLUG = 'nestly-commerce-core-settings';
        private bool $checkout_mount_rendered = false;

        public static function init(): void {
            $instance = new self();
            $instance->hooks();
        }

        private function hooks(): void {
            add_action('admin_menu', [$this, 'add_admin_menu']);
            add_action('admin_init', [$this, 'register_settings']);

            add_action('init', [$this, 'register_shortcodes'], 20);
            add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
            add_action('wp_head', [$this, 'maybe_hide_merchant_upsell'], 120);
            add_action('woocommerce_review_order_after_order_total', [$this, 'render_checkout_mount'], 25);
            add_filter('nvcc_use_fee_bulk_discount', [$this, 'filter_use_fee_bulk_discount'], 10, 1);
            add_action('woocommerce_before_calculate_totals', [$this, 'apply_bulk_discounts'], 20);
            add_filter('woocommerce_get_item_data', [$this, 'append_bulk_discount_item_data'], 20, 2);
            add_action('woocommerce_checkout_create_order_line_item', [$this, 'add_bulk_discount_order_item_meta'], 20, 4);

            add_action('wp_ajax_nv_smart_upsell_data', [$this, 'ajax_get_data']);
            add_action('wp_ajax_nopriv_nv_smart_upsell_data', [$this, 'ajax_get_data']);

            add_action('wp_ajax_nv_smart_upsell_add', [$this, 'ajax_add_to_cart']);
            add_action('wp_ajax_nopriv_nv_smart_upsell_add', [$this, 'ajax_add_to_cart']);

            add_action('wc_ajax_nv_get_cart_contents', [$this, 'wc_ajax_get_cart_contents']);
            add_action('wc_ajax_nopriv_nv_get_cart_contents', [$this, 'wc_ajax_get_cart_contents']);
            add_action('wc_ajax_update_cart_item', [$this, 'wc_ajax_update_cart_item']);
            add_action('wc_ajax_nopriv_update_cart_item', [$this, 'wc_ajax_update_cart_item']);

            add_action('wp_ajax_nvcc_get_cart_contents', [$this, 'wc_ajax_get_cart_contents']);
            add_action('wp_ajax_nopriv_nvcc_get_cart_contents', [$this, 'wc_ajax_get_cart_contents']);
            add_action('wp_ajax_nvcc_update_cart_item', [$this, 'wc_ajax_update_cart_item']);
            add_action('wp_ajax_nopriv_nvcc_update_cart_item', [$this, 'wc_ajax_update_cart_item']);
        }

        public function enqueue_assets(): void {
            if (is_admin() || !$this->woocommerce_ready()) {
                return;
            }

            $settings = $this->get_settings();

            wp_enqueue_style(
                'nv-smart-upsell-core',
                NVCC_PLUGIN_URL . 'assets/css/nv-smart-upsell.css',
                [],
                self::VERSION
            );

            wp_enqueue_script(
                'nv-smart-upsell-core',
                NVCC_PLUGIN_URL . 'assets/js/nv-smart-upsell.js',
                ['jquery'],
                self::VERSION,
                true
            );

            wp_localize_script('nv-smart-upsell-core', 'NVSmartUpsell', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce(self::NONCE_ACTION),
                'enabledCheckout' => $settings['enabled_checkout'],
                'enabledSidecart' => $settings['enabled_sidecart'],
                'maxProducts' => (int) $settings['max_products'],
                'endpoints' => [
                    'cartContents' => admin_url('admin-ajax.php?action=nvcc_get_cart_contents'),
                    'updateCartItem' => admin_url('admin-ajax.php?action=nvcc_update_cart_item'),
                ],
                'strings' => [
                    'add' => __('Lägg till', 'nv-commerce-core'),
                    'adding' => __('Lägger till...', 'nv-commerce-core'),
                    'added' => __('Tillagd', 'nv-commerce-core'),
                    'error' => __('Fel - försök igen', 'nv-commerce-core'),
                    'empty' => __('Inga rekommendationer just nu.', 'nv-commerce-core'),
                    'badgePopular' => __('Populär', 'nv-commerce-core'),
                    'badgeNew' => __('Ny', 'nv-commerce-core'),
                    'prev' => __('Föregående', 'nv-commerce-core'),
                    'next' => __('Nästa', 'nv-commerce-core'),
                    'selectVariation' => __('Välj variant', 'nv-commerce-core'),
                ],
            ]);
        }

        public function register_shortcodes(): void {
            $shortcodes = [
                'nv_smart_upsell',
                'nv_smart_upsell_checkout',
                'nvcc_smart_upsell',
            ];

            foreach ($shortcodes as $shortcode) {
                if (!shortcode_exists($shortcode)) {
                    add_shortcode($shortcode, [$this, 'shortcode_mount']);
                }
            }
        }

        public function filter_use_fee_bulk_discount(bool $enabled): bool {
            if ($this->is_legacy_bulk_enabled()) {
                return false;
            }
            return $enabled;
        }

        public function maybe_hide_merchant_upsell(): void {
            if (!$this->woocommerce_ready() || !is_checkout()) {
                return;
            }

            $settings = $this->get_settings();
            if ($settings['hide_merchant_upsell'] !== 'yes') {
                return;
            }
            ?>
            <style id="nv-smart-upsell-hide-merchant">
                .merchant-order-offer-container {
                    display: none !important;
                }
            </style>
            <?php
        }

        public function render_checkout_mount(): void {
            echo $this->get_checkout_mount_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        private function get_checkout_mount_markup(): string {
            if (!$this->woocommerce_ready()) {
                return '';
            }

            $settings = $this->get_settings();
            if ($settings['enabled_checkout'] !== 'yes') {
                return '';
            }

            if ($this->checkout_mount_rendered) {
                return '';
            }

            $this->checkout_mount_rendered = true;
            return '<div id="nv-smart-upsell-checkout" class="nv-smart-upsell nv-smart-upsell--checkout" data-context="checkout"></div>';
        }

        public function shortcode_mount($atts = []): string {
            $atts = shortcode_atts(
                [
                    'context' => 'checkout',
                ],
                is_array($atts) ? $atts : [],
                'nv_smart_upsell'
            );

            $context = sanitize_key((string) ($atts['context'] ?? 'checkout'));
            if ($context === 'sidecart') {
                $settings = $this->get_settings();
                if ($settings['enabled_sidecart'] !== 'yes') {
                    return '';
                }

                return '<div id="nv-smart-upsell-sidecart" class="nv-smart-upsell nv-smart-upsell--sidecart" data-context="sidecart"></div>';
            }

            return $this->get_checkout_mount_markup();
        }

        public function ajax_get_data(): void {
            check_ajax_referer(self::NONCE_ACTION, 'nonce');

            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                wp_send_json_error(['message' => 'WooCommerce unavailable'], 400);
            }

            $payload = $this->build_payload();
            wp_send_json_success($payload);
        }

        public function ajax_add_to_cart(): void {
            check_ajax_referer(self::NONCE_ACTION, 'nonce');

            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                wp_send_json_error(['message' => 'WooCommerce unavailable'], 400);
            }

            $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
            $variation_id = isset($_POST['variation_id']) ? absint(wp_unslash($_POST['variation_id'])) : 0;
            $quantity = isset($_POST['quantity']) ? max(1, absint(wp_unslash($_POST['quantity']))) : 1;

            if ($product_id <= 0) {
                wp_send_json_error(['message' => __('Ogiltig produkt.', 'nv-commerce-core')], 400);
            }

            $variation = [];
            if ($variation_id > 0) {
                $variation_product = wc_get_product($variation_id);
                if ($variation_product && $variation_product->is_type('variation')) {
                    $variation = $variation_product->get_variation_attributes();
                }
            }

            $added_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation);

            if (!$added_key) {
                wp_send_json_error(['message' => __('Kunde inte lägga till produkten.', 'nv-commerce-core')], 400);
            }

            WC()->cart->calculate_totals();

            $payload = $this->build_payload();
            wp_send_json_success($payload);
        }

        public function wc_ajax_get_cart_contents(): void {
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                wp_send_json_error(['message' => 'WooCommerce unavailable'], 400);
            }

            WC()->cart->calculate_totals();
            wp_send_json_success($this->build_side_cart_payload());
        }

        public function wc_ajax_update_cart_item(): void {
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                wp_send_json_error(['message' => 'WooCommerce unavailable'], 400);
            }

            $cart_item_key = isset($_POST['cart_item_key']) ? wc_clean(wp_unslash($_POST['cart_item_key'])) : '';
            $quantity = isset($_POST['quantity']) ? absint(wp_unslash($_POST['quantity'])) : 0;

            if ($cart_item_key === '') {
                wp_send_json_error(['message' => __('Ogiltig varukorgsrad.', 'nv-commerce-core')], 400);
            }

            $cart_contents = WC()->cart->get_cart();
            if (!isset($cart_contents[$cart_item_key])) {
                wp_send_json_error(['message' => __('Produkten hittades inte i varukorgen.', 'nv-commerce-core')], 404);
            }

            if ($quantity <= 0) {
                WC()->cart->remove_cart_item($cart_item_key);
            } else {
                WC()->cart->set_quantity($cart_item_key, $quantity, true);
            }

            WC()->cart->calculate_totals();
            wp_send_json_success($this->build_side_cart_payload());
        }

        public function apply_bulk_discounts($cart): void {
            if (!$cart instanceof WC_Cart) {
                return;
            }

            if (!$this->is_legacy_bulk_enabled()) {
                return;
            }

            if (is_admin() && !wp_doing_ajax()) {
                return;
            }

            $settings = $this->get_settings();
            $enabled = ($settings['bulk_discount_enabled'] ?? 'yes') === 'yes';
            $active_percent = $enabled ? $this->get_active_bulk_discount_percent((int) $this->get_cart_quantity_from_object($cart)) : 0;

            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                if (empty($cart_item['data']) || !($cart_item['data'] instanceof WC_Product)) {
                    continue;
                }

                // NV Product Widgets bundle lines + free gifts price themselves — leave
                // them alone so the two discount engines don't fight.
                if (!empty($cart_item['_nv_pw_fixed_unit']) || !empty($cart_item['nv_pw_gift'])) {
                    continue;
                }

                $base_unit_price = $this->get_base_unit_price_for_cart_item($cart_item);
                if ($base_unit_price <= 0) {
                    continue;
                }

                $qty = max(1, (int) ($cart_item['quantity'] ?? 1));

                if ($active_percent > 0) {
                    $discounted_unit_price = $base_unit_price * ((100 - $active_percent) / 100);
                    $discounted_unit_price = (float) wc_format_decimal($discounted_unit_price, wc_get_price_decimals());

                    $cart_item['data']->set_price($discounted_unit_price);
                    $cart_item['nv_bulk_discount_percent'] = $active_percent;
                    $cart_item['nv_bulk_base_price'] = $base_unit_price;
                    $cart_item['nv_bulk_discount_unit'] = max(0, $base_unit_price - $discounted_unit_price);
                    $cart_item['nv_bulk_discount_line'] = $cart_item['nv_bulk_discount_unit'] * $qty;
                } else {
                    $cart_item['data']->set_price($base_unit_price);
                    unset($cart_item['nv_bulk_discount_percent'], $cart_item['nv_bulk_base_price'], $cart_item['nv_bulk_discount_unit'], $cart_item['nv_bulk_discount_line']);
                }

                $cart->cart_contents[$cart_item_key] = $cart_item;
            }
        }

        public function append_bulk_discount_item_data(array $item_data, array $cart_item): array {
            $line_discount = isset($cart_item['nv_bulk_discount_line']) ? (float) $cart_item['nv_bulk_discount_line'] : 0.0;
            if ($line_discount <= 0) {
                return $item_data;
            }

            $item_data[] = [
                'name' => __('Rabatt', 'nv-commerce-core'),
                'value' => '-' . wp_strip_all_tags(wc_price($line_discount)),
            ];

            return $item_data;
        }

        public function add_bulk_discount_order_item_meta(WC_Order_Item_Product $item, string $cart_item_key, array $values, WC_Order $order): void {
            $line_discount = isset($values['nv_bulk_discount_line']) ? (float) $values['nv_bulk_discount_line'] : 0.0;
            if ($line_discount <= 0) {
                return;
            }

            $item->add_meta_data(__('Rabatt', 'nv-commerce-core'), '-' . wp_strip_all_tags(wc_price($line_discount)), true);
        }

        private function get_active_bulk_discount_percent(int $cart_qty): int {
            if ($cart_qty >= 4) {
                return 20;
            }
            if ($cart_qty >= 3) {
                return 15;
            }
            if ($cart_qty >= 2) {
                return 10;
            }
            return 0;
        }

        private function get_cart_quantity_from_object(WC_Cart $cart): int {
            $qty = 0;
            foreach ($cart->get_cart() as $cart_item) {
                // NV Product Widgets bundle lines + free gifts are self-priced and must
                // not count toward the store-wide bulk-discount threshold.
                if (!empty($cart_item['_nv_pw_fixed_unit']) || !empty($cart_item['nv_pw_gift'])) {
                    continue;
                }
                $qty += max(0, (int) ($cart_item['quantity'] ?? 0));
            }
            return (int) $qty;
        }

        private function get_base_unit_price_for_cart_item(array $cart_item): float {
            $source = null;

            if (!empty($cart_item['variation_id'])) {
                $source = wc_get_product((int) $cart_item['variation_id']);
            }
            if (!$source && !empty($cart_item['product_id'])) {
                $source = wc_get_product((int) $cart_item['product_id']);
            }

            if (!$source || !($source instanceof WC_Product)) {
                return 0.0;
            }

            $price = $this->sanitize_number($source->get_price());
            if ($price <= 0) {
                $price = $this->sanitize_number($source->get_regular_price());
            }
            return (float) $price;
        }

        private function get_regular_unit_price_for_cart_item(array $cart_item): float {
            $source = null;

            if (!empty($cart_item['variation_id'])) {
                $source = wc_get_product((int) $cart_item['variation_id']);
            }
            if (!$source && !empty($cart_item['product_id'])) {
                $source = wc_get_product((int) $cart_item['product_id']);
            }
            if (!$source instanceof WC_Product) {
                return 0.0;
            }

            $regular = $this->sanitize_number($source->get_regular_price());
            if ($regular <= 0) {
                $regular = $this->sanitize_number($source->get_price());
            }

            return (float) $regular;
        }

        private function get_summary_base_unit_price_for_cart_item(array $cart_item, float $discounted_unit): float {
            if (isset($cart_item['nv_bulk_base_price'])) {
                $bulk_base = $this->sanitize_number($cart_item['nv_bulk_base_price']);
                if ($bulk_base > 0) {
                    return $bulk_base;
                }
            }

            $regular_unit = $this->get_regular_unit_price_for_cart_item($cart_item);
            return max($regular_unit, $discounted_unit);
        }

        private function build_side_cart_payload(): array {
            if (!$this->ensure_cart_loaded()) {
                return [
                    'count' => 0,
                    'items' => [],
                    'subtotal' => wp_kses_post(wc_price(0)),
                    'original_total' => '',
                    'order_value' => wp_kses_post(wc_price(0)),
                    'payable_total' => wp_kses_post(wc_price(0)),
                    'total_savings_html' => wp_kses_post(wc_price(0)),
                    'total_savings' => 0.0,
                ];
            }

            $items = [];
            $count = 0;
            $discounted_total = 0.0;
            $original_total = 0.0;
            $total_savings = 0.0;

            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                if (empty($cart_item['data']) || !($cart_item['data'] instanceof WC_Product)) {
                    continue;
                }

                /** @var WC_Product $product */
                $product = $cart_item['data'];
                $qty = max(1, (int) ($cart_item['quantity'] ?? 1));
                $count += $qty;

                $is_gift = !empty($cart_item['nv_pw_gift']);

                $discounted_unit = $this->sanitize_number($product->get_price());
                if ($discounted_unit <= 0) {
                    $discounted_unit = $this->get_base_unit_price_for_cart_item($cart_item);
                }
                $base_unit = $this->get_summary_base_unit_price_for_cart_item($cart_item, $discounted_unit);

                // NV Product Widgets free gift: it costs nothing, so show it as free here
                // too (never fall back to the catalog price) — keeps the drawer line and
                // total consistent with checkout.
                if ($is_gift) {
                    $discounted_unit = 0.0;
                }

                $line_regular = $base_unit * $qty;
                $line_sale = $discounted_unit * $qty;
                $line_savings = max(0, $line_regular - $line_sale);

                $original_total += $line_regular;
                $discounted_total += $line_sale;
                $total_savings += $line_savings;

                $free_label = esc_html__('Gratis', 'nv-commerce-core');
                $items[] = [
                    'key' => $cart_item_key,
                    'name' => wp_strip_all_tags($product->get_name()),
                    'thumbnail' => $this->get_cart_item_thumbnail_url($cart_item),
                    'permalink' => esc_url_raw(get_permalink((int) ($cart_item['product_id'] ?? 0))),
                    'variation' => $this->get_cart_item_variation_labels($cart_item),
                    'quantity' => $qty,
                    'regular_price' => wp_kses_post(wc_price($line_regular)),
                    'sale_price' => $is_gift ? $free_label : wp_kses_post(wc_price($line_sale)),
                    'price' => $is_gift ? $free_label : wp_kses_post(wc_price($line_sale)),
                    'savings' => wp_kses_post(wc_price($line_savings)),
                    'savings_amount' => (float) wc_format_decimal($line_savings, 2),
                    'bulk_discount_amount' => (float) wc_format_decimal($line_savings, 2),
                ];
            }

            $fee_savings = $this->get_cart_fee_savings();
            if ($fee_savings > 0) {
                $discounted_total = max(0, $discounted_total - $fee_savings);
                $total_savings += $fee_savings;
            }

            return [
                'count' => $count,
                'items' => $items,
                'subtotal' => wp_kses_post(wc_price($discounted_total)),
                'original_total' => $original_total > 0 ? wp_kses_post(wc_price($original_total)) : '',
                'order_value' => wp_kses_post(wc_price($original_total)),
                'payable_total' => wp_kses_post(wc_price($discounted_total)),
                'total_savings_html' => wp_kses_post(wc_price($total_savings)),
                'total_savings' => (float) wc_format_decimal($total_savings, 2),
            ];
        }

        private function get_cart_item_thumbnail_url(array $cart_item): string {
            $image_id = 0;
            if (!empty($cart_item['data']) && $cart_item['data'] instanceof WC_Product) {
                $image_id = (int) $cart_item['data']->get_image_id();
            }

            if ($image_id <= 0 && !empty($cart_item['product_id'])) {
                $parent_product = wc_get_product((int) $cart_item['product_id']);
                if ($parent_product) {
                    $image_id = (int) $parent_product->get_image_id();
                }
            }

            $url = $image_id > 0 ? wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail') : '';
            if (!$url) {
                $url = wc_placeholder_img_src('woocommerce_thumbnail');
            }
            return esc_url_raw($url);
        }

        private function get_cart_fee_savings(): float {
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                return 0.0;
            }

            $fee_total = 0.0;
            foreach (WC()->cart->get_fees() as $fee) {
                $fee_line_total = isset($fee->total) ? (float) $fee->total : 0.0;
                if ($fee_line_total < 0) {
                    $fee_total += abs($fee_line_total);
                }
            }

            return (float) wc_format_decimal($fee_total, 2);
        }

        private function get_cart_item_variation_labels(array $cart_item): array {
            $labels = [];
            if (empty($cart_item['variation']) || !is_array($cart_item['variation'])) {
                return $labels;
            }

            foreach ($cart_item['variation'] as $attribute_name => $attribute_value) {
                $attribute_value = trim((string) $attribute_value);
                if ($attribute_value === '') {
                    continue;
                }

                $taxonomy = str_replace('attribute_', '', (string) $attribute_name);
                $value_label = $this->get_attribute_value_label($taxonomy, $attribute_value);
                $attribute_label = wc_attribute_label($taxonomy);

                if ($attribute_label && $attribute_label !== $taxonomy) {
                    $labels[] = $attribute_label . ': ' . $value_label;
                } else {
                    $labels[] = $value_label;
                }
            }

            return $labels;
        }

        private function build_payload(): array {
            $settings = $this->get_settings();
            $cart_qty = $this->get_cart_quantity();
            $cart_product_ids = $this->get_cart_product_ids();

            $products = $this->get_candidate_products(
                $cart_product_ids,
                (int) $settings['max_products'],
                $settings
            );

            return [
                'headline' => $this->get_dynamic_headline($cart_qty, $settings),
                'cartQty' => $cart_qty,
                'products' => $products,
                'tier' => $this->get_discount_tier($cart_qty),
            ];
        }

        private function get_dynamic_headline(int $cart_qty, array $settings): string {
            if ($cart_qty <= 1) {
                return $settings['headline_tier_2'];
            }
            if ($cart_qty === 2) {
                return $settings['headline_tier_3'];
            }
            if ($cart_qty === 3) {
                return $settings['headline_tier_4'];
            }
            return $settings['headline_tier_max'];
        }

        private function get_discount_tier(int $cart_qty): int {
            return $this->get_active_bulk_discount_percent($cart_qty);
        }

        private function get_cart_quantity(): int {
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                return 0;
            }
            return (int) WC()->cart->get_cart_contents_count();
        }

        private function get_cart_product_ids(): array {
            $ids = [];
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                return $ids;
            }

            foreach (WC()->cart->get_cart() as $item) {
                if (!empty($item['product_id'])) {
                    $ids[] = (int) $item['product_id'];
                }
            }
            return array_values(array_unique($ids));
        }

        private function get_cart_total(): float {
            if (!$this->woocommerce_ready() || !$this->ensure_cart_loaded()) {
                return 0.0;
            }
            return (float) WC()->cart->get_cart_contents_total();
        }

        private function ensure_cart_loaded(): bool {
            if (!$this->woocommerce_ready()) {
                return false;
            }

            if (WC()->cart instanceof WC_Cart) {
                return true;
            }

            if (function_exists('wc_load_cart')) {
                wc_load_cart();
            } elseif (method_exists(WC(), 'initialize_cart')) {
                WC()->initialize_cart();
            }

            return WC()->cart instanceof WC_Cart;
        }

        private function get_candidate_products(array $exclude_ids, int $limit, array $settings): array {
            $ids = $this->get_configured_product_ids();
            $products = [];
            $filters = [
                'allowed_category_ids' => $this->parse_csv_ids((string) $settings['allowed_category_ids']),
                'popular_badge_ids' => $this->parse_csv_ids((string) $settings['popular_badge_ids']),
                'new_badge_ids' => $this->parse_csv_ids((string) $settings['new_badge_ids']),
                'price_cap_threshold_total' => $this->sanitize_number($settings['price_cap_threshold_total']),
                'price_cap_max_product_price' => $this->sanitize_number($settings['price_cap_max_product_price']),
                'cart_total' => $this->get_cart_total(),
            ];

            if (!empty($ids)) {
                foreach ($ids as $id) {
                    if (in_array((int) $id, $exclude_ids, true)) {
                        continue;
                    }
                    $product_data = $this->build_product_payload((int) $id, $filters);
                    if ($product_data !== null) {
                        $products[] = $product_data;
                    }
                    if (count($products) >= $limit) {
                        break;
                    }
                }
            }

            if (count($products) < $limit) {
                $fallback_products = wc_get_products([
                    'status' => 'publish',
                    'limit' => 30,
                    'orderby' => 'popularity',
                    'order' => 'DESC',
                    'stock_status' => 'instock',
                    'exclude' => $exclude_ids,
                ]);

                foreach ($fallback_products as $product) {
                    $product_data = $this->build_product_payload((int) $product->get_id(), $filters);
                    if ($product_data === null) {
                        continue;
                    }
                    if ($this->contains_product($products, (int) $product_data['productId'])) {
                        continue;
                    }
                    $products[] = $product_data;
                    if (count($products) >= $limit) {
                        break;
                    }
                }
            }

            return array_values($products);
        }

        private function contains_product(array $products, int $product_id): bool {
            foreach ($products as $entry) {
                if (!empty($entry['productId']) && (int) $entry['productId'] === $product_id) {
                    return true;
                }
            }
            return false;
        }

        private function build_product_payload(int $product_id, array $filters = []): ?array {
            $product = wc_get_product($product_id);
            if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) {
                return null;
            }
            if (!$this->product_matches_category_filter($product, $filters)) {
                return null;
            }

            $variation_id = 0;
            $price_product = $product;
            $is_variable = false;
            $variations_payload = [];
            $display_price_html = $this->build_compact_price_html($product);
            if ($display_price_html === '') {
                $display_price_html = wc_price((float) $product->get_price());
            }
            $selected_variation_price_html = '';
            $selected_variation_price_text = '';

            if ($product->is_type('variable')) {
                $is_variable = true;
                $variations_payload = $this->get_variable_product_options($product, $filters);
                if (empty($variations_payload)) {
                    return null;
                }
                $variation_id = (int) $variations_payload[0]['id'];
                $variation_product = wc_get_product($variation_id);
                if (!$variation_product || !$variation_product->is_type('variation')) {
                    return null;
                }
                $price_product = $variation_product;
                $display_price_html = (string) $variations_payload[0]['priceHtml'];
                $selected_variation_price_html = (string) $variations_payload[0]['priceHtml'];
                $selected_variation_price_text = (string) $variations_payload[0]['priceText'];
            } elseif (!$product->is_type('simple')) {
                return null;
            }
            if (!$this->product_passes_price_cap($price_product, $filters)) {
                return null;
            }

            $image_id = $product->get_image_id();
            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'woocommerce_thumbnail') : '';
            if (!$image_url) {
                $image_url = wc_placeholder_img_src('woocommerce_thumbnail');
            }

            return [
                'productId' => (int) $product->get_id(),
                'variationId' => (int) $variation_id,
                'isVariable' => $is_variable,
                'variations' => $variations_payload,
                'selectedVariationPriceHtml' => $selected_variation_price_html,
                'selectedVariationPriceText' => $selected_variation_price_text,
                'name' => wp_strip_all_tags($product->get_name()),
                'priceHtml' => $display_price_html,
                'image' => esc_url_raw($image_url),
                'url' => esc_url_raw(get_permalink($product->get_id())),
                'badge' => $this->resolve_product_badge((int) $product->get_id(), $filters),
            ];
        }

        private function get_variable_product_options(WC_Product $product, array $filters): array {
            if (!$product->is_type('variable')) {
                return [];
            }

            $options = [];
            $variation_ids = $product->get_children();

            foreach ($variation_ids as $variation_id) {
                $variation = wc_get_product($variation_id);
                if (!$variation || !$variation->is_type('variation')) {
                    continue;
                }
                if (!$variation->is_purchasable() || !$variation->is_in_stock()) {
                    continue;
                }
                if (!$this->product_passes_price_cap($variation, $filters)) {
                    continue;
                }

                $variation_attributes = $variation->get_variation_attributes();
                $variation_label = $this->build_variation_label($variation_attributes);
                if ($variation_label === '') {
                    $variation_label = wp_strip_all_tags($variation->get_name());
                }

                $price_html = $this->build_compact_price_html($variation);
                if ($price_html === '') {
                    $price_html = wc_price((float) $variation->get_price());
                }

                $options[] = [
                    'id' => (int) $variation->get_id(),
                    'label' => $variation_label,
                    'priceHtml' => wp_kses_post($price_html),
                    'priceText' => $this->strip_price_html($price_html),
                ];
            }

            return $options;
        }

        private function build_compact_price_html(WC_Product $product): string {
            $current = $this->sanitize_number($product->get_price());
            $regular = $this->sanitize_number($product->get_regular_price());

            if ($current <= 0 && $regular <= 0) {
                return '';
            }

            if ($regular > 0 && $current > 0 && $regular > $current) {
                return '<del>' . wc_price($regular) . '</del> <ins>' . wc_price($current) . '</ins>';
            }

            $display = $current > 0 ? $current : $regular;
            return wc_price($display);
        }

        private function build_variation_label(array $attributes): string {
            if (empty($attributes)) {
                return '';
            }

            $parts = [];
            $attribute_count = count($attributes);

            foreach ($attributes as $attribute_name => $attribute_value) {
                $attribute_value = trim((string) $attribute_value);
                if ($attribute_value === '') {
                    continue;
                }

                $taxonomy = str_replace('attribute_', '', (string) $attribute_name);
                $value_label = $this->get_attribute_value_label($taxonomy, $attribute_value);

                if ($attribute_count > 1) {
                    $parts[] = wc_attribute_label($taxonomy) . ': ' . $value_label;
                } else {
                    $parts[] = $value_label;
                }
            }

            return trim(implode(' / ', $parts));
        }

        private function get_attribute_value_label(string $taxonomy, string $raw_value): string {
            if ($raw_value === '') {
                return '';
            }

            if (taxonomy_exists($taxonomy)) {
                $term = get_term_by('slug', $raw_value, $taxonomy);
                if ($term && !is_wp_error($term) && !empty($term->name)) {
                    return wp_strip_all_tags((string) $term->name);
                }
            }

            $fallback = str_replace(['-', '_'], ' ', $raw_value);
            return wp_strip_all_tags(ucwords($fallback));
        }

        private function strip_price_html(string $price_html): string {
            $text = html_entity_decode(wp_strip_all_tags($price_html), ENT_QUOTES, 'UTF-8');
            $text = preg_replace('/\s+/', ' ', (string) $text);
            return trim((string) $text);
        }

        private function get_first_instock_variation_id(WC_Product $product): int {
            if (!$product->is_type('variable')) {
                return 0;
            }

            $variation_ids = $product->get_children();
            foreach ($variation_ids as $variation_id) {
                $variation = wc_get_product($variation_id);
                if (!$variation) {
                    continue;
                }
                if ($variation->is_purchasable() && $variation->is_in_stock()) {
                    return (int) $variation_id;
                }
            }
            return 0;
        }

        private function product_matches_category_filter(WC_Product $product, array $filters): bool {
            $allowed_category_ids = !empty($filters['allowed_category_ids']) && is_array($filters['allowed_category_ids'])
                ? $filters['allowed_category_ids']
                : [];

            if (empty($allowed_category_ids)) {
                return true;
            }

            $product_category_ids = array_map('absint', $product->get_category_ids());
            if (empty($product_category_ids)) {
                return false;
            }

            return !empty(array_intersect($allowed_category_ids, $product_category_ids));
        }

        private function product_passes_price_cap(WC_Product $product, array $filters): bool {
            $threshold = isset($filters['price_cap_threshold_total']) ? (float) $filters['price_cap_threshold_total'] : 0.0;
            $max_price = isset($filters['price_cap_max_product_price']) ? (float) $filters['price_cap_max_product_price'] : 0.0;
            $cart_total = isset($filters['cart_total']) ? (float) $filters['cart_total'] : 0.0;

            if ($threshold <= 0 || $max_price <= 0 || $cart_total <= $threshold) {
                return true;
            }

            $product_price = $this->sanitize_number($product->get_price());
            if ($product_price <= 0) {
                return false;
            }

            return $product_price <= $max_price;
        }

        private function resolve_product_badge(int $product_id, array $filters): string {
            $popular_badge_ids = !empty($filters['popular_badge_ids']) && is_array($filters['popular_badge_ids'])
                ? $filters['popular_badge_ids']
                : [];
            $new_badge_ids = !empty($filters['new_badge_ids']) && is_array($filters['new_badge_ids'])
                ? $filters['new_badge_ids']
                : [];

            if (in_array($product_id, $popular_badge_ids, true)) {
                return 'popular';
            }
            if (in_array($product_id, $new_badge_ids, true)) {
                return 'new';
            }
            return '';
        }

        private function parse_csv_ids(string $raw): array {
            if ($raw === '') {
                return [];
            }
            $parts = array_map('trim', explode(',', $raw));
            $ids = array_filter(array_map('absint', $parts));
            return array_values(array_unique($ids));
        }

        private function sanitize_number($value): float {
            if ($value === null || $value === '') {
                return 0.0;
            }
            $normalized = str_replace(',', '.', (string) $value);
            return max(0.0, (float) $normalized);
        }

        private function get_configured_product_ids(): array {
            $settings = $this->get_settings();
            return $this->parse_csv_ids((string) $settings['product_ids']);
        }

        private function get_settings(): array {
            $saved = get_option(self::OPTION_KEY, []);
            if (!is_array($saved)) {
                $saved = [];
            }
            return wp_parse_args($saved, $this->defaults());
        }

        private function defaults(): array {
            return [
                'enabled_checkout' => 'yes',
                'enabled_sidecart' => 'yes',
                'bulk_discount_enabled' => 'no',
                'hide_merchant_upsell' => 'yes',
                'product_ids' => '',
                'popular_badge_ids' => '',
                'new_badge_ids' => '',
                'allowed_category_ids' => '',
                'price_cap_threshold_total' => 0,
                'price_cap_max_product_price' => 0,
                'max_products' => 8,
                'headline_tier_2' => 'Snabbt tips: Lägg till 1 till och spara 10%',
                'headline_tier_3' => 'Snabbt tips: Lägg till 1 till och spara 15%',
                'headline_tier_4' => 'Snabbt tips: Lägg till 1 till och spara 20%',
                'headline_tier_max' => 'Maxrabatt 20% aktiv i varukorgen',
            ];
        }

        private function is_legacy_bulk_enabled(): bool {
            $settings = $this->get_settings();
            return (($settings['bulk_discount_enabled'] ?? 'no') === 'yes');
        }

        public function add_admin_menu(): void {
            $capability = $this->resolve_admin_capability();

            add_submenu_page(
                self::CORE_MENU_SLUG,
                __('NV Smart Upsell', 'nv-commerce-core'),
                __('NV Smart Upsell', 'nv-commerce-core'),
                $capability,
                self::MENU_SLUG,
                [$this, 'render_settings_page']
            );
        }

        private function resolve_admin_capability(): string {
            $capability = apply_filters('nvcc_admin_capability', 'manage_woocommerce');
            if (!is_string($capability) || $capability === '') {
                return 'manage_woocommerce';
            }

            return sanitize_key($capability);
        }

        private function has_admin_access(): bool {
            return current_user_can($this->resolve_admin_capability())
                || current_user_can('manage_woocommerce')
                || current_user_can('manage_options')
                || current_user_can('activate_plugins');
        }

        public function register_settings(): void {
            register_setting(
                'nv_smart_upsell_group',
                self::OPTION_KEY,
                [$this, 'sanitize_settings']
            );
        }

        public function sanitize_settings($input): array {
            $defaults = $this->defaults();
            $input = is_array($input) ? $input : [];

            return [
                'enabled_checkout' => (!empty($input['enabled_checkout']) && $input['enabled_checkout'] === 'yes') ? 'yes' : 'no',
                'enabled_sidecart' => (!empty($input['enabled_sidecart']) && $input['enabled_sidecart'] === 'yes') ? 'yes' : 'no',
                'bulk_discount_enabled' => (!empty($input['bulk_discount_enabled']) && $input['bulk_discount_enabled'] === 'yes') ? 'yes' : 'no',
                'hide_merchant_upsell' => (!empty($input['hide_merchant_upsell']) && $input['hide_merchant_upsell'] === 'yes') ? 'yes' : 'no',
                'product_ids' => isset($input['product_ids']) ? sanitize_text_field($input['product_ids']) : '',
                'popular_badge_ids' => isset($input['popular_badge_ids']) ? sanitize_text_field($input['popular_badge_ids']) : '',
                'new_badge_ids' => isset($input['new_badge_ids']) ? sanitize_text_field($input['new_badge_ids']) : '',
                'allowed_category_ids' => isset($input['allowed_category_ids']) ? sanitize_text_field($input['allowed_category_ids']) : '',
                'price_cap_threshold_total' => isset($input['price_cap_threshold_total']) ? $this->sanitize_number($input['price_cap_threshold_total']) : $defaults['price_cap_threshold_total'],
                'price_cap_max_product_price' => isset($input['price_cap_max_product_price']) ? $this->sanitize_number($input['price_cap_max_product_price']) : $defaults['price_cap_max_product_price'],
                'max_products' => isset($input['max_products']) ? max(3, min(20, absint($input['max_products']))) : $defaults['max_products'],
                'headline_tier_2' => isset($input['headline_tier_2']) ? sanitize_text_field($input['headline_tier_2']) : $defaults['headline_tier_2'],
                'headline_tier_3' => isset($input['headline_tier_3']) ? sanitize_text_field($input['headline_tier_3']) : $defaults['headline_tier_3'],
                'headline_tier_4' => isset($input['headline_tier_4']) ? sanitize_text_field($input['headline_tier_4']) : $defaults['headline_tier_4'],
                'headline_tier_max' => isset($input['headline_tier_max']) ? sanitize_text_field($input['headline_tier_max']) : $defaults['headline_tier_max'],
            ];
        }

        public function render_settings_page(): void {
            if (!$this->has_admin_access()) {
                return;
            }
            $settings = $this->get_settings();
            ?>
            <div class="wrap nv-admin-clean nvcc-smart-upsell-admin">
                <style>
                    .nv-admin-clean{max-width:1180px}.nv-admin-clean__hero,.nv-admin-clean__panel{background:#fff;border:1px solid #dcdcde;border-radius:8px;box-sizing:border-box;margin:16px 0;padding:18px 20px}.nv-admin-clean__hero h1{align-items:center;display:flex;flex-wrap:wrap;gap:10px;line-height:1.2;margin:0 0 8px}.nv-admin-clean__hero p{color:#50575e;font-size:14px;margin:0;max-width:860px}.nv-admin-clean__version{background:#f6f7f7;border:1px solid #dcdcde;border-radius:999px;color:#50575e;font-size:12px;font-weight:600;line-height:1;padding:4px 8px}.nv-admin-clean .form-table{margin-top:0}.nv-admin-clean .form-table th{width:240px}.nv-admin-clean input.regular-text,.nv-admin-clean input.large-text,.nv-admin-clean textarea.large-text{max-width:100%;width:100%}.nv-admin-clean .submit{margin-bottom:0;padding-bottom:0}@media (max-width:782px){.nv-admin-clean .form-table th{width:auto}.nv-admin-clean__hero,.nv-admin-clean__panel{padding:14px}}
                </style>
                <div class="nv-admin-clean__hero">
                    <h1><?php esc_html_e('NV Smart Upsell', 'nv-commerce-core'); ?> <span class="nv-admin-clean__version">v<?php echo esc_html(self::VERSION); ?></span></h1>
                    <p><?php esc_html_e('Styr vilka produkter som visas i checkout + sidokorg-karusellen.', 'nv-commerce-core'); ?></p>
                </div>

                <div class="nv-admin-clean__panel">
                <form method="post" action="options.php">
                    <?php settings_fields('nv_smart_upsell_group'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><?php esc_html_e('Aktivera på checkout', 'nv-commerce-core'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[enabled_checkout]" value="yes" <?php checked($settings['enabled_checkout'], 'yes'); ?> />
                                    <?php esc_html_e('Ja', 'nv-commerce-core'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Aktivera i sidokorg', 'nv-commerce-core'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[enabled_sidecart]" value="yes" <?php checked($settings['enabled_sidecart'], 'yes'); ?> />
                                    <?php esc_html_e('Ja', 'nv-commerce-core'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Aktivera bulk-rabatt (2=10%, 3=15%, 4+=20%)', 'nv-commerce-core'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[bulk_discount_enabled]" value="yes" <?php checked($settings['bulk_discount_enabled'], 'yes'); ?> />
                                    <?php esc_html_e('Ja', 'nv-commerce-core'); ?>
                                </label>
                                <p class="description"><?php esc_html_e('Gäller hela varukorgen och ersätter Merchant Pro bulk-discount logik.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Dölj Merchant Pro upsell block', 'nv-commerce-core'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[hide_merchant_upsell]" value="yes" <?php checked($settings['hide_merchant_upsell'], 'yes'); ?> />
                                    <?php esc_html_e('Ja (rekommenderat)', 'nv-commerce-core'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Produkt-ID lista', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[product_ids]" value="<?php echo esc_attr($settings['product_ids']); ?>" />
                                <p class="description"><?php esc_html_e('Komma-separerade produkt-ID:n. Ex: 14501,15308,15309', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Populär badge (Produkt-ID)', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[popular_badge_ids]" value="<?php echo esc_attr($settings['popular_badge_ids']); ?>" />
                                <p class="description"><?php esc_html_e('Produkt-ID med badge "Populär". Komma-separerat.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Ny badge (Produkt-ID)', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[new_badge_ids]" value="<?php echo esc_attr($settings['new_badge_ids']); ?>" />
                                <p class="description"><?php esc_html_e('Produkt-ID med badge "Ny". Komma-separerat.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Kategori-filter (kategori-ID)', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[allowed_category_ids]" value="<?php echo esc_attr($settings['allowed_category_ids']); ?>" />
                                <p class="description"><?php esc_html_e('Valfritt. Om satt visas bara produkter från dessa produktkategorier.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Max antal produkter i karusell', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="number" min="3" max="20" name="<?php echo esc_attr(self::OPTION_KEY); ?>[max_products]" value="<?php echo esc_attr((string) $settings['max_products']); ?>" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Pris-cap aktiv över varukorgsbelopp', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[price_cap_threshold_total]" value="<?php echo esc_attr((string) $settings['price_cap_threshold_total']); ?>" />
                                <p class="description"><?php esc_html_e('Y-värde: om varukorgen överstiger detta belopp aktiveras produkt-prisfilter.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Max produktpris när pris-cap är aktiv', 'nv-commerce-core'); ?></th>
                            <td>
                                <input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[price_cap_max_product_price]" value="<?php echo esc_attr((string) $settings['price_cap_max_product_price']); ?>" />
                                <p class="description"><?php esc_html_e('X-värde: visa endast produkter upp till detta pris när pris-cap är aktiv.', 'nv-commerce-core'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Headline när 1 vara finns', 'nv-commerce-core'); ?></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[headline_tier_2]" value="<?php echo esc_attr($settings['headline_tier_2']); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Headline när 2 varor finns', 'nv-commerce-core'); ?></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[headline_tier_3]" value="<?php echo esc_attr($settings['headline_tier_3']); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Headline när 3 varor finns', 'nv-commerce-core'); ?></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[headline_tier_4]" value="<?php echo esc_attr($settings['headline_tier_4']); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Headline när 4+ varor finns', 'nv-commerce-core'); ?></th>
                            <td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[headline_tier_max]" value="<?php echo esc_attr($settings['headline_tier_max']); ?>" /></td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
                </div>
            </div>
            <?php
        }

        private function woocommerce_ready(): bool {
            return function_exists('WC') && WC();
        }
    }
}
