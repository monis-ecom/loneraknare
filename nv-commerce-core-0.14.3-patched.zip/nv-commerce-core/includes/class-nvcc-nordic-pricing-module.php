<?php
/**
 * NV Commerce Core – Nordic Pricing module.
 *
 * Enables manual, country-specific prices for Nordic markets (Norway, Denmark, Finland).
 * Built to be expandable: adding a new country requires only a new entry in NORDIC_COUNTRIES.
 *
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Nestly_NVCC_Nordic_Pricing_Runtime' ) ) {

	final class Nestly_NVCC_Nordic_Pricing_Runtime {

		/* ── Constants ─────────────────────────────────────────── */

		private const META_KEY       = '_nvcc_nordic_prices';
		private const OPTION_KEY     = 'nvcc_nordic_pricing_settings';
		private const NONCE_META     = 'nvcc_nordic_pricing_meta_nonce';
		private const MENU_SLUG      = 'nestly-nordic-pricing';
		private const CORE_MENU_SLUG = 'nestly-commerce-core-settings';

		/**
		 * Supported Nordic markets.
		 *
		 * To expand to a new country (e.g. Iceland), add a new entry here.
		 * Keys must be ISO 3166-1 alpha-2 country codes.
		 *
		 * 'decimals' = preferred number of decimal places for display.
		 */
		private const NORDIC_COUNTRIES = [
			'NO' => [
				'label'    => 'Norway',
				'label_sv' => 'Norge',
				'currency' => 'NOK',
				'symbol'   => 'kr',
				'flag'     => '🇳🇴',
				'decimals' => 0,
			],
			'DK' => [
				'label'    => 'Denmark',
				'label_sv' => 'Danmark',
				'currency' => 'DKK',
				'symbol'   => 'kr.',
				'flag'     => '🇩🇰',
				'decimals' => 0,
			],
			'FI' => [
				'label'    => 'Finland',
				'label_sv' => 'Finland',
				'currency' => 'EUR',
				'symbol'   => '€',
				'flag'     => '🇫🇮',
				'decimals' => 2,
			],
		];

		/* ── State ──────────────────────────────────────────────── */

		/** @var string|null Resolved country code for the current request */
		private ?string $request_country = null;

		/** @var bool Whether country resolution has been attempted this request */
		private bool $resolution_done = false;

		/* ── Boot ───────────────────────────────────────────────── */

		public static function init(): void {
			$instance = new self();
			$instance->register_hooks();
		}

		private function register_hooks(): void {
			// Admin: product-level meta box (simple products)
			add_action( 'add_meta_boxes',    [ $this, 'register_product_meta_box' ] );
			add_action( 'save_post_product', [ $this, 'save_product_meta_box' ] );

			// Admin: per-variation pricing fields (variable products)
			add_action( 'woocommerce_product_after_variable_attributes', [ $this, 'render_variation_pricing_fields' ], 15, 3 );
			add_action( 'woocommerce_save_product_variation',             [ $this, 'save_variation_pricing_fields' ],  15, 2 );

			// Admin: settings sub-page under Commerce Core menu
			add_action( 'admin_menu', [ $this, 'register_admin_submenu' ] );
			add_action( 'admin_init', [ $this, 'register_admin_settings' ] );

			// Frontend: price & currency overrides
			add_filter( 'woocommerce_product_get_price',                   [ $this, 'maybe_override_price' ], 10, 2 );
			add_filter( 'woocommerce_product_get_regular_price',           [ $this, 'maybe_override_price' ], 10, 2 );
			add_filter( 'woocommerce_product_variation_get_price',         [ $this, 'maybe_override_price' ], 10, 2 );
			add_filter( 'woocommerce_product_variation_get_regular_price', [ $this, 'maybe_override_price' ], 10, 2 );
			add_filter( 'woocommerce_currency',                            [ $this, 'maybe_switch_currency' ],        10, 1 );
			add_filter( 'get_woocommerce_currency_symbol',                 [ $this, 'maybe_switch_currency_symbol' ], 10, 2 );
			add_filter( 'wc_price_args',                                   [ $this, 'maybe_adjust_price_args' ],      10, 1 );

			// Frontend: optional manual country-switcher widget in footer
			add_action( 'wp_footer', [ $this, 'maybe_render_country_switcher' ], 100 );

			// AJAX: handle manual country override from the switcher widget
			add_action( 'wp_ajax_nvcc_nordic_set_country',        [ $this, 'handle_set_country_ajax' ] );
			add_action( 'wp_ajax_nopriv_nvcc_nordic_set_country', [ $this, 'handle_set_country_ajax' ] );
		}

		/* ═══════════════════════════════════════════════════════════
		 * ADMIN: Product Meta Box (simple products)
		 * ═══════════════════════════════════════════════════════════ */

		public function register_product_meta_box(): void {
			add_meta_box(
				'nvcc-nordic-pricing',
				'🌍 ' . __( 'Nordic Pricing', 'nv-commerce-core' ),
				[ $this, 'render_product_meta_box' ],
				'product',
				'side',
				'default'
			);
		}

		public function render_product_meta_box( \WP_Post $post ): void {
			wp_nonce_field( self::NONCE_META, '_nvcc_nordic_pricing_nonce' );

			$prices   = $this->get_product_prices( (int) $post->ID );
			$settings = $this->get_settings();
			?>
			<style>
				.nvcc-np-row { display:flex; align-items:center; gap:8px; margin-bottom:8px; padding:8px 10px; background:#f9f9f9; border-radius:4px; border:1px solid #e5e5e5; }
				.nvcc-np-row .np-flag { font-size:20px; line-height:1; flex-shrink:0; }
				.nvcc-np-row .np-info { flex:1; min-width:0; }
				.nvcc-np-row .np-info label { display:block; font-weight:600; font-size:11px; color:#444; margin-bottom:3px; }
				.nvcc-np-row .np-info input[type=number] { width:100%; padding:4px 6px; border:1px solid #ddd; border-radius:3px; font-size:13px; box-sizing:border-box; }
				.nvcc-np-note { font-size:11px; color:#999; margin:8px 0 0; }
			</style>

			<p style="margin:0 0 10px; font-size:12px; color:#666;">
				<?php esc_html_e( 'Set a manual price for each Nordic country. Leave blank to show the default SEK price.', 'nv-commerce-core' ); ?>
			</p>

			<?php foreach ( self::NORDIC_COUNTRIES as $code => $info ) :
				$option_key  = 'enabled_' . strtolower( $code );
				$globally_on = ( $settings[ $option_key ] ?? 'yes' ) === 'yes';
				$price_val   = $prices[ $code ] ?? '';
				?>
				<div class="nvcc-np-row">
					<span class="np-flag"><?php echo esc_html( $info['flag'] ); ?></span>
					<div class="np-info">
						<label for="nvcc_np_<?php echo esc_attr( $code ); ?>">
							<?php echo esc_html( $info['label'] ); ?>
							<span style="font-weight:normal; color:#888;">(<?php echo esc_html( $info['currency'] ); ?>)</span>
							<?php if ( ! $globally_on ) : ?>
								&nbsp;<span style="color:#d63638; font-weight:normal;"><?php esc_html_e( '(disabled globally)', 'nv-commerce-core' ); ?></span>
							<?php endif; ?>
						</label>
						<input
							type="number"
							id="nvcc_np_<?php echo esc_attr( $code ); ?>"
							name="nvcc_nordic_prices[<?php echo esc_attr( $code ); ?>]"
							value="<?php echo esc_attr( $price_val ); ?>"
							step="1"
							min="0"
							placeholder="<?php esc_attr_e( 'e.g. 329', 'nv-commerce-core' ); ?>"
							<?php echo ! $globally_on ? 'disabled style="opacity:.5;"' : ''; ?>
						/>
					</div>
				</div>
			<?php endforeach; ?>

			<p class="nvcc-np-note">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG ) ); ?>">
					<?php esc_html_e( 'Nordic Pricing settings →', 'nv-commerce-core' ); ?>
				</a>
			</p>
			<?php
		}

		public function save_product_meta_box( int $post_id ): void {
			if ( ! isset( $_POST['_nvcc_nordic_pricing_nonce'] ) ) {
				return;
			}
			if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_nvcc_nordic_pricing_nonce'] ) ), self::NONCE_META ) ) {
				return;
			}
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				return;
			}
			if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
				return;
			}

			$raw_prices = ( isset( $_POST['nvcc_nordic_prices'] ) && is_array( $_POST['nvcc_nordic_prices'] ) )
				? $_POST['nvcc_nordic_prices']
				: [];

			$clean = [];
			foreach ( array_keys( self::NORDIC_COUNTRIES ) as $code ) {
				$raw          = isset( $raw_prices[ $code ] ) ? trim( sanitize_text_field( wp_unslash( $raw_prices[ $code ] ) ) ) : '';
				$clean[ $code ] = ( $raw !== '' && is_numeric( $raw ) && (float) $raw >= 0 ) ? $raw : '';
			}

			update_post_meta( $post_id, self::META_KEY, $clean );
		}

		/* ═══════════════════════════════════════════════════════════
		 * ADMIN: Per-Variation Pricing Fields (variable products)
		 * ═══════════════════════════════════════════════════════════ */

		/**
		 * @param int      $loop
		 * @param array    $variation_data
		 * @param \WP_Post $variation
		 */
		public function render_variation_pricing_fields( int $loop, array $variation_data, \WP_Post $variation ): void {
			$prices = $this->get_product_prices( (int) $variation->ID );
			?>
			<div class="nvcc-np-variation" style="padding:10px 12px; background:#eef5ff; border-top:1px solid #d5e3f5; margin-top:6px; border-radius:0 0 4px 4px;">
				<p style="margin:0 0 7px; font-size:12px; font-weight:600; color:#3a5a8c;">
					🌍 <?php esc_html_e( 'Nordic Pricing (this variation)', 'nv-commerce-core' ); ?>
				</p>
				<div style="display:flex; gap:10px; flex-wrap:wrap;">
					<?php foreach ( self::NORDIC_COUNTRIES as $code => $info ) :
						$price_val = $prices[ $code ] ?? '';
						?>
						<div style="flex:1; min-width:90px;">
							<label style="font-size:11px; color:#555; display:block; margin-bottom:3px;">
								<?php echo esc_html( $info['flag'] ); ?> <?php echo esc_html( $info['label'] ); ?>
								<span style="color:#888;">(<?php echo esc_html( $info['currency'] ); ?>)</span>
							</label>
							<input
								type="number"
								name="nvcc_nordic_variation_prices[<?php echo esc_attr( (string) $loop ); ?>][<?php echo esc_attr( $code ); ?>]"
								value="<?php echo esc_attr( $price_val ); ?>"
								step="1"
								min="0"
								placeholder="—"
								class="short"
								style="width:100%;"
							/>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php
		}

		public function save_variation_pricing_fields( int $variation_id, int $loop ): void {
			if ( ! isset( $_POST['nvcc_nordic_variation_prices'][ $loop ] ) ||
				! is_array( $_POST['nvcc_nordic_variation_prices'][ $loop ] ) ) {
				return;
			}

			$raw_prices = $_POST['nvcc_nordic_variation_prices'][ $loop ];
			$clean      = [];

			foreach ( array_keys( self::NORDIC_COUNTRIES ) as $code ) {
				$raw          = isset( $raw_prices[ $code ] ) ? trim( sanitize_text_field( wp_unslash( $raw_prices[ $code ] ) ) ) : '';
				$clean[ $code ] = ( $raw !== '' && is_numeric( $raw ) && (float) $raw >= 0 ) ? $raw : '';
			}

			update_post_meta( $variation_id, self::META_KEY, $clean );
		}

		/* ═══════════════════════════════════════════════════════════
		 * ADMIN: Settings Sub-Page
		 * ═══════════════════════════════════════════════════════════ */

		public function register_admin_submenu(): void {
			add_submenu_page(
				self::CORE_MENU_SLUG,
				__( 'Nordic Pricing', 'nv-commerce-core' ),
				__( 'Nordic Pricing', 'nv-commerce-core' ),
				'manage_options',
				self::MENU_SLUG,
				[ $this, 'render_settings_page' ]
			);
		}

		public function register_admin_settings(): void {
			register_setting(
				self::OPTION_KEY,
				self::OPTION_KEY,
				[ 'sanitize_callback' => [ $this, 'sanitize_settings_input' ] ]
			);
		}

		public function sanitize_settings_input( mixed $input ): array {
			if ( ! is_array( $input ) ) {
				return $this->get_settings();
			}

			$clean = [];

			foreach ( array_keys( self::NORDIC_COUNTRIES ) as $code ) {
				$key           = 'enabled_' . strtolower( $code );
				$clean[ $key ] = ( isset( $input[ $key ] ) && $input[ $key ] === 'yes' ) ? 'yes' : 'no';
			}

			$valid_detection    = [ 'geolocation', 'billing', 'shipping' ];
			$clean['detection_method'] = in_array( $input['detection_method'] ?? '', $valid_detection, true )
				? $input['detection_method']
				: 'geolocation';

			$clean['allow_manual_switch'] = ( isset( $input['allow_manual_switch'] ) && $input['allow_manual_switch'] === 'yes' ) ? 'yes' : 'no';
			$clean['round_prices']        = ( isset( $input['round_prices'] )        && $input['round_prices']        === 'yes' ) ? 'yes' : 'no';

			return $clean;
		}

		public function render_settings_page(): void {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$settings = $this->get_settings();
			?>
			<div class="wrap nv-admin-clean nvcc-nordic-pricing-admin">
				<style>
					.nv-admin-clean{max-width:1180px}.nv-admin-clean__hero,.nv-admin-clean__panel{background:#fff;border:1px solid #dcdcde;border-radius:8px;box-sizing:border-box;margin:16px 0;padding:18px 20px}.nv-admin-clean__hero h1{align-items:center;display:flex;flex-wrap:wrap;gap:10px;line-height:1.2;margin:0 0 8px}.nv-admin-clean__hero p{color:#50575e;font-size:14px;margin:0;max-width:860px}.nv-admin-clean__version{background:#f6f7f7;border:1px solid #dcdcde;border-radius:999px;color:#50575e;font-size:12px;font-weight:600;line-height:1;padding:4px 8px}.nv-admin-clean .form-table{margin-top:0}.nv-admin-clean .form-table th{width:240px}.nv-admin-clean input.regular-text,.nv-admin-clean input.large-text,.nv-admin-clean textarea.large-text{max-width:100%;width:100%}.nv-admin-clean .submit{margin-bottom:0;padding-bottom:0}.nv-admin-clean__panel h2:first-child{margin-top:0}.nv-admin-clean__panel ol{line-height:1.8;margin-bottom:0;max-width:640px}@media (max-width:782px){.nv-admin-clean .form-table th{width:auto}.nv-admin-clean__hero,.nv-admin-clean__panel{padding:14px}}
				</style>
				<div class="nv-admin-clean__hero">
					<h1>
						<span style="font-size:28px; line-height:1;">🌍</span>
						<?php esc_html_e( 'Nordic Pricing', 'nv-commerce-core' ); ?>
						<span class="nv-admin-clean__version">v<?php echo esc_html( NVCC_VERSION ); ?></span>
					</h1>
					<p>
						<?php esc_html_e( 'Show clean, manually-set prices to customers in Nordic countries instead of auto-converting from SEK. Set prices per product using the "Nordic Pricing" box on each product edit page.', 'nv-commerce-core' ); ?>
					</p>
				</div>

				<?php if ( ! empty( $_GET['settings-updated'] ) ) : ?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e( 'Settings saved.', 'nv-commerce-core' ); ?></p>
					</div>
				<?php endif; ?>

				<div class="nv-admin-clean__panel">
				<form method="post" action="options.php">
					<?php settings_fields( self::OPTION_KEY ); ?>

					<table class="form-table" role="presentation">
						<tbody>

							<!-- Enabled countries -->
							<tr>
								<th scope="row"><?php esc_html_e( 'Enabled Countries', 'nv-commerce-core' ); ?></th>
								<td>
									<fieldset>
										<?php foreach ( self::NORDIC_COUNTRIES as $code => $info ) :
											$key = 'enabled_' . strtolower( $code );
											?>
											<label style="display:inline-flex; align-items:center; gap:6px; margin:0 24px 10px 0; font-size:14px; cursor:pointer;">
												<input type="hidden"   name="<?php echo esc_attr( self::OPTION_KEY . '[' . $key . ']' ); ?>" value="no" />
												<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY . '[' . $key . ']' ); ?>" value="yes" <?php checked( $settings[ $key ] ?? 'yes', 'yes' ); ?> />
												<?php echo esc_html( $info['flag'] ); ?>
												<?php echo esc_html( $info['label'] ); ?>
												<span style="color:#888;">(<?php echo esc_html( $info['currency'] ); ?>)</span>
											</label>
										<?php endforeach; ?>
									</fieldset>
									<p class="description">
										<?php esc_html_e( 'Disabled countries will always see the default SEK price.', 'nv-commerce-core' ); ?>
									</p>
								</td>
							</tr>

							<!-- Detection method -->
							<tr>
								<th scope="row"><?php esc_html_e( 'Country Detection', 'nv-commerce-core' ); ?></th>
								<td>
									<select name="<?php echo esc_attr( self::OPTION_KEY . '[detection_method]' ); ?>">
										<option value="geolocation" <?php selected( $settings['detection_method'], 'geolocation' ); ?>>
											<?php esc_html_e( 'IP Geolocation — detect automatically (recommended)', 'nv-commerce-core' ); ?>
										</option>
										<option value="billing" <?php selected( $settings['detection_method'], 'billing' ); ?>>
											<?php esc_html_e( 'Billing Country — use address entered at checkout', 'nv-commerce-core' ); ?>
										</option>
										<option value="shipping" <?php selected( $settings['detection_method'], 'shipping' ); ?>>
											<?php esc_html_e( 'Shipping Country — use shipping address at checkout', 'nv-commerce-core' ); ?>
										</option>
									</select>
									<p class="description">
										<?php
										printf(
											wp_kses(
												/* translators: %s = link to WooCommerce settings */
												__( 'For geolocation, enable it in <a href="%s">WooCommerce → Settings → General → Default customer location</a>.', 'nv-commerce-core' ),
												[ 'a' => [ 'href' => [] ] ]
											),
											esc_url( admin_url( 'admin.php?page=wc-settings&tab=general' ) )
										);
										?>
									</p>
								</td>
							</tr>

							<!-- Manual switcher -->
							<tr>
								<th scope="row"><?php esc_html_e( 'Manual Country Switch', 'nv-commerce-core' ); ?></th>
								<td>
									<label style="display:inline-flex; align-items:center; gap:6px; cursor:pointer;">
										<input type="hidden"   name="<?php echo esc_attr( self::OPTION_KEY . '[allow_manual_switch]' ); ?>" value="no" />
										<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY . '[allow_manual_switch]' ); ?>" value="yes" <?php checked( $settings['allow_manual_switch'] ?? 'no', 'yes' ); ?> />
										<?php esc_html_e( 'Show a country/currency switcher widget to visitors', 'nv-commerce-core' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Useful for customers using a VPN or browsing from a different country than they intend to order from. Appears as a small pill in the bottom-left corner of the storefront.', 'nv-commerce-core' ); ?>
									</p>
								</td>
							</tr>

							<!-- Round prices -->
							<tr>
								<th scope="row"><?php esc_html_e( 'Round Prices', 'nv-commerce-core' ); ?></th>
								<td>
									<label style="display:inline-flex; align-items:center; gap:6px; cursor:pointer;">
										<input type="hidden"   name="<?php echo esc_attr( self::OPTION_KEY . '[round_prices]' ); ?>" value="no" />
										<input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY . '[round_prices]' ); ?>" value="yes" <?php checked( $settings['round_prices'] ?? 'yes', 'yes' ); ?> />
										<?php esc_html_e( 'Round Nordic prices to whole numbers (e.g. 329 instead of 329.00)', 'nv-commerce-core' ); ?>
									</label>
									<p class="description">
										<?php esc_html_e( 'Recommended for NOK and DKK. EUR (Finland) will always show 2 decimal places regardless of this setting.', 'nv-commerce-core' ); ?>
									</p>
								</td>
							</tr>

						</tbody>
					</table>

					<?php submit_button(); ?>
				</form>
				</div>

				<div class="nv-admin-clean__panel">
				<h2><?php esc_html_e( 'How to use', 'nv-commerce-core' ); ?></h2>
				<ol>
					<li><?php esc_html_e( 'Go to any product in WooCommerce and find the "🌍 Nordic Pricing" box in the right sidebar.', 'nv-commerce-core' ); ?></li>
					<li><?php esc_html_e( 'Enter the price you want customers in each country to see — e.g. 329 for Norway.', 'nv-commerce-core' ); ?></li>
					<li><?php esc_html_e( 'For variable products, you can also set a price per variation using the Nordic Pricing row inside each variation panel.', 'nv-commerce-core' ); ?></li>
					<li><?php esc_html_e( 'When a visitor from that country views your store, they see your manual price and the correct currency — no auto-conversion, no odd decimals.', 'nv-commerce-core' ); ?></li>
					<li><?php esc_html_e( 'If no price is set for a country, that country sees the default SEK price.', 'nv-commerce-core' ); ?></li>
				</ol>
				</div>
			</div>
			<?php
		}

		/* ═══════════════════════════════════════════════════════════
		 * COUNTRY DETECTION
		 * ═══════════════════════════════════════════════════════════ */

		/**
		 * Resolve and cache the active country for this request.
		 *
		 * @return string  ISO 3166-1 alpha-2 code, or '' if undetermined.
		 */
		private function resolve_visitor_country(): string {
			if ( $this->resolution_done ) {
				return $this->request_country ?? '';
			}
			$this->resolution_done = true;

			// 1. Honour any manual override (session / cookie)
			$manual = $this->get_manual_override();
			if ( $manual !== '' ) {
				$this->request_country = $manual;
				return $manual;
			}

			$settings = $this->get_settings();
			$method   = $settings['detection_method'] ?? 'geolocation';
			$country  = '';

			// 2. Address-based detection (only meaningful after checkout begins)
			if ( $method !== 'geolocation' && function_exists( 'WC' ) && WC()->customer instanceof \WC_Customer ) {
				$country = ( $method === 'shipping' )
					? (string) WC()->customer->get_shipping_country()
					: (string) WC()->customer->get_billing_country();
			}

			// 3. Fallback / primary: IP geolocation
			if ( $country === '' ) {
				$country = $this->geolocate_ip();
			}

			$this->request_country = strtoupper( $country );
			return $this->request_country;
		}

		private function geolocate_ip(): string {
			if ( ! class_exists( 'WC_Geolocation' ) ) {
				return '';
			}
			$result = \WC_Geolocation::geolocate_ip( '', true, false );
			return ! empty( $result['country'] ) ? strtoupper( (string) $result['country'] ) : '';
		}

		private function get_manual_override(): string {
			// WC session (cleared on expiry — most reliable)
			if ( function_exists( 'WC' ) && WC()->session instanceof \WC_Session ) {
				$val = (string) WC()->session->get( 'nvcc_country_override', '' );
				if ( $val === 'SE' ) {
					return ''; // Explicit "reset to default"
				}
				if ( $val !== '' && isset( self::NORDIC_COUNTRIES[ $val ] ) ) {
					return $val;
				}
			}

			// Cookie fallback (persists across sessions, 30-day TTL)
			$cookie = isset( $_COOKIE['nvcc_np_country'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['nvcc_np_country'] ) ) : '';
			if ( $cookie === 'SE' ) {
				return '';
			}
			if ( $cookie !== '' && isset( self::NORDIC_COUNTRIES[ $cookie ] ) ) {
				return $cookie;
			}

			return '';
		}

		/**
		 * Return the active Nordic country code if:
		 *   (a) visitor is from a Nordic country, AND
		 *   (b) that country is enabled in settings.
		 *
		 * Returns '' in admin (except AJAX), or if no Nordic country matches.
		 */
		private function get_active_country(): string {
			if ( is_admin() && ! wp_doing_ajax() ) {
				return '';
			}

			$country = $this->resolve_visitor_country();
			if ( $country === '' || ! isset( self::NORDIC_COUNTRIES[ $country ] ) ) {
				return '';
			}

			$settings = $this->get_settings();
			$key      = 'enabled_' . strtolower( $country );
			if ( ( $settings[ $key ] ?? 'yes' ) !== 'yes' ) {
				return '';
			}

			return $country;
		}

		/* ═══════════════════════════════════════════════════════════
		 * PRICE & CURRENCY FILTERS
		 * ═══════════════════════════════════════════════════════════ */

		/**
		 * Swap in the manually-set Nordic price for the current product.
		 *
		 * @param string      $price    WooCommerce-supplied price string
		 * @param \WC_Product $product  The product being priced
		 * @return string
		 */
		public function maybe_override_price( string $price, \WC_Product $product ): string {
			$country = $this->get_active_country();
			if ( $country === '' ) {
				return $price;
			}

			$prices   = $this->get_product_prices( (int) $product->get_id() );
			$np_price = $prices[ $country ] ?? '';

			if ( $np_price === '' || ! is_numeric( $np_price ) || (float) $np_price <= 0 ) {
				return $price; // No price set → use default
			}

			$info     = self::NORDIC_COUNTRIES[ $country ];
			$settings = $this->get_settings();

			// Round to whole number for zero-decimal currencies (NOK, DKK)
			if ( ( $settings['round_prices'] ?? 'yes' ) === 'yes' && ( $info['decimals'] ?? 2 ) === 0 ) {
				return (string) round( (float) $np_price );
			}

			return $np_price;
		}

		/**
		 * Switch WooCommerce currency code for Nordic visitors.
		 *
		 * @param string $currency  Current currency code
		 * @return string
		 */
		public function maybe_switch_currency( string $currency ): string {
			$country = $this->get_active_country();
			if ( $country === '' ) {
				return $currency;
			}
			return self::NORDIC_COUNTRIES[ $country ]['currency'];
		}

		/**
		 * Switch the currency symbol for Nordic visitors.
		 *
		 * @param string $symbol    Current symbol
		 * @param string $currency  Currency code being queried
		 * @return string
		 */
		public function maybe_switch_currency_symbol( string $symbol, string $currency ): string {
			$country = $this->get_active_country();
			if ( $country === '' ) {
				return $symbol;
			}

			// Only override when the queried currency matches the active Nordic currency
			if ( $currency !== self::NORDIC_COUNTRIES[ $country ]['currency'] ) {
				return $symbol;
			}

			return self::NORDIC_COUNTRIES[ $country ]['symbol'];
		}

		/**
		 * Adjust decimal precision in wc_price() calls for Nordic visitors.
		 *
		 * @param array $args  wc_price() argument array
		 * @return array
		 */
		public function maybe_adjust_price_args( array $args ): array {
			$country = $this->get_active_country();
			if ( $country === '' ) {
				return $args;
			}

			$info     = self::NORDIC_COUNTRIES[ $country ];
			$settings = $this->get_settings();

			if ( ( $settings['round_prices'] ?? 'yes' ) === 'yes' ) {
				$args['decimals'] = (int) ( $info['decimals'] ?? 0 );
			}

			return $args;
		}

		/* ═══════════════════════════════════════════════════════════
		 * AJAX: Manual Country Override
		 * ═══════════════════════════════════════════════════════════ */

		public function handle_set_country_ajax(): void {
			$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
			if ( ! wp_verify_nonce( $nonce, 'nvcc_nordic_set_country' ) ) {
				wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
			}

			$country = isset( $_POST['country'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['country'] ) ) ) : '';

			// 'SE' = reset to store default; anything else must be a supported Nordic country
			if ( $country !== 'SE' && ! isset( self::NORDIC_COUNTRIES[ $country ] ) ) {
				wp_send_json_error( [ 'message' => 'Invalid country code.' ], 400 );
			}

			// Persist to WC session
			if ( function_exists( 'WC' ) && WC()->session instanceof \WC_Session ) {
				WC()->session->set( 'nvcc_country_override', $country );
			}

			// Persist to cookie (30-day TTL, httpOnly)
			if ( ! headers_sent() ) {
				setcookie(
					'nvcc_np_country',
					$country,
					time() + 30 * DAY_IN_SECONDS,
					COOKIEPATH,
					COOKIE_DOMAIN,
					is_ssl(),
					true
				);
			}

			// Reset cached resolution so the next page load re-evaluates
			$this->request_country = null;
			$this->resolution_done = false;

			wp_send_json_success( [ 'country' => $country, 'reload' => true ] );
		}

		/* ═══════════════════════════════════════════════════════════
		 * FRONTEND: Country Switcher Widget
		 * ═══════════════════════════════════════════════════════════ */

		public function maybe_render_country_switcher(): void {
			if ( is_admin() ) {
				return;
			}

			$settings = $this->get_settings();
			if ( ( $settings['allow_manual_switch'] ?? 'no' ) !== 'yes' ) {
				return;
			}

			// Build option list: always include Sweden as "default"
			$options = [
				'SE' => [ 'label' => 'Sverige', 'currency' => 'SEK', 'flag' => '🇸🇪' ],
			];
			foreach ( self::NORDIC_COUNTRIES as $code => $info ) {
				$key = 'enabled_' . strtolower( $code );
				if ( ( $settings[ $key ] ?? 'yes' ) === 'yes' ) {
					$options[ $code ] = $info;
				}
			}

			if ( count( $options ) <= 1 ) {
				return; // Only Sweden — nothing to switch to
			}

			$current  = $this->resolve_visitor_country();
			$active   = isset( $options[ $current ] ) ? $current : 'SE';
			$nonce    = wp_create_nonce( 'nvcc_nordic_set_country' );
			$ajax_url = esc_js( admin_url( 'admin-ajax.php' ) );
			?>
			<style id="nvcc-np-sw-css">
				#nvcc-np-sw { position:fixed; bottom:20px; left:20px; z-index:99999; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; font-size:13px; line-height:1; }
				#nvcc-np-sw .sw-toggle { display:inline-flex; align-items:center; gap:6px; padding:8px 14px; background:#fff; border:1px solid #ddd; border-radius:30px; cursor:pointer; box-shadow:0 2px 8px rgba(0,0,0,.12); transition:box-shadow .2s; user-select:none; }
				#nvcc-np-sw .sw-toggle:hover { box-shadow:0 4px 14px rgba(0,0,0,.18); }
				#nvcc-np-sw .sw-dropdown { display:none; background:#fff; border:1px solid #ddd; border-radius:10px; overflow:hidden; box-shadow:0 4px 18px rgba(0,0,0,.15); margin-bottom:8px; min-width:180px; }
				#nvcc-np-sw .sw-dropdown.open { display:block; }
				#nvcc-np-sw .sw-opt { display:flex; align-items:center; gap:8px; padding:10px 16px; cursor:pointer; border-bottom:1px solid #f0f0f0; transition:background .12s; }
				#nvcc-np-sw .sw-opt:last-child { border-bottom:none; }
				#nvcc-np-sw .sw-opt:hover { background:#f5f5f5; }
				#nvcc-np-sw .sw-opt.active { background:#f5f5f5; font-weight:600; }
				#nvcc-np-sw .sw-curr { color:#999; font-size:11px; margin-left:auto; padding-left:12px; }
				#nvcc-np-sw.sw-loading { opacity:.6; pointer-events:none; }
			</style>

			<div id="nvcc-np-sw">
				<div class="sw-dropdown" id="nvcc-np-dropdown">
					<?php foreach ( $options as $code => $info ) : ?>
						<div class="sw-opt<?php echo $code === $active ? ' active' : ''; ?>" data-code="<?php echo esc_attr( $code ); ?>">
							<span><?php echo esc_html( $info['flag'] ); ?></span>
							<span><?php echo esc_html( $info['label'] ); ?></span>
							<span class="sw-curr"><?php echo esc_html( $info['currency'] ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="sw-toggle" id="nvcc-np-toggle" role="button" aria-haspopup="listbox" aria-label="<?php esc_attr_e( 'Switch country / currency', 'nv-commerce-core' ); ?>">
					<span id="nvcc-np-flag"><?php echo esc_html( $options[ $active ]['flag'] ); ?></span>
					<span id="nvcc-np-curr"><?php echo esc_html( $options[ $active ]['currency'] ); ?></span>
					<span style="font-size:9px; color:#bbb; margin-left:2px;">▲</span>
				</div>
			</div>

			<script>
			(function () {
				var sw       = document.getElementById('nvcc-np-sw');
				var toggle   = document.getElementById('nvcc-np-toggle');
				var dropdown = document.getElementById('nvcc-np-dropdown');

				toggle.addEventListener('click', function (e) {
					e.stopPropagation();
					dropdown.classList.toggle('open');
				});
				document.addEventListener('click', function () {
					dropdown.classList.remove('open');
				});

				dropdown.querySelectorAll('.sw-opt').forEach(function (el) {
					el.addEventListener('click', function () {
						var code = this.getAttribute('data-code');
						sw.classList.add('sw-loading');

						var fd = new FormData();
						fd.append('action',  'nvcc_nordic_set_country');
						fd.append('country', code);
						fd.append('nonce',   '<?php echo esc_js( $nonce ); ?>');

						fetch('<?php echo $ajax_url; ?>', {
							method: 'POST',
							body: fd,
							credentials: 'same-origin'
						})
						.then(function (r) { return r.json(); })
						.then(function (j) {
							if (j.success) {
								window.location.reload();
							} else {
								sw.classList.remove('sw-loading');
							}
						})
						.catch(function () {
							sw.classList.remove('sw-loading');
						});
					});
				});
			})();
			</script>
			<?php
		}

		/* ═══════════════════════════════════════════════════════════
		 * HELPERS
		 * ═══════════════════════════════════════════════════════════ */

		/**
		 * Retrieve the stored Nordic prices for a given product / variation ID.
		 *
		 * @param  int   $product_id
		 * @return array<string,string>  Keys = country codes, values = price strings ('' = not set)
		 */
		public function get_product_prices( int $product_id ): array {
			$raw  = get_post_meta( $product_id, self::META_KEY, true );
			$data = is_array( $raw ) ? $raw : [];

			foreach ( array_keys( self::NORDIC_COUNTRIES ) as $code ) {
				if ( ! isset( $data[ $code ] ) ) {
					$data[ $code ] = '';
				}
			}

			return $data;
		}

		public function get_settings(): array {
			$defaults = [
				'enabled_no'          => 'yes',
				'enabled_dk'          => 'yes',
				'enabled_fi'          => 'yes',
				'detection_method'    => 'geolocation',
				'allow_manual_switch' => 'no',
				'round_prices'        => 'yes',
			];

			$saved = get_option( self::OPTION_KEY, [] );
			return wp_parse_args( is_array( $saved ) ? $saved : [], $defaults );
		}

		/**
		 * Expose country definitions for external use (theme / other plugins).
		 *
		 * @return array<string, array>
		 */
		public static function get_supported_countries(): array {
			return self::NORDIC_COUNTRIES;
		}
	}
}
