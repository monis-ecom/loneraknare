(function ($) {
  "use strict";

  if (!window.NVSmartUpsell) {
    return;
  }

  var state = {
    payload: null,
    loading: false,
    queued: false,
    debounceTimer: null,
    initDone: false
  };

  function toArray(list) {
    return Array.prototype.slice.call(list || []);
  }

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str == null ? "" : String(str);
    return div.innerHTML;
  }

  function decodeHtmlEntities(str) {
    if (!str) return "";
    var div = document.createElement("div");
    div.innerHTML = String(str);
    return div.textContent || div.innerText || "";
  }

  function queueRefresh(delay) {
    var wait = typeof delay === "number" ? delay : 120;
    if (state.debounceTimer) {
      clearTimeout(state.debounceTimer);
    }
    state.debounceTimer = setTimeout(function () {
      fetchData();
    }, wait);
  }

  function isCheckoutPage() {
    return document.body && (
      document.body.classList.contains("woocommerce-checkout") ||
      !!document.querySelector("form.checkout.woocommerce-checkout")
    );
  }

  function isVisibleElement(el) {
    if (!el || !el.isConnected) {
      return false;
    }

    var rect = el.getBoundingClientRect();
    var style = window.getComputedStyle ? window.getComputedStyle(el) : null;

    return rect.width > 0 &&
      rect.height > 0 &&
      (!style || (style.display !== "none" && style.visibility !== "hidden"));
  }

  function isHiddenKustomForm(el) {
    return !!(el && el.closest("#kco-wc-form, [aria-hidden='true']"));
  }

  function findVisibleCandidate(selector) {
    var candidates = toArray(document.querySelectorAll(selector));

    for (var i = 0; i < candidates.length; i++) {
      if (!isHiddenKustomForm(candidates[i]) && isVisibleElement(candidates[i])) {
        return candidates[i];
      }
    }

    return null;
  }

  function getCheckoutPlacementAnchor() {
    var kcoReview = document.getElementById("kco-order-review");
    if (kcoReview && isVisibleElement(kcoReview)) {
      return {
        parent: kcoReview,
        before: kcoReview.querySelector(".woocommerce-checkout-review-order-table") || kcoReview.firstChild
      };
    }

    var customerDetails = findVisibleCandidate("#customer_details");
    if (customerDetails && customerDetails.parentNode) {
      return {
        parent: customerDetails.parentNode,
        before: customerDetails
      };
    }

    var billingFields = findVisibleCandidate(".woocommerce-billing-fields");
    if (billingFields && billingFields.parentNode) {
      return {
        parent: billingFields.parentNode,
        before: billingFields
      };
    }

    var orderReview = findVisibleCandidate("#order_review, .woocommerce-checkout-review-order");
    if (orderReview && orderReview.parentNode) {
      return {
        parent: orderReview.parentNode,
        before: orderReview
      };
    }

    var checkoutForm = findVisibleCandidate("form.checkout.woocommerce-checkout");
    if (checkoutForm) {
      return {
        parent: checkoutForm,
        before: checkoutForm.firstChild
      };
    }

    return null;
  }

  function chooseCheckoutMount(mounts) {
    var renderedOutsideTables = mounts.filter(function (mount) {
      return mount.querySelector(".nv-upsell-wrap") && !mount.closest(".woocommerce-checkout-review-order-table");
    });

    if (renderedOutsideTables.length) {
      return renderedOutsideTables[0];
    }

    var positioned = mounts.filter(function (mount) {
      return mount.dataset.nvSmartUpsellPosition === "checkout-top";
    });

    if (positioned.length) {
      return positioned[0];
    }

    var outsideTables = mounts.filter(function (mount) {
      return !mount.closest(".woocommerce-checkout-review-order-table");
    });

    if (outsideTables.length) {
      return outsideTables[0];
    }

    return mounts[0] || null;
  }

  function dedupeCheckoutMounts() {
    var mounts = toArray(document.querySelectorAll("#nv-smart-upsell-checkout"));
    if (!mounts.length) {
      return null;
    }

    var keep = chooseCheckoutMount(mounts);
    mounts.forEach(function (mount) {
      if (mount !== keep) {
        mount.remove();
      }
    });

    return keep;
  }

  function placeCheckoutMount(mount) {
    if (!mount || !isCheckoutPage()) {
      return mount;
    }

    var anchor = getCheckoutPlacementAnchor();
    if (!anchor || !anchor.parent) {
      return mount;
    }

    if (anchor.parent === mount || mount.contains(anchor.parent)) {
      return mount;
    }

    if (anchor.before === mount) {
      mount.dataset.nvMoved = "1";
      mount.dataset.nvSmartUpsellPosition = "checkout-top";
      return mount;
    }

    if (mount.parentNode !== anchor.parent || mount.nextSibling !== anchor.before) {
      anchor.parent.insertBefore(mount, anchor.before || null);
    }

    mount.dataset.nvMoved = "1";
    mount.dataset.nvSmartUpsellPosition = "checkout-top";

    return mount;
  }

  function maintainCheckoutMount() {
    if (window.NVSmartUpsell.enabledCheckout !== "yes") {
      return null;
    }

    return placeCheckoutMount(dedupeCheckoutMounts());
  }

  function getCheckoutMount() {
    return maintainCheckoutMount();
  }

  function getSideCartMount() {
    if (window.NVSmartUpsell.enabledSidecart !== "yes") {
      return null;
    }

    var sideCart = document.getElementById("nvSideCart") || document.getElementById("nv-side-cart");
    if (!sideCart) {
      return null;
    }
    var sideCartBody = sideCart.querySelector(".nv-side-cart-body") || sideCart;

    var mount = document.getElementById("nv-smart-upsell-sidecart");
    if (!mount) {
      mount = document.createElement("div");
      mount.id = "nv-smart-upsell-sidecart";
      mount.className = "nv-smart-upsell nv-smart-upsell--sidecart";
      mount.dataset.context = "sidecart";

      var items = sideCartBody.querySelector("#nvSideCartItems, .nv-side-cart-items");
      if (items) {
        items.insertAdjacentElement("afterend", mount);
      } else {
        sideCartBody.appendChild(mount);
      }
    }
    return mount;
  }

  function normalizePriceMarkup(priceHtml) {
    if (!priceHtml) return "";
    return String(priceHtml)
      // Remove hidden accessibility helper text from WooCommerce markup.
      .replace(/<span[^>]*class=(["'])screen-reader-text\1[^>]*>[\s\S]*?<\/span>/gi, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function buildVariationSelectMarkup(product, selectedVariationId) {
    var variations = Array.isArray(product.variations) ? product.variations : [];
    if (variations.length <= 1) {
      return "";
    }

    var label = escapeHtml(window.NVSmartUpsell.strings.selectVariation || "Välj variant");
    var options = variations.map(function (variation) {
      var variationId = Number(variation.id || 0);
      var selectedAttr = variationId === selectedVariationId ? ' selected="selected"' : "";
      var optionLabel = escapeHtml(variation.label || "");
      var optionPrice = escapeHtml(variation.priceText || "");
      var optionPriceHtml = escapeHtml(normalizePriceMarkup(variation.priceHtml || variation.priceText || ""));
      return '<option value="' + variationId + '"' + selectedAttr + ' data-price="' + optionPrice + '" data-price-html="' + optionPriceHtml + '">' + optionLabel + "</option>";
    }).join("");

    return (
      '<label class="nv-upsell-variation-wrap">' +
        '<span class="nv-upsell-variation-label">' + label + "</span>" +
        '<select class="nv-upsell-variation-select" aria-label="' + label + '">' +
          options +
        "</select>" +
      "</label>"
    );
  }

  function productCardMarkup(product, context) {
    var compact = context === "sidecart";
    var img = product.image || "";
    var name = escapeHtml(product.name || "");
    var productId = Number(product.productId || 0);
    var selectedVariationId = Number(product.variationId || 0);
    var isVariable = !!product.isVariable && Array.isArray(product.variations) && product.variations.length > 0;

    var priceMarkup = isVariable
      ? normalizePriceMarkup(product.selectedVariationPriceHtml || product.selectedVariationPriceText || "")
      : normalizePriceMarkup(product.priceHtml || "");

    var badge = String(product.badge || "").toLowerCase();
    var badgeLabel = "";
    if (badge === "popular") {
      badgeLabel = window.NVSmartUpsell.strings.badgePopular || "Populär";
    } else if (badge === "new") {
      badgeLabel = window.NVSmartUpsell.strings.badgeNew || "Ny";
    }
    var badgeHtml = badgeLabel
      ? '<span class="nv-upsell-badge nv-upsell-badge--' + badge + '">' + escapeHtml(badgeLabel) + "</span>"
      : "";

    var variationSelectHtml = buildVariationSelectMarkup(product, selectedVariationId);
    var variableClass = isVariable ? " nv-upsell-price--variable" : "";

    return (
      '<article class="nv-upsell-card' + (compact ? " is-compact" : "") + '" role="listitem">' +
        '<a class="nv-upsell-image-wrap" href="' + escapeHtml(product.url || "#") + '">' +
          '<img class="nv-upsell-image" src="' + escapeHtml(img) + '" alt="' + name + '" loading="lazy" decoding="async" />' +
        "</a>" +
        '<div class="nv-upsell-content">' +
          badgeHtml +
          '<div class="nv-upsell-name">' + name + "</div>" +
          '<div class="nv-upsell-price' + variableClass + '">' + priceMarkup + "</div>" +
          variationSelectHtml +
          '<button type="button" class="nv-upsell-btn" data-product-id="' + productId + '" data-variation-id="' + selectedVariationId + '">' +
            escapeHtml(window.NVSmartUpsell.strings.add || "Lägg till") +
          "</button>" +
        "</div>" +
      "</article>"
    );
  }

  function renderMount(mount, context) {
    if (!mount) return;
    var payload = state.payload || {};
    var products = Array.isArray(payload.products) ? payload.products : [];

    if (!products.length) {
      mount.innerHTML = "";
      return;
    }

    var cards = products.map(function (p) {
      return productCardMarkup(p, context);
    }).join("");

    var headline = escapeHtml(payload.headline || "");
    mount.innerHTML =
      '<div class="nv-upsell-wrap ' + (context === "sidecart" ? "is-sidecart" : "is-checkout") + '">' +
        '<div class="nv-upsell-title" role="heading" aria-level="3">' + headline + "</div>" +
        '<div class="nv-upsell-track" role="list">' + cards + "</div>" +
        '<div class="nv-upsell-carousel-nav">' +
          '<div class="nv-upsell-dots" aria-hidden="true"></div>' +
        "</div>" +
      "</div>";

    bindMountInteractions(mount);

    if (context === "checkout") {
      placeCheckoutMount(mount);
    }
  }

  function renderAll() {
    if (!state.payload) return;

    if (window.NVSmartUpsell.enabledCheckout === "yes") {
      renderMount(getCheckoutMount(), "checkout");
    }
    if (window.NVSmartUpsell.enabledSidecart === "yes") {
      renderMount(getSideCartMount(), "sidecart");
    }
  }

  function triggerWooRefresh() {
    $(document.body).trigger("wc_fragment_refresh");
    $(document.body).trigger("update_checkout");
    $(document.body).trigger("updated_wc_div");

    if (window.NV_SIDE_CART && typeof window.NV_SIDE_CART.updateCartFromWooCommerce === "function") {
      setTimeout(function () {
        window.NV_SIDE_CART.updateCartFromWooCommerce();
      }, 180);
    }
  }

  function addToCart(btn, productId, variationId) {
    if (!productId) return;

    btn.disabled = true;
    btn.textContent = window.NVSmartUpsell.strings.adding || "Lägger till...";

    $.ajax({
      url: window.NVSmartUpsell.ajaxUrl,
      type: "POST",
      dataType: "json",
      data: {
        action: "nv_smart_upsell_add",
        nonce: window.NVSmartUpsell.nonce,
        product_id: productId,
        variation_id: variationId || 0,
        quantity: 1
      }
    })
      .done(function (res) {
        if (res && res.success) {
          btn.textContent = window.NVSmartUpsell.strings.added || "Tillagd";
          triggerWooRefresh();
          fetchData();
        } else {
          btn.textContent = window.NVSmartUpsell.strings.error || "Fel - försök igen";
        }
      })
      .fail(function () {
        btn.textContent = window.NVSmartUpsell.strings.error || "Fel - försök igen";
      })
      .always(function () {
        setTimeout(function () {
          btn.disabled = false;
          btn.textContent = window.NVSmartUpsell.strings.add || "Lägg till";
        }, 1200);
      });
  }

  function bindButtons(scope) {
    var buttons = scope.querySelectorAll(".nv-upsell-btn");
    buttons.forEach(function (btn) {
      if (btn.dataset.bound === "1") return;
      btn.dataset.bound = "1";
      btn.addEventListener("click", function () {
        var pid = parseInt(btn.getAttribute("data-product-id"), 10) || 0;
        var vid = parseInt(btn.getAttribute("data-variation-id"), 10) || 0;
        addToCart(btn, pid, vid);
      });
    });
  }

  function bindVariationSelectors(scope) {
    var selects = scope.querySelectorAll(".nv-upsell-variation-select");
    selects.forEach(function (select) {
      if (select.dataset.bound === "1") return;
      select.dataset.bound = "1";

      select.addEventListener("change", function () {
        var card = select.closest(".nv-upsell-card");
        if (!card) return;

        var btn = card.querySelector(".nv-upsell-btn");
        var price = card.querySelector(".nv-upsell-price--variable");
        var option = select.options[select.selectedIndex];
        var variationId = parseInt(select.value, 10) || 0;
        var selectedPrice = option ? option.getAttribute("data-price") || "" : "";
        var selectedPriceHtml = option ? decodeHtmlEntities(option.getAttribute("data-price-html") || "") : "";

        if (btn) {
          btn.setAttribute("data-variation-id", String(variationId));
        }
        if (price) {
          if (selectedPriceHtml) {
            price.innerHTML = normalizePriceMarkup(selectedPriceHtml);
          } else {
            price.textContent = selectedPrice;
          }
        }
      });
    });
  }

  function setupCarousel(scope) {
    var track = scope.querySelector(".nv-upsell-track");
    var nav = scope.querySelector(".nv-upsell-carousel-nav");
    var dotsWrap = scope.querySelector(".nv-upsell-dots");
    var cards = track ? track.querySelectorAll(".nv-upsell-card") : [];
    var isLockedSingleCard = scope.id === "nv-smart-upsell-checkout" || scope.id === "nv-smart-upsell-sidecart";

    if (!track || !nav || !dotsWrap) {
      return;
    }

    if (isLockedSingleCard) {
      track.style.display = "flex";
      track.style.gap = "8px";
      track.style.overflowX = "auto";
      track.style.overflowY = "hidden";
      track.style.scrollSnapType = "x mandatory";

      Array.prototype.forEach.call(cards, function (card) {
        card.style.flex = "0 0 100%";
        card.style.width = "100%";
        card.style.maxWidth = "100%";
        card.style.minWidth = "100%";
        card.style.scrollSnapAlign = "start";
      });
    }

    if (!cards.length || cards.length <= 1) {
      nav.classList.add("is-hidden");
      return;
    }

    nav.classList.remove("is-hidden");

    dotsWrap.innerHTML = "";
    Array.prototype.forEach.call(cards, function (_card, index) {
      var dot = document.createElement("button");
      dot.type = "button";
      dot.className = "nv-upsell-dot" + (index === 0 ? " is-active" : "");
      dot.setAttribute("data-index", String(index));
      dot.setAttribute("aria-label", "Slide " + (index + 1));
      dotsWrap.appendChild(dot);
    });

    function getActiveIndex() {
      var scrollLeft = track.scrollLeft;
      var closestIndex = 0;
      var closestDistance = Number.POSITIVE_INFINITY;

      Array.prototype.forEach.call(cards, function (card, index) {
        var distance = Math.abs(card.offsetLeft - scrollLeft);
        if (distance < closestDistance) {
          closestDistance = distance;
          closestIndex = index;
        }
      });

      return closestIndex;
    }

    function setActive(index) {
      var dots = dotsWrap.querySelectorAll(".nv-upsell-dot");
      dots.forEach(function (dot, dotIndex) {
        dot.classList.toggle("is-active", dotIndex === index);
      });
    }

    function scrollToIndex(index) {
      var safeIndex = Math.max(0, Math.min(cards.length - 1, index));
      var target = cards[safeIndex];
      if (!target) return;
      track.scrollTo({
        left: target.offsetLeft,
        behavior: "smooth"
      });
    }

    var ticking = false;
    track.addEventListener("scroll", function () {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        ticking = false;
        setActive(getActiveIndex());
      });
    });

    dotsWrap.addEventListener("click", function (event) {
      var target = event.target;
      if (!target || !target.classList.contains("nv-upsell-dot")) {
        return;
      }
      var index = parseInt(target.getAttribute("data-index"), 10) || 0;
      scrollToIndex(index);
    });

    setActive(0);
  }

  function bindMountInteractions(scope) {
    bindButtons(scope);
    bindVariationSelectors(scope);
    setupCarousel(scope);
  }

  function fetchData() {
    if (state.loading) {
      state.queued = true;
      return;
    }

    state.loading = true;

    $.ajax({
      url: window.NVSmartUpsell.ajaxUrl,
      type: "POST",
      dataType: "json",
      data: {
        action: "nv_smart_upsell_data",
        nonce: window.NVSmartUpsell.nonce
      }
    })
      .done(function (res) {
        if (!res || !res.success) return;
        state.payload = res.data || null;
        renderAll();
      })
      .always(function () {
        state.loading = false;
        if (state.queued) {
          state.queued = false;
          fetchData();
        }
      });
  }

  function bindGlobalEvents() {
    $(document.body).on(
      "updated_checkout updated_wc_div wc_fragments_refreshed wc_fragments_loaded added_to_cart removed_from_cart",
      function () {
        maintainCheckoutMount();
        queueRefresh(120);
        setTimeout(maintainCheckoutMount, 240);
      }
    );

    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) {
        queueRefresh(100);
      }
    });
  }

  function observeCheckoutMount() {
    if (window.NVSmartUpsell.enabledCheckout !== "yes" || typeof MutationObserver === "undefined") {
      return;
    }

    var target = document.getElementById("nv-checkout-minimal-v2") ||
      document.querySelector("form.checkout.woocommerce-checkout") ||
      document.body;

    if (!target) {
      return;
    }

    var placementTimer = null;
    var observer = new MutationObserver(function () {
      if (placementTimer) {
        clearTimeout(placementTimer);
      }
      placementTimer = setTimeout(function () {
        maintainCheckoutMount();
      }, 80);
    });

    observer.observe(target, {
      childList: true,
      subtree: true
    });
  }

  function observeSideCartOpen() {
    var sideCart = document.getElementById("nvSideCart") || document.getElementById("nv-side-cart");
    if (!sideCart) {
      return;
    }

    document.addEventListener("nv:sidecart:open", function () {
      queueRefresh(60);
    });

    if (typeof MutationObserver !== "undefined") {
      var observer = new MutationObserver(function () {
        var isOpen = sideCart.classList.contains("active") || document.body.classList.contains("nv-side-cart-open");
        if (isOpen) {
          queueRefresh(80);
        }
      });

      observer.observe(sideCart, {
        attributes: true,
        attributeFilter: ["class"]
      });
    }
  }

  function init() {
    if (state.initDone) return;
    state.initDone = true;

    bindGlobalEvents();
    observeSideCartOpen();
    observeCheckoutMount();
    maintainCheckoutMount();
    fetchData();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})(jQuery);
