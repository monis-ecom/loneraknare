(function ($) {
  "use strict";

  if (!window.NVCommerceCore || !$) {
    return;
  }

  function setStatus(container, message, isError) {
    var status = container.querySelector(".nvcc-bundle__status");
    if (!status) return;
    status.textContent = message || "";
    status.classList.toggle("is-error", !!isError);
  }

  function formatCurrency(amount) {
    var value = Number(amount || 0);
    var locale = NVCommerceCore.locale || "sv-SE";
    var code = NVCommerceCore.currencyCode || "SEK";

    try {
      return new Intl.NumberFormat(locale, {
        style: "currency",
        currency: code,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(value);
    } catch (e) {
      return value.toFixed(2) + " " + code;
    }
  }

  function parseNumber(input, fallback) {
    var num = parseFloat(input);
    return Number.isFinite(num) ? num : (fallback || 0);
  }

  function setBonusPanelVisibility(panel, isVisible) {
    if (!panel) return;
    var bonusRoot = panel.closest(".nvcc-bonus");

    if (isVisible) {
      panel.hidden = false;
      panel.classList.add("is-open");
      panel.style.removeProperty("display");
      if (bonusRoot) {
        bonusRoot.classList.add("is-expanded");
      }
      return;
    }

    panel.hidden = true;
    panel.classList.remove("is-open");
    panel.style.setProperty("display", "none", "important");
    if (bonusRoot) {
      bonusRoot.classList.remove("is-expanded");
    }
  }

  function getSelectedDeal(container) {
    var checked = container.querySelector(".nvcc-deal input[type='radio']:checked");
    return checked ? checked.closest(".nvcc-deal") : null;
  }

  function updateDealSelection(container, selectedDeal) {
    var deals = container.querySelectorAll(".nvcc-deal");
    deals.forEach(function (deal) {
      var isActive = deal === selectedDeal;
      deal.classList.toggle("is-selected", isActive);
      var mix = deal.querySelector(".nvcc-deal__mix");
      if (mix) {
        mix.hidden = !isActive;
      }

      if (!isActive) {
        deal.querySelectorAll(".nvcc-bonus__panel").forEach(function (panel) {
          setBonusPanelVisibility(panel, false);
        });

        deal.querySelectorAll(".nvcc-bonus__toggle").forEach(function (toggle) {
          toggle.setAttribute("aria-expanded", "false");
          var closeText = toggle.getAttribute("data-close-text") || "+ Visa alla";
          toggle.textContent = closeText;
        });
      }
    });
  }

  function updateDealTotals(deal) {
    if (!deal) return;

    var discountPct = parseNumber(deal.getAttribute("data-discount"), 0);
    var discountMode = String(deal.getAttribute("data-discount-mode") || "auto");
    var discountValue = parseNumber(deal.getAttribute("data-discount-value"), 0);
    var selects = deal.querySelectorAll(".nvcc-deal__select");
    if (!selects.length) return;

    var regularTotal = 0;
    var currentTotal = 0;

    selects.forEach(function (select) {
      var option = select.options[select.selectedIndex];
      if (!option) return;

      var price = parseNumber(option.getAttribute("data-price"), 0);
      var regular = parseNumber(option.getAttribute("data-regular"), price);

      currentTotal += price;
      regularTotal += regular;
    });

    var discountedTotal = currentTotal;
    if (discountMode === "percentage" || discountMode === "auto") {
      if (discountPct > 0) {
        discountedTotal = currentTotal * (1 - discountPct / 100);
      }
    } else if (discountMode === "fixed_amount") {
      discountedTotal = Math.max(0, currentTotal - discountValue);
    } else if (discountMode === "fixed_price") {
      discountedTotal = discountValue > 0 ? Math.min(currentTotal, discountValue) : currentTotal;
    }

    var currentEl = deal.querySelector("[data-price-current]");
    var regularEl = deal.querySelector("[data-price-regular]");
    var savingsEl = deal.querySelector("[data-savings]");

    if (currentEl) {
      currentEl.textContent = formatCurrency(discountedTotal);
    }

    if (regularEl) {
      regularEl.textContent = formatCurrency(regularTotal);
      regularEl.style.display = regularTotal > discountedTotal ? "inline" : "none";
    }

    if (savingsEl) {
      var savingsAmount = regularTotal - discountedTotal;
      if (savingsAmount > 0.009) {
        savingsEl.textContent = "Du sparar " + formatCurrency(savingsAmount);
        savingsEl.style.display = "inline";
      } else {
        savingsEl.style.display = "none";
      }
    }
  }

  function updateRowThumb(select) {
    if (!select) return;

    var row = select.closest(".nvcc-deal__mix-row");
    if (!row) return;

    var thumb = row.querySelector(".nvcc-deal__thumb");
    if (!thumb) return;

    var option = select.options[select.selectedIndex];
    if (!option) return;

    var thumbUrl = option.getAttribute("data-thumb") || "";
    if (!thumbUrl) return;

    if (thumb.getAttribute("src") !== thumbUrl) {
      thumb.setAttribute("src", thumbUrl);
    }
  }

  function collectDealItems(container) {
    var selectedDeal = getSelectedDeal(container);
    if (!selectedDeal) {
      return { error: NVCommerceCore.strings.selectQty || "Välj minst en variant." };
    }

    var selects = selectedDeal.querySelectorAll(".nvcc-deal__mix .nvcc-deal__select");
    if (!selects.length) {
      return { error: NVCommerceCore.strings.selectQty || "Välj minst en variant." };
    }

    var itemMap = {};

    for (var i = 0; i < selects.length; i += 1) {
      var option = selects[i].options[selects[i].selectedIndex];
      var itemType = option ? String(option.getAttribute("data-type") || "variation") : "variation";
      var itemId = parseInt(selects[i].value, 10) || 0;
      if (itemId <= 0) {
        return { error: NVCommerceCore.strings.selectAll || "Välj variant i alla rader först." };
      }

      var itemKey = itemType + ":" + itemId;
      if (!itemMap[itemKey]) {
        itemMap[itemKey] = {
          type: itemType,
          id: itemId,
          qty: 0
        };
      }
      itemMap[itemKey].qty += 1;
    }

    var items = Object.keys(itemMap).map(function (key) {
      var item = itemMap[key];
      if (item.type === "simple") {
        return {
          product_id: item.id,
          qty: item.qty
        };
      }

      return {
        variation_id: item.id,
        qty: item.qty
      };
    });

    var dealTitleNode = selectedDeal.querySelector(".nvcc-deal__title");
    var dealTitle = dealTitleNode ? String(dealTitleNode.textContent || "").trim() : "";

    return {
      items: items,
      deal: {
        mode: String(selectedDeal.getAttribute("data-discount-mode") || "auto"),
        value: parseNumber(selectedDeal.getAttribute("data-discount-value"), 0),
        title: dealTitle
      }
    };
  }

  function collectLegacyRowItems(container) {
    var rows = container.querySelectorAll(".nvcc-bundle__row");
    var items = [];

    rows.forEach(function (row) {
      var variationId = parseInt(row.getAttribute("data-variation-id"), 10) || 0;
      var qtyInput = row.querySelector(".nvcc-bundle__qty");
      var qty = qtyInput ? Math.max(0, parseInt(qtyInput.value, 10) || 0) : 0;

      if (variationId > 0 && qty > 0) {
        items.push({ variation_id: variationId, qty: qty });
      }
    });

    return items;
  }

  function triggerWooRefresh() {
    $(document.body).trigger("wc_fragment_refresh");
    $(document.body).trigger("update_checkout");
    $(document.body).trigger("updated_wc_div");

    if (window.NV_SIDE_CART && typeof window.NV_SIDE_CART.updateCartFromWooCommerce === "function") {
      setTimeout(function () {
        window.NV_SIDE_CART.updateCartFromWooCommerce();
        if (typeof window.NV_SIDE_CART.open === "function") {
          window.NV_SIDE_CART.open();
        }
      }, 220);
    }
  }

  function getErrorMessageFromResponse(response) {
    return (response && response.data && response.data.message) || (NVCommerceCore.strings.error || "Något gick fel. Försök igen.");
  }

  function redirectToBuyNowTarget() {
    var buyNow = NVCommerceCore.buyNow || {};
    var target = String(buyNow.redirectUrl || "");

    if (!target) {
      target = "/checkout/";
    }

    window.location.assign(target);
  }

  function postBundleItems(container, button, productId, items, options) {
    var opts = options || {};
    var shouldRedirect = !!opts.redirectAfterAdd;
    var dealMeta = opts.deal && typeof opts.deal === "object" ? opts.deal : null;
    var originalLabel = button.textContent || (NVCommerceCore.strings.add || "Lägg till paket");
    button.disabled = true;
    button.textContent = NVCommerceCore.strings.adding || "Lägger till...";
    setStatus(container, "", false);

    var requestData = {
      action: "nvcc_add_variation_bundle",
      nonce: NVCommerceCore.nonce,
      product_id: productId,
      items: items
    };
    if (dealMeta) {
      requestData.deal = dealMeta;
    }
    var hasRetriedNonce = false;

    function releaseButton() {
      setTimeout(function () {
        button.disabled = false;
        button.textContent = originalLabel;
      }, 900);
    }

    function sendRequest() {
      $.ajax({
        url: NVCommerceCore.ajaxUrl,
        type: "POST",
        dataType: "json",
        data: requestData
      })
        .done(function (response) {
          if (response && response.success) {
            var successMessage = (response.data && response.data.message) || (NVCommerceCore.strings.added || "Tillagd!");
            if (shouldRedirect) {
              successMessage = NVCommerceCore.strings.buyNowAdded || "Tillagd – skickar till kassan...";
            }

            setStatus(container, successMessage, false);
            triggerWooRefresh();

            if (shouldRedirect) {
              setTimeout(function () {
                redirectToBuyNowTarget();
              }, 140);
            }
          } else {
            setStatus(container, getErrorMessageFromResponse(response), true);
          }

          releaseButton();
        })
        .fail(function (jqXHR) {
          var responseJson = jqXHR && jqXHR.responseJSON ? jqXHR.responseJSON : null;
          var nonceFromServer =
            responseJson &&
            responseJson.data &&
            responseJson.data.code === "invalid_nonce" &&
            responseJson.data.nonce
              ? responseJson.data.nonce
              : "";

          if (!hasRetriedNonce && nonceFromServer) {
            hasRetriedNonce = true;
            NVCommerceCore.nonce = nonceFromServer;
            requestData.nonce = nonceFromServer;
            sendRequest();
            return;
          }

          setStatus(container, getErrorMessageFromResponse(responseJson), true);
          releaseButton();
        });
    }

    sendRequest();
  }

  function bindBundle(container) {
    if (container.dataset.bound === "1") {
      return;
    }

    container.dataset.bound = "1";

    var button = container.querySelector(".nvcc-bundle__submit");
    if (!button) return;
    var buyNowButton = container.querySelector(".nvcc-bundle__buy-now");
    var buyNowEnabled = !!(NVCommerceCore.buyNow && NVCommerceCore.buyNow.enabled);

    var radios = container.querySelectorAll(".nvcc-deal input[type='radio']");
    var selects = container.querySelectorAll(".nvcc-deal__select");

    radios.forEach(function (radio) {
      radio.addEventListener("change", function () {
        var selectedDeal = this.closest(".nvcc-deal");
        if (!selectedDeal) return;
        updateDealSelection(container, selectedDeal);
      });
    });

    selects.forEach(function (select) {
      select.addEventListener("change", function () {
        var deal = this.closest(".nvcc-deal");
        updateRowThumb(this);
        updateDealTotals(deal);
      });

      updateRowThumb(select);
    });

    container.querySelectorAll(".nvcc-deal").forEach(updateDealTotals);

    container.querySelectorAll(".nvcc-bonus__toggle").forEach(function (toggle) {
      toggle.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        var controlsId = toggle.getAttribute("aria-controls") || "";
        if (!controlsId) return;

        var panel = container.querySelector("#" + controlsId);
        if (!panel) return;

        var expanded = toggle.getAttribute("aria-expanded") === "true";
        var openText = toggle.getAttribute("data-open-text") || "Visa färre ▲";
        var closeText = toggle.getAttribute("data-close-text") || "+ Visa alla";

        setBonusPanelVisibility(panel, !expanded);
        toggle.setAttribute("aria-expanded", expanded ? "false" : "true");
        toggle.textContent = expanded ? closeText : openText;
      });
    });

    container.querySelectorAll(".nvcc-bonus__panel").forEach(function (panel) {
      setBonusPanelVisibility(panel, false);
    });

    container.querySelectorAll(".nvcc-bonus__toggle").forEach(function (toggle) {
      toggle.setAttribute("aria-expanded", "false");
      var closeText = toggle.getAttribute("data-close-text") || "+ Visa alla";
      toggle.textContent = closeText;
    });

    var selectedDeal = getSelectedDeal(container);
    if (selectedDeal) {
      updateDealSelection(container, selectedDeal);
    }

    button.addEventListener("click", function () {
      var productId = parseInt(container.getAttribute("data-product-id"), 10) || 0;
      var items = [];

      if (container.classList.contains("nvcc-bundle--deals")) {
        var collected = collectDealItems(container);
        if (collected.error) {
          setStatus(container, collected.error, true);
          return;
        }
        items = collected.items || [];
        var dealMeta = collected.deal || null;
      } else {
        items = collectLegacyRowItems(container);
        var dealMeta = null;
      }

      if (!productId || !items.length) {
        setStatus(container, NVCommerceCore.strings.selectQty || "Välj minst en variant med antal över 0.", true);
        return;
      }

      postBundleItems(container, button, productId, items, { redirectAfterAdd: false, deal: dealMeta });
    });

    if (buyNowButton && buyNowEnabled) {
      buyNowButton.addEventListener("click", function () {
        var productId = parseInt(container.getAttribute("data-product-id"), 10) || 0;
        var items = [];

        if (container.classList.contains("nvcc-bundle--deals")) {
          var collected = collectDealItems(container);
          if (collected.error) {
            setStatus(container, collected.error, true);
            return;
          }
          items = collected.items || [];
          var dealMeta = collected.deal || null;
        } else {
          items = collectLegacyRowItems(container);
          var dealMeta = null;
        }

        if (!productId || !items.length) {
          setStatus(container, NVCommerceCore.strings.selectQty || "Välj minst en variant med antal över 0.", true);
          return;
        }

        postBundleItems(container, buyNowButton, productId, items, { redirectAfterAdd: true, deal: dealMeta });
      });
    }
  }

  function init() {
    document.querySelectorAll(".nvcc-bundle").forEach(bindBundle);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  $(document.body).on("updated_checkout wc_fragments_loaded wc_fragments_refreshed", function () {
    init();
  });
})(window.jQuery);
