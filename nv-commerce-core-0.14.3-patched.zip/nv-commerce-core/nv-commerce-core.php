<?php
/**
 * Plugin Name: AS Commerce Core
 * Description: Bulk discount tiers + Kaching-style mix & match bundle deals + Smart Upsell compatibility for Nordiska Varuhuset.
 * Version: 0.14.3
 * Author: Alpha Studio
 * Text Domain: nv-commerce-core
 * Plugin URI: https://alphaecom.org
 * Author URI: https://alphaecom.org
 * License: Proprietary
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('NVCC_VERSION')) {
    define('NVCC_VERSION', '0.14.3');
}
if (!defined('NVCC_PLUGIN_FILE')) {
    define('NVCC_PLUGIN_FILE', __FILE__);
}
if (!defined('NVCC_PLUGIN_DIR')) {
    define('NVCC_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('NVCC_PLUGIN_URL')) {
    define('NVCC_PLUGIN_URL', plugin_dir_url(__FILE__));
}

if (!function_exists('nvcc_get_legacy_core_file')) {
    function nvcc_get_legacy_core_file(): string {
        if (!class_exists('NV_Commerce_Core', false)) {
            return '';
        }

        try {
            $reflection = new ReflectionClass('NV_Commerce_Core');
            $file = (string) $reflection->getFileName();
        } catch (Throwable $e) {
            $file = '';
        }

        return $file;
    }
}

if (!function_exists('nvcc_remove_legacy_core_hooks')) {
    function nvcc_remove_legacy_core_hooks(): void {
        global $wp_filter;

        if (!is_array($wp_filter)) {
            return;
        }

        foreach ($wp_filter as $hook_name => $hook_object) {
            if (!is_object($hook_object) || !isset($hook_object->callbacks) || !is_array($hook_object->callbacks)) {
                continue;
            }

            foreach ($hook_object->callbacks as $priority => $callbacks) {
                if (!is_array($callbacks)) {
                    continue;
                }

                foreach ($callbacks as $callback) {
                    if (!isset($callback['function']) || !is_array($callback['function'])) {
                        continue;
                    }

                    $fn = $callback['function'];
                    if (!isset($fn[0], $fn[1]) || !is_object($fn[0])) {
                        continue;
                    }

                    $legacy_classes = [
                        'NV_Commerce_Core',
                        'Nestly_NVCC_Commerce_Core_Main',
                        'NVCC_Commerce_Core_Main',
                        'Nestly_NVCC_Smart_Upsell_Module',
                        'NVCC_Smart_Upsell_Module',
                    ];

                    if (!in_array(get_class($fn[0]), $legacy_classes, true)) {
                        continue;
                    }

                    remove_action((string) $hook_name, $fn, (int) $priority);
                    remove_filter((string) $hook_name, $fn, (int) $priority);
                }
            }
        }
    }
}

if (!function_exists('nvcc_find_runtime_instance')) {
    function nvcc_find_runtime_instance(): ?object {
        static $cached = null;
        if (is_object($cached) && method_exists($cached, 'shortcode_variation_bundle')) {
            return $cached;
        }

        $cached = null;

        if (
            isset($GLOBALS['nvcc_runtime_instance']) &&
            is_object($GLOBALS['nvcc_runtime_instance']) &&
            method_exists($GLOBALS['nvcc_runtime_instance'], 'shortcode_variation_bundle')
        ) {
            $cached = $GLOBALS['nvcc_runtime_instance'];
            return $cached;
        }

        global $wp_filter;
        if (!is_array($wp_filter)) {
            return null;
        }

        $hooks = [
            'init',
            'wp_enqueue_scripts',
            'woocommerce_after_add_to_cart_form',
            'nv_theme_bundle_widget',
            'woocommerce_cart_calculate_fees',
        ];

        foreach ($hooks as $hook_name) {
            if (
                !isset($wp_filter[$hook_name]) ||
                !is_object($wp_filter[$hook_name]) ||
                !isset($wp_filter[$hook_name]->callbacks) ||
                !is_array($wp_filter[$hook_name]->callbacks)
            ) {
                continue;
            }

            foreach ($wp_filter[$hook_name]->callbacks as $callbacks) {
                if (!is_array($callbacks)) {
                    continue;
                }

                foreach ($callbacks as $callback) {
                    if (!isset($callback['function']) || !is_array($callback['function'])) {
                        continue;
                    }

                    $fn = $callback['function'];
                    if (!isset($fn[0], $fn[1]) || !is_object($fn[0])) {
                        continue;
                    }

                    if (get_class($fn[0]) !== 'Nestly_NVCC_Commerce_Core_Runtime') {
                        continue;
                    }

                    if (!method_exists($fn[0], 'shortcode_variation_bundle')) {
                        continue;
                    }

                    $cached = $fn[0];
                    $GLOBALS['nvcc_runtime_instance'] = $cached;
                    return $cached;
                }
            }
        }

        return null;
    }
}

if (!function_exists('nvcc_shortcode_bridge_callback')) {
    function nvcc_shortcode_bridge_callback($atts = []): string {
        $runtime = nvcc_find_runtime_instance();
        if (!is_object($runtime) || !method_exists($runtime, 'shortcode_variation_bundle')) {
            return '';
        }

        try {
            $result = $runtime->shortcode_variation_bundle(is_array($atts) ? $atts : []);
        } catch (Throwable $e) {
            return '';
        }

        return is_string($result) ? $result : '';
    }
}

if (!function_exists('nvcc_register_shortcode_bridge_shortcodes')) {
    function nvcc_register_shortcode_bridge_shortcodes(): void {
        $runtime = nvcc_find_runtime_instance();
        if (is_object($runtime) && method_exists($runtime, 'register_shortcodes')) {
            $runtime->register_shortcodes();
        }

        if (!shortcode_exists('nvcc_variation_bundle')) {
            add_shortcode('nvcc_variation_bundle', 'nvcc_shortcode_bridge_callback');
        }
        if (!shortcode_exists('nvcc_bundle_widget')) {
            add_shortcode('nvcc_bundle_widget', 'nvcc_shortcode_bridge_callback');
        }
    }
}

add_action('init', 'nvcc_register_shortcode_bridge_shortcodes', 5);

add_action('plugins_loaded', static function (): void {
    nvcc_remove_legacy_core_hooks();
}, 9999);

if (!function_exists('nvcc_load_smart_upsell_module')) {
    function nvcc_load_smart_upsell_module(): void {
        $module_file = NVCC_PLUGIN_DIR . 'includes/class-nvcc-smart-upsell-module.php';
        if (file_exists($module_file)) {
            require_once $module_file;
        }
    }
}

if (!function_exists('nvcc_boot_smart_upsell_module_once')) {
    function nvcc_boot_smart_upsell_module_once(): void {
        if (!empty($GLOBALS['nvcc_smart_upsell_module_booted'])) {
            return;
        }

        $enabled = (bool) apply_filters('nvcc_enable_upsell_module', true);
        if (!$enabled) {
            return;
        }

        nvcc_load_smart_upsell_module();

        if (class_exists('Nestly_NVCC_Smart_Upsell_Runtime')) {
            $GLOBALS['nvcc_smart_upsell_module_booted'] = true;
            Nestly_NVCC_Smart_Upsell_Runtime::init();
            return;
        }

        if (class_exists('Nestly_NVCC_Smart_Upsell_Module')) {
            $GLOBALS['nvcc_smart_upsell_module_booted'] = true;
            Nestly_NVCC_Smart_Upsell_Module::init();
        }
    }
}

if (class_exists('Nestly_NVCC_Commerce_Core_Runtime', false)) {
    /**
     * Another loaded copy has already declared the runtime class.
     * Keep this plugin row functional and try to ensure one runtime instance exists.
     */
    add_filter('plugin_action_links_' . plugin_basename(__FILE__), static function (array $links): array {
        $core_url = admin_url('admin.php?page=nestly-commerce-core-settings');
        $upsell_url = admin_url('admin.php?page=nestly-smart-upsell-settings');

        array_unshift(
            $links,
            '<a href="' . esc_url($core_url) . '">' . esc_html__('Inställningar', 'nv-commerce-core') . '</a>'
        );
        $links[] = '<a href="' . esc_url($upsell_url) . '">' . esc_html__('Smart Upsell', 'nv-commerce-core') . '</a>';

        return $links;
    });

    add_action('plugins_loaded', static function (): void {
        $runtime = nvcc_find_runtime_instance();
        if (!is_object($runtime) && class_exists('Nestly_NVCC_Commerce_Core_Runtime')) {
            try {
                $runtime = new Nestly_NVCC_Commerce_Core_Runtime();
                $GLOBALS['nvcc_runtime_instance'] = $runtime;
            } catch (Throwable $e) {
                $runtime = null;
            }
        }

        if (is_object($runtime) && method_exists($runtime, 'register_shortcodes')) {
            $runtime->register_shortcodes();
        }
    }, 20);

    if (did_action('plugins_loaded')) {
        nvcc_boot_smart_upsell_module_once();
    } else {
        add_action('plugins_loaded', 'nvcc_boot_smart_upsell_module_once', 20);
    }

    return;
}

$nvcc_legacy_core_file = nvcc_get_legacy_core_file();
if ($nvcc_legacy_core_file !== '' && is_admin()) {
    add_action('admin_notices', static function () use ($nvcc_legacy_core_file): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        echo '<div class="notice notice-warning"><p>';
        echo 'NV Commerce Core: legacy class detected and disabled from <code>' . esc_html($nvcc_legacy_core_file) . '</code>.';
        echo '</p></div>';
    });
}

nvcc_load_smart_upsell_module();
require_once NVCC_PLUGIN_DIR . 'includes/class-nvcc-nordic-pricing-module.php';

final class Nestly_NVCC_Commerce_Core_Runtime {
    private const OPTION_KEY = 'nvcc_settings';
    private const CORE_MENU_SLUG = 'nestly-commerce-core-settings';
    private const SMART_UPSELL_MENU_SLUG = 'nestly-smart-upsell-settings';
    private const LEGACY_CORE_MENU_SLUG = 'nvcc-core-settings';
    private const LEGACY_SMART_UPSELL_MENU_SLUG = 'nvcc-smart-upsell-settings';
    private const MENU_POSITION = '56.14';
    private bool $bundle_assets_enqueued = false;
    private bool $bundle_hook_registered = false;
    private bool $bundle_hide_default_atc_style_printed = false;
    private array $rendered_bundle_product_ids = [];

    public function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('init', [$this, 'register_shortcodes'], 25);
        add_action('init', [$this, 'register_bundle_render_hook'], 20);
        add_filter('elementor/frontend/the_content', [$this, 'maybe_parse_elementor_bundle_shortcodes'], 20);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('elementor/preview/enqueue_styles', [$this, 'enqueue_elementor_preview_assets']);
        add_action('elementor/preview/enqueue_scripts', [$this, 'enqueue_elementor_preview_assets']);

        add_action('woocommerce_cart_calculate_fees', [$this, 'apply_bundle_custom_deal_discounts'], 15);
        add_action('woocommerce_cart_calculate_fees', [$this, 'apply_bulk_discount'], 20);

        add_action('wp_ajax_nvcc_add_variation_bundle', [$this, 'handle_bundle_ajax']);
        add_action('wp_ajax_nopriv_nvcc_add_variation_bundle', [$this, 'handle_bundle_ajax']);
        add_action('wp_ajax_nvcc_get_bundle_nonce', [$this, 'handle_bundle_nonce_refresh_ajax']);
        add_action('wp_ajax_nopriv_nvcc_get_bundle_nonce', [$this, 'handle_bundle_nonce_refresh_ajax']);
        add_action('wp_ajax_nvcc_search_admin_targets', [$this, 'handle_admin_target_search_ajax']);

        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'redirect_legacy_settings_pages']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_plugin_action_links']);

        add_action('woocommerce_before_add_to_cart_form', [$this, 'maybe_hide_default_add_to_cart'], 5);
        add_action('woocommerce_after_add_to_cart_button', [$this, 'render_buy_now_button'], 25);
        add_filter('woocommerce_add_to_cart_redirect', [$this, 'maybe_buy_now_redirect'], 99);
    }

    public function load_textdomain(): void {
        load_plugin_textdomain('nv-commerce-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function register_bundle_render_hook(): void {
        if ($this->bundle_hook_registered) {
            return;
        }

        $this->bundle_hook_registered = true;

        if ($this->should_render_bundle_in_theme_widget()) {
            add_action('nv_theme_bundle_widget', [$this, 'render_variation_mix_bundle'], 10, 1);
            return;
        }

        add_action('woocommerce_after_add_to_cart_form', [$this, 'render_variation_mix_bundle'], 30);
    }

    public function maybe_hide_default_add_to_cart(): void {
        $settings = $this->get_settings();
        if (($settings['enable_variation_bundle'] ?? 'no') !== 'yes') {
            return;
        }

        global $product;
        if (!$product instanceof WC_Product || !in_array($product->get_type(), ['simple', 'variable'], true)) {
            return;
        }

        $product_id = (int) $product->get_id();
        if ($product_id <= 0 || !$this->is_bundle_enabled_for_product($product_id)) {
            return;
        }

        if (!isset($this->rendered_bundle_product_ids[$product_id])) {
            return;
        }

        $this->print_hide_default_add_to_cart_style();
    }

    private function print_hide_default_add_to_cart_style(): void {
        if ($this->bundle_hide_default_atc_style_printed) {
            return;
        }

        $this->bundle_hide_default_atc_style_printed = true;
        echo '<style id="nvcc-hide-default-atc">.woocommerce div.product form.cart{display:none!important}.variations_form.cart{display:none!important}.single_add_to_cart_button{display:none!important}</style>';
    }

    public function register_shortcodes(): void {
        add_shortcode('nvcc_variation_bundle', [$this, 'shortcode_variation_bundle']);
        add_shortcode('nvcc_bundle_widget', [$this, 'shortcode_variation_bundle']);
    }

    public function shortcode_variation_bundle($atts = []): string {
        if (!class_exists('WooCommerce')) {
            return '';
        }

        $atts = shortcode_atts(
            [
                'product_id' => 0,
            ],
            is_array($atts) ? $atts : [],
            'nvcc_variation_bundle'
        );

        $resolved_product = null;
        $product_id = absint((string) ($atts['product_id'] ?? 0));

        if ($product_id > 0) {
            $candidate = wc_get_product($product_id);
            if ($candidate instanceof WC_Product) {
                $resolved_product = $candidate;
            }
        }

        if (!$resolved_product instanceof WC_Product && is_singular('product')) {
            $candidate = wc_get_product(get_the_ID());
            if ($candidate instanceof WC_Product) {
                $resolved_product = $candidate;
            }
        }

        if (!$resolved_product instanceof WC_Product) {
            global $product;
            if ($product instanceof WC_Product) {
                $resolved_product = $product;
            }
        }

        if (!$resolved_product instanceof WC_Product) {
            return '';
        }

        ob_start();
        $this->render_variation_mix_bundle($resolved_product);
        return (string) ob_get_clean();
    }

    public function maybe_parse_elementor_bundle_shortcodes(string $content): string {
        if ($content === '' || !is_singular('product')) {
            return $content;
        }

        if (
            strpos($content, '[nvcc_variation_bundle') === false &&
            strpos($content, '[nvcc_bundle_widget') === false
        ) {
            return $content;
        }

        $parsed = preg_replace_callback(
            '/\[(nvcc_variation_bundle|nvcc_bundle_widget)(?:\s[^\]]*)?\]/i',
            static function (array $matches): string {
                return do_shortcode($matches[0]);
            },
            $content
        );

        return is_string($parsed) ? $parsed : $content;
    }

    private function should_render_bundle_in_theme_widget(): bool {
        if (!function_exists('wp_get_theme')) {
            return false;
        }

        $theme = wp_get_theme();
        if (!$theme instanceof WP_Theme) {
            return false;
        }

        $template = strtolower((string) $theme->get_template());
        $stylesheet = strtolower((string) $theme->get_stylesheet());
        $name = strtolower((string) $theme->get('Name'));

        foreach ([$template, $stylesheet, $name] as $needle_source) {
            if (strpos($needle_source, 'nv-nordic-precision') !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * One-time migration from legacy Merchant Hub option into local nvcc_settings keys.
     */
    private function maybe_migrate_buy_now_from_hub(): void {
        $flag = get_option('nvcc_buy_now_migrated', '0');
        if ($flag === '1') {
            return;
        }

        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $has_local_keys =
            array_key_exists('buy_now_enabled', $saved) ||
            array_key_exists('buy_now_label', $saved) ||
            array_key_exists('buy_now_redirect_target', $saved);

        if ($has_local_keys) {
            update_option('nvcc_buy_now_migrated', '1', false);
            return;
        }

        $legacy = get_option('nvmh_module_settings', []);
        if (!is_array($legacy) || empty($legacy)) {
            update_option('nvcc_buy_now_migrated', '1', false);
            return;
        }

        $saved['buy_now_enabled'] = (($legacy['buy_now_enabled'] ?? 'yes') === 'no') ? 'no' : 'yes';
        $saved['buy_now_label'] = sanitize_text_field((string) ($legacy['buy_now_label'] ?? __('Buy Now', 'nv-commerce-core')));
        $target = sanitize_key((string) ($legacy['buy_now_redirect_target'] ?? 'checkout'));
        $saved['buy_now_redirect_target'] = in_array($target, ['checkout', 'cart'], true) ? $target : 'checkout';

        update_option(self::OPTION_KEY, $saved, false);
        update_option('nvcc_buy_now_migrated', '1', false);
    }

    /**
     * @return array<string,mixed>
     */
    private function get_buy_now_settings(): array {
        $this->maybe_migrate_buy_now_from_hub();

        $settings = $this->get_settings();
        $redirect_target = sanitize_key((string) ($settings['buy_now_redirect_target'] ?? 'checkout'));
        if (!in_array($redirect_target, ['checkout', 'cart'], true)) {
            $redirect_target = 'checkout';
        }

        return [
            'buy_now_enabled' => (($settings['buy_now_enabled'] ?? 'yes') === 'no') ? 'no' : 'yes',
            'buy_now_label' => sanitize_text_field((string) ($settings['buy_now_label'] ?? __('Buy Now', 'nv-commerce-core'))),
            'buy_now_redirect_target' => $redirect_target,
        ];
    }

    private function is_buy_now_enabled(): bool {
        $module_settings = $this->get_buy_now_settings();
        return ($module_settings['buy_now_enabled'] ?? 'yes') === 'yes';
    }

    private function get_buy_now_label(): string {
        $module_settings = $this->get_buy_now_settings();
        $label = trim((string) ($module_settings['buy_now_label'] ?? ''));
        if ($label === '') {
            $label = __('Buy Now', 'nv-commerce-core');
        }

        return $label;
    }

    private function get_buy_now_redirect_url(): string {
        $module_settings = $this->get_buy_now_settings();
        $target = (string) ($module_settings['buy_now_redirect_target'] ?? 'checkout');

        if ($target === 'cart' && function_exists('wc_get_cart_url')) {
            return (string) wc_get_cart_url();
        }

        if (function_exists('wc_get_checkout_url')) {
            return (string) wc_get_checkout_url();
        }

        return home_url('/checkout/');
    }

    public function render_buy_now_button(): void {
        if (!$this->is_buy_now_enabled()) {
            return;
        }

        global $product;
        if (!$product instanceof WC_Product || !$product->is_purchasable()) {
            return;
        }

        if ($product->is_type('external') || $product->is_type('grouped')) {
            return;
        }

        $label = $this->get_buy_now_label();
        ?>
        <button
            type="submit"
            class="button alt nvcc-buy-now-button"
            name="nv_buy_now"
            value="1"
            style="margin-left:8px;"
        ><?php echo esc_html($label); ?></button>
        <?php
    }

    public function maybe_buy_now_redirect(string $url): string {
        if (!$this->is_buy_now_enabled()) {
            return $url;
        }

        if (!isset($_REQUEST['nv_buy_now']) || sanitize_text_field(wp_unslash((string) $_REQUEST['nv_buy_now'])) !== '1') {
            return $url;
        }

        return $this->get_buy_now_redirect_url();
    }

    public function get_settings(): array {
        $default_bundle_deals = $this->get_default_bundle_deals();

        $defaults = [
            'enable_bulk_discount' => 'yes',
            'bulk_label' => __('Volymrabatt', 'nv-commerce-core'),
            'tier_2_qty' => 2,
            'tier_2_pct' => 10,
            'tier_3_qty' => 3,
            'tier_3_pct' => 15,
            'tier_4_qty' => 4,
            'tier_4_pct' => 20,
            'enable_variation_bundle' => 'yes',
            'bundle_subtitle' => __('Välj flera varianter och lägg till allt med ett klick.', 'nv-commerce-core'),
            'bundle_headline' => '',
            'bundle_variant_style' => 'a',
            'bundle_cta_label' => __('Lägg till paket', 'nv-commerce-core'),
            'bundle_timer_enabled' => 'no',
            'bundle_timer_minutes' => 15,
            'bundle_timer_text' => __('Erbjudandet slutar om', 'nv-commerce-core'),
            'bundle_popular_index' => 2,
            'bundle_default_index' => 2,
            'bundle_deals' => $default_bundle_deals,
            'bundle_deal_1_qty' => 1,
            'bundle_deal_1_title' => __('Single', 'nv-commerce-core'),
            'bundle_deal_1_subtitle' => __('Standardpris', 'nv-commerce-core'),
            'bundle_deal_1_badge' => '',
            'bundle_deal_1_label' => '',
            'bundle_deal_1_discount_mode' => 'auto',
            'bundle_deal_1_discount_value' => '',
            'bundle_deal_1_discount' => '',
            'bundle_deal_1_bogo' => 'no',
            'bundle_deal_2_qty' => 2,
            'bundle_deal_2_title' => __('Duo', 'nv-commerce-core'),
            'bundle_deal_2_subtitle' => __('Spara {pct}%', 'nv-commerce-core'),
            'bundle_deal_2_badge' => __('Mest populär', 'nv-commerce-core'),
            'bundle_deal_2_label' => __('Fri frakt', 'nv-commerce-core'),
            'bundle_deal_2_discount_mode' => 'auto',
            'bundle_deal_2_discount_value' => '',
            'bundle_deal_2_discount' => '',
            'bundle_deal_2_bogo' => 'no',
            'bundle_deal_3_qty' => 3,
            'bundle_deal_3_title' => __('Trio', 'nv-commerce-core'),
            'bundle_deal_3_subtitle' => __('Spara {pct}%', 'nv-commerce-core'),
            'bundle_deal_3_badge' => '',
            'bundle_deal_3_label' => '',
            'bundle_deal_3_discount_mode' => 'auto',
            'bundle_deal_3_discount_value' => '',
            'bundle_deal_3_discount' => '',
            'bundle_deal_3_bogo' => 'no',
            'bundle_bonus_preview_enabled' => 'yes',
            'bundle_bonus_display_style' => 'auto',
            'bundle_bonus_thumb_size' => 'thumbnail',
            'bundle_bonus_details_cta' => __('+ Visa alla {count} böcker ▼', 'nv-commerce-core'),
            'buy_now_enabled' => 'yes',
            'buy_now_label' => __('Buy Now', 'nv-commerce-core'),
            'buy_now_redirect_target' => 'checkout',
            'offer_campaigns' => [],
            'bonus_entitlements_enabled' => 'yes',
            'bonus_match_product_selectors' => "slug:niteguard\nid:17006\nid:12233",
            'bonus_tier_1_min_qty' => 1,
            'bonus_tier_1_selectors' => "slug:hygienguide\nid:12431",
            'bonus_tier_2_min_qty' => 2,
            'bonus_tier_2_selectors' => "slug:hygienguide\nslug:nokturi\nslug:sov-hela-natten\nid:12431\nid:12416\nid:12399",
            'bonus_tier_3_min_qty' => 3,
            'bonus_tier_3_selectors' => "slug:hygienguide\nslug:sov-hela-natten\nslug:fallskydd-i-hemmet\nslug:nokturi\nslug:starkare-backenbotten\nslug:energi-efter-65\nslug:sjalvstandig-hemma\nslug:battre-blashalsa\nslug:trygg-natt\nslug:somn-halsa\nid:12431\nid:12399\nid:12414\nid:12416\nid:12418\nid:12420\nid:12422\nid:12425\nid:12427\nid:12429",
            'bonus_idempotency_meta_key' => '_nvob_bonuses_granted',
            'bonus_debug_order_notes' => 'no',
        ];

        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $merged = wp_parse_args($saved, $defaults);
        $merged['bundle_deals'] = $this->normalize_bundle_deals(
            $merged['bundle_deals'] ?? [],
            $this->get_legacy_deals_from_source($merged, true),
            true
        );

        if (!isset($merged['offer_campaigns']) || !is_array($merged['offer_campaigns'])) {
            $merged['offer_campaigns'] = [];
        }

        return $merged;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private function get_default_bundle_deals(): array {
        return [
            [
                'qty' => 1,
                'title' => __('Single', 'nv-commerce-core'),
                'subtitle' => __('Standardpris', 'nv-commerce-core'),
                'badge' => '',
                'label' => '',
                'discount_mode' => 'auto',
                'discount_value' => '',
                'discount' => '',
                'bogo' => 'no',
            ],
            [
                'qty' => 2,
                'title' => __('Duo', 'nv-commerce-core'),
                'subtitle' => __('Spara {pct}%', 'nv-commerce-core'),
                'badge' => __('Mest populär', 'nv-commerce-core'),
                'label' => __('Fri frakt', 'nv-commerce-core'),
                'discount_mode' => 'auto',
                'discount_value' => '',
                'discount' => '',
                'bogo' => 'no',
            ],
            [
                'qty' => 3,
                'title' => __('Trio', 'nv-commerce-core'),
                'subtitle' => __('Spara {pct}%', 'nv-commerce-core'),
                'badge' => '',
                'label' => '',
                'discount_mode' => 'auto',
                'discount_value' => '',
                'discount' => '',
                'bogo' => 'no',
            ],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function get_bonus_module_defaults(): array {
        return [
            'bonus_entitlements_enabled' => 'yes',
            'bonus_match_product_selectors' => "slug:niteguard\nid:17006\nid:12233",
            'bonus_tier_1_min_qty' => 1,
            'bonus_tier_1_selectors' => "slug:hygienguide\nid:12431",
            'bonus_tier_2_min_qty' => 2,
            'bonus_tier_2_selectors' => "slug:hygienguide\nslug:nokturi\nslug:sov-hela-natten\nid:12431\nid:12416\nid:12399",
            'bonus_tier_3_min_qty' => 3,
            'bonus_tier_3_selectors' => "slug:hygienguide\nslug:sov-hela-natten\nslug:fallskydd-i-hemmet\nslug:nokturi\nslug:starkare-backenbotten\nslug:energi-efter-65\nslug:sjalvstandig-hemma\nslug:battre-blashalsa\nslug:trygg-natt\nslug:somn-halsa\nid:12431\nid:12399\nid:12414\nid:12416\nid:12418\nid:12420\nid:12422\nid:12425\nid:12427\nid:12429",
            'bonus_idempotency_meta_key' => '_nvob_bonuses_granted',
            'bonus_debug_order_notes' => 'no',
        ];
    }

    /**
     * @param array<string,mixed> $settings
     * @return array<string,mixed>
     */
    private function sanitize_bonus_module_settings(array $settings): array {
        $defaults = $this->get_bonus_module_defaults();

        $sanitized = [
            'bonus_entitlements_enabled' => (($settings['bonus_entitlements_enabled'] ?? $defaults['bonus_entitlements_enabled']) === 'no') ? 'no' : 'yes',
            'bonus_match_product_selectors' => trim((string) ($settings['bonus_match_product_selectors'] ?? $defaults['bonus_match_product_selectors'])),
            'bonus_tier_1_min_qty' => max(1, (int) ($settings['bonus_tier_1_min_qty'] ?? $defaults['bonus_tier_1_min_qty'])),
            'bonus_tier_1_selectors' => trim((string) ($settings['bonus_tier_1_selectors'] ?? $defaults['bonus_tier_1_selectors'])),
            'bonus_tier_2_min_qty' => max(1, (int) ($settings['bonus_tier_2_min_qty'] ?? $defaults['bonus_tier_2_min_qty'])),
            'bonus_tier_2_selectors' => trim((string) ($settings['bonus_tier_2_selectors'] ?? $defaults['bonus_tier_2_selectors'])),
            'bonus_tier_3_min_qty' => max(1, (int) ($settings['bonus_tier_3_min_qty'] ?? $defaults['bonus_tier_3_min_qty'])),
            'bonus_tier_3_selectors' => trim((string) ($settings['bonus_tier_3_selectors'] ?? $defaults['bonus_tier_3_selectors'])),
            'bonus_idempotency_meta_key' => sanitize_key((string) ($settings['bonus_idempotency_meta_key'] ?? $defaults['bonus_idempotency_meta_key'])),
            'bonus_debug_order_notes' => (($settings['bonus_debug_order_notes'] ?? $defaults['bonus_debug_order_notes']) === 'yes') ? 'yes' : 'no',
        ];

        if ($sanitized['bonus_match_product_selectors'] === '') {
            $sanitized['bonus_match_product_selectors'] = (string) $defaults['bonus_match_product_selectors'];
        }
        if ($sanitized['bonus_tier_1_selectors'] === '') {
            $sanitized['bonus_tier_1_selectors'] = (string) $defaults['bonus_tier_1_selectors'];
        }
        if ($sanitized['bonus_tier_2_selectors'] === '') {
            $sanitized['bonus_tier_2_selectors'] = (string) $defaults['bonus_tier_2_selectors'];
        }
        if ($sanitized['bonus_tier_3_selectors'] === '') {
            $sanitized['bonus_tier_3_selectors'] = (string) $defaults['bonus_tier_3_selectors'];
        }
        if ($sanitized['bonus_idempotency_meta_key'] === '') {
            $sanitized['bonus_idempotency_meta_key'] = (string) $defaults['bonus_idempotency_meta_key'];
        }

        return $sanitized;
    }

    /**
     * @param array<string,mixed> $legacy
     * @return array<string,mixed>
     */
    private function map_legacy_order_bonuses_settings(array $legacy): array {
        $mapped = [
            'bonus_entitlements_enabled' => (($legacy['enabled'] ?? 'yes') === 'no') ? 'no' : 'yes',
            'bonus_match_product_selectors' => trim((string) ($legacy['match_product_selectors'] ?? '')),
            'bonus_tier_1_min_qty' => max(1, (int) ($legacy['tier_1_min_qty'] ?? 1)),
            'bonus_tier_1_selectors' => trim((string) ($legacy['tier_1_bonus_selectors'] ?? '')),
            'bonus_tier_2_min_qty' => max(1, (int) ($legacy['tier_2_min_qty'] ?? 2)),
            'bonus_tier_2_selectors' => trim((string) ($legacy['tier_2_bonus_selectors'] ?? '')),
            'bonus_tier_3_min_qty' => max(1, (int) ($legacy['tier_3_min_qty'] ?? 3)),
            'bonus_tier_3_selectors' => trim((string) ($legacy['tier_3_bonus_selectors'] ?? '')),
            'bonus_idempotency_meta_key' => sanitize_key((string) ($legacy['idempotency_meta_key'] ?? '_nvob_bonuses_granted')),
            'bonus_debug_order_notes' => (($legacy['debug_order_notes'] ?? 'no') === 'yes') ? 'yes' : 'no',
            'bundle_bonus_preview_enabled' => (($legacy['frontend_show_bonus_thumbnails'] ?? 'yes') === 'no') ? 'no' : 'yes',
            'bundle_bonus_display_style' => in_array((string) ($legacy['frontend_display_style'] ?? 'auto'), ['auto', 'strip', 'grid'], true) ? (string) $legacy['frontend_display_style'] : 'auto',
            'bundle_bonus_thumb_size' => in_array((string) ($legacy['frontend_thumbnail_size'] ?? 'thumbnail'), ['thumbnail', 'woocommerce_thumbnail', 'medium', 'full'], true) ? (string) $legacy['frontend_thumbnail_size'] : 'thumbnail',
        ];

        return $this->sanitize_bonus_module_settings($mapped) + [
            'bundle_bonus_preview_enabled' => (string) $mapped['bundle_bonus_preview_enabled'],
            'bundle_bonus_display_style' => (string) $mapped['bundle_bonus_display_style'],
            'bundle_bonus_thumb_size' => (string) $mapped['bundle_bonus_thumb_size'],
        ];
    }

    /**
     * @param array<string,mixed> $raw_settings
     */
    private function has_bonus_module_keys(array $raw_settings): bool {
        foreach (array_keys($this->get_bonus_module_defaults()) as $key) {
            if (array_key_exists($key, $raw_settings)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Read legacy nv_order_bonuses_settings once and write-forward into nvcc_settings.
     *
     * @param array<string,mixed> $raw_nvcc_settings
     * @return array<string,mixed>
     */
    private function maybe_migrate_legacy_order_bonus_settings(array $raw_nvcc_settings): array {
        if ($this->has_bonus_module_keys($raw_nvcc_settings)) {
            return $raw_nvcc_settings;
        }

        $legacy = get_option('nv_order_bonuses_settings', []);
        if (!is_array($legacy) || empty($legacy)) {
            return $raw_nvcc_settings;
        }

        $mapped = $this->map_legacy_order_bonuses_settings($legacy);

        foreach ($mapped as $key => $value) {
            if (!array_key_exists($key, $raw_nvcc_settings)) {
                $raw_nvcc_settings[$key] = $value;
            }
        }

        update_option(self::OPTION_KEY, $raw_nvcc_settings, false);

        return $raw_nvcc_settings;
    }

    /**
     * @return array<string,mixed>
     */
    private function get_bonus_module_settings(): array {
        $raw = get_option(self::OPTION_KEY, []);
        if (!is_array($raw)) {
            $raw = [];
        }

        $raw = $this->maybe_migrate_legacy_order_bonus_settings($raw);

        return $this->sanitize_bonus_module_settings($raw);
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private function get_legacy_deals_from_source(array $source, bool $allow_discount = false): array {
        $items = [];
        $prefix = array_key_exists('deal_1_qty', $source) ? 'deal_' : 'bundle_deal_';

        for ($i = 1; $i <= 3; $i++) {
            $discount_mode = sanitize_key((string) ($source[$prefix . $i . '_discount_mode'] ?? ''));
            if (!in_array($discount_mode, ['auto', 'percentage', 'fixed_amount', 'fixed_price'], true)) {
                $discount_mode = 'auto';
            }

            $discount_value_raw = $source[$prefix . $i . '_discount_value'] ?? '';
            $discount_value_raw = is_scalar($discount_value_raw) ? trim((string) $discount_value_raw) : '';
            $discount_value = $discount_value_raw === '' ? '' : max(0.0, (float) $discount_value_raw);

            $item = [
                'qty' => max(1, absint((string) ($source[$prefix . $i . '_qty'] ?? $i))),
                'title' => sanitize_text_field((string) ($source[$prefix . $i . '_title'] ?? '')),
                'subtitle' => sanitize_text_field((string) ($source[$prefix . $i . '_subtitle'] ?? '')),
                'badge' => sanitize_text_field((string) ($source[$prefix . $i . '_badge'] ?? '')),
                'label' => sanitize_text_field((string) ($source[$prefix . $i . '_label'] ?? '')),
                'bogo' => (($source[$prefix . $i . '_bogo'] ?? 'no') === 'yes') ? 'yes' : 'no',
                'discount_mode' => $discount_mode,
                'discount_value' => $discount_value,
                'discount' => '',
            ];

            if ($allow_discount) {
                $discount_raw = $source[$prefix . $i . '_discount'] ?? ($source['deal_' . $i . '_discount'] ?? '');
                $discount_raw = is_scalar($discount_raw) ? trim((string) $discount_raw) : '';
                $legacy_discount = $discount_raw === '' ? '' : max(0.0, (float) $discount_raw);
                if ($discount_mode === 'auto' && $legacy_discount !== '') {
                    $discount_mode = 'percentage';
                    $item['discount_mode'] = 'percentage';
                }

                if ($discount_value === '' && $legacy_discount !== '') {
                    $discount_value = $legacy_discount;
                    $item['discount_value'] = $legacy_discount;
                }

                if ($item['discount_mode'] === 'percentage') {
                    $item['discount'] = $item['discount_value'] === '' ? '' : max(0.0, (float) $item['discount_value']);
                }
            }

            $items[] = $item;
        }

        return $items;
    }

    /**
     * @param mixed $raw
     * @param array<int,array<string,mixed>> $fallback
     * @return array<int,array<string,mixed>>
     */
    private function normalize_bundle_deals($raw, array $fallback = [], bool $allow_discount = false): array {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($raw)) {
            $raw = [];
        }

        $items = [];

        foreach ($raw as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $qty = max(1, absint((string) ($item['qty'] ?? ($index + 1))));
            $title = sanitize_text_field((string) ($item['title'] ?? ''));
            $subtitle = sanitize_text_field((string) ($item['subtitle'] ?? ''));
            $badge = sanitize_text_field((string) ($item['badge'] ?? ''));
            $label = sanitize_text_field((string) ($item['label'] ?? ''));
            $discount_mode = sanitize_key((string) ($item['discount_mode'] ?? ''));
            if (!in_array($discount_mode, ['auto', 'percentage', 'fixed_amount', 'fixed_price'], true)) {
                $discount_mode = 'auto';
            }
            $discount_raw = $item['discount'] ?? '';
            $discount_raw = is_scalar($discount_raw) ? trim((string) $discount_raw) : '';
            $discount_value_raw = $item['discount_value'] ?? '';
            $discount_value_raw = is_scalar($discount_value_raw) ? trim((string) $discount_value_raw) : '';

            $discount_value = '';
            if ($allow_discount) {
                if ($discount_value_raw !== '') {
                    $discount_value = max(0.0, (float) $discount_value_raw);
                } elseif ($discount_raw !== '') {
                    $discount_value = max(0.0, (float) $discount_raw);
                }
            }

            if ($allow_discount && $discount_mode === 'auto' && $discount_raw !== '') {
                $discount_mode = 'percentage';
            }

            $items[] = [
                'qty' => $qty,
                'title' => $title,
                'subtitle' => $subtitle,
                'badge' => $badge,
                'label' => $label,
                'discount_mode' => $discount_mode,
                'discount_value' => $discount_value,
                'discount' => ($allow_discount && $discount_mode === 'percentage' && $discount_value !== '') ? max(0.0, (float) $discount_value) : '',
                'bogo' => (($item['bogo'] ?? 'no') === 'yes') ? 'yes' : 'no',
            ];
        }

        if (empty($items)) {
            $items = $fallback;
        }

        if (empty($items)) {
            $items = $this->get_default_bundle_deals();
        }

        return array_values($items);
    }

    /**
     * @param mixed $raw
     * @return array<int,int>
     */
    private function normalize_id_list($raw): array {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : preg_split('/[\s,]+/', $raw);
        }

        if (!is_array($raw)) {
            return [];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = absint((string) $value);
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<int,int>
     */
    private function extract_id_values_from_selectors(string $raw): array {
        $ids = [];
        $parts = preg_split('/[\r\n,]+/', $raw);

        if (!is_array($parts)) {
            return $ids;
        }

        foreach ($parts as $line) {
            $value = trim((string) $line);
            if ($value === '') {
                continue;
            }

            if (preg_match('/^id\s*:\s*(\d+)$/i', $value, $match)) {
                $ids[] = absint((string) $match[1]);
                continue;
            }

            if (ctype_digit($value)) {
                $ids[] = absint($value);
            }
        }

        return array_values(array_unique(array_filter($ids)));
    }

    private function parse_product_selectors(string $raw): array {
        $selectors = [];
        $parts = preg_split('/[\r\n,]+/', $raw);

        if (!is_array($parts)) {
            return $selectors;
        }

        foreach ($parts as $line) {
            $value = trim((string) $line);
            if ($value === '') {
                continue;
            }

            $type = 'slug';
            $selector_value = $value;

            if (preg_match('/^(id|slug|sku)\s*:\s*(.+)$/i', $value, $match)) {
                $type = strtolower(trim((string) $match[1]));
                $selector_value = trim((string) $match[2]);
            } elseif (ctype_digit($value)) {
                $type = 'id';
            }

            if ($type === 'id') {
                $normalized = absint($selector_value);
                if ($normalized > 0) {
                    $selectors[] = ['type' => 'id', 'value' => (string) $normalized];
                }
                continue;
            }

            if ($type === 'sku') {
                $normalized = wc_clean($selector_value);
                if ($normalized !== '') {
                    $selectors[] = ['type' => 'sku', 'value' => $normalized];
                }
                continue;
            }

            $normalized = sanitize_title($selector_value);
            if ($normalized !== '') {
                $selectors[] = ['type' => 'slug', 'value' => $normalized];
            }
        }

        return $selectors;
    }

    private function parse_category_selectors(string $raw): array {
        $selectors = [];
        $parts = preg_split('/[\r\n,]+/', $raw);

        if (!is_array($parts)) {
            return $selectors;
        }

        foreach ($parts as $line) {
            $value = trim((string) $line);
            if ($value === '') {
                continue;
            }

            $type = 'slug';
            $selector_value = $value;

            if (preg_match('/^(id|slug)\s*:\s*(.+)$/i', $value, $match)) {
                $type = strtolower(trim((string) $match[1]));
                $selector_value = trim((string) $match[2]);
            } elseif (ctype_digit($value)) {
                $type = 'id';
            }

            if ($type === 'id') {
                $normalized = absint($selector_value);
                if ($normalized > 0) {
                    $selectors[] = ['type' => 'id', 'value' => (string) $normalized];
                }
                continue;
            }

            $normalized = sanitize_title($selector_value);
            if ($normalized !== '') {
                $selectors[] = ['type' => 'slug', 'value' => $normalized];
            }
        }

        return $selectors;
    }

    private function get_product_signatures(WC_Product $product): array {
        $ids = [(int) $product->get_id()];
        $slugs = [sanitize_title((string) $product->get_slug())];
        $skus = [(string) $product->get_sku()];

        if ($product->is_type('variation')) {
            $parent_id = (int) $product->get_parent_id();
            if ($parent_id > 0) {
                $ids[] = $parent_id;
                $parent = wc_get_product($parent_id);
                if ($parent instanceof WC_Product) {
                    $slugs[] = sanitize_title((string) $parent->get_slug());
                    $skus[] = (string) $parent->get_sku();
                }
            }
        }

        $clean_ids = [];
        foreach ($ids as $id) {
            if ($id > 0) {
                $clean_ids[] = (int) $id;
            }
        }

        $clean_slugs = [];
        foreach ($slugs as $slug) {
            $normalized = sanitize_title((string) $slug);
            if ($normalized !== '') {
                $clean_slugs[] = $normalized;
            }
        }

        $clean_skus = [];
        foreach ($skus as $sku) {
            $normalized = wc_clean((string) $sku);
            if ($normalized !== '') {
                $clean_skus[] = $normalized;
            }
        }

        return [
            'ids' => array_values(array_unique($clean_ids)),
            'slugs' => array_values(array_unique($clean_slugs)),
            'skus' => array_values(array_unique($clean_skus)),
        ];
    }

    private function product_matches_selectors(WC_Product $product, array $selectors): bool {
        if (empty($selectors)) {
            return false;
        }

        $signatures = $this->get_product_signatures($product);
        foreach ($selectors as $selector) {
            $type = (string) ($selector['type'] ?? '');
            $value = (string) ($selector['value'] ?? '');

            if ($type === 'id' && in_array((int) $value, $signatures['ids'], true)) {
                return true;
            }
            if ($type === 'slug' && in_array(sanitize_title($value), $signatures['slugs'], true)) {
                return true;
            }
            if ($type === 'sku' && in_array(wc_clean($value), $signatures['skus'], true)) {
                return true;
            }
        }

        return false;
    }

    private function product_matches_category_selectors(WC_Product $product, array $selectors): bool {
        if (empty($selectors)) {
            return false;
        }

        $product_id = (int) $product->get_id();
        if ($product->is_type('variation')) {
            $parent_id = (int) $product->get_parent_id();
            if ($parent_id > 0) {
                $product_id = $parent_id;
            }
        }

        if ($product_id <= 0) {
            return false;
        }

        $category_ids = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'ids']);
        $category_slugs = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'slugs']);

        if (!is_array($category_ids)) {
            $category_ids = [];
        }
        if (!is_array($category_slugs)) {
            $category_slugs = [];
        }

        $normalized_slugs = [];
        foreach ($category_slugs as $slug) {
            $normalized = sanitize_title((string) $slug);
            if ($normalized !== '') {
                $normalized_slugs[] = $normalized;
            }
        }

        foreach ($selectors as $selector) {
            $type = (string) ($selector['type'] ?? '');
            $value = (string) ($selector['value'] ?? '');

            if ($type === 'id' && in_array((int) $value, array_map('intval', $category_ids), true)) {
                return true;
            }
            if ($type === 'slug' && in_array(sanitize_title($value), $normalized_slugs, true)) {
                return true;
            }
        }

        return false;
    }

    private function resolve_selector_to_product_id(array $selector): int {
        $type = (string) ($selector['type'] ?? '');
        $value = (string) ($selector['value'] ?? '');

        if ($type === 'id') {
            $id = absint($value);
            return ($id > 0 && wc_get_product($id) instanceof WC_Product) ? $id : 0;
        }

        if ($type === 'sku') {
            $id = (int) wc_get_product_id_by_sku(wc_clean($value));
            return $id > 0 ? $id : 0;
        }

        $slug = sanitize_title($value);
        if ($slug === '') {
            return 0;
        }

        $by_path = get_page_by_path($slug, OBJECT, 'product');
        if ($by_path instanceof WP_Post) {
            return (int) $by_path->ID;
        }

        $query = get_posts([
            'post_type' => 'product',
            'name' => $slug,
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'fields' => 'ids',
        ]);

        return !empty($query) ? (int) $query[0] : 0;
    }

    private function get_order_bonuses_selectors_for_product_deal(int $product_id, int $deal_num): string {
        if ($deal_num < 1 || $deal_num > 3) {
            return '';
        }

        $settings = $this->get_bonus_module_settings();

        $match_raw = trim((string) ($settings['bonus_match_product_selectors'] ?? ''));
        if ($match_raw === '') {
            return '';
        }

        $match_selectors = $this->parse_product_selectors($match_raw);
        if (empty($match_selectors)) {
            return '';
        }

        $product = wc_get_product($product_id);
        if (!$product instanceof WC_Product || !$this->product_matches_selectors($product, $match_selectors)) {
            return '';
        }

        return trim((string) ($settings['bonus_tier_' . $deal_num . '_selectors'] ?? ''));
    }

    private function count_matched_quantity_for_order_bonus(WC_Order $order, array $match_selectors): int {
        $qty = 0;

        foreach ($order->get_items() as $item) {
            if (!$item instanceof WC_Order_Item_Product) {
                continue;
            }

            $product = $item->get_product();
            if (!$product instanceof WC_Product) {
                continue;
            }

            if (!$this->product_matches_selectors($product, $match_selectors)) {
                continue;
            }

            $qty += (int) $item->get_quantity();
        }

        return $qty;
    }

    /**
     * @return array<int,int>
     */
    private function collect_matched_parent_quantities_for_order_bonus(WC_Order $order, array $match_selectors): array {
        $parent_qty = [];

        foreach ($order->get_items() as $item) {
            if (!$item instanceof WC_Order_Item_Product) {
                continue;
            }

            $product = $item->get_product();
            if (!$product instanceof WC_Product) {
                continue;
            }

            if (!$this->product_matches_selectors($product, $match_selectors)) {
                continue;
            }

            $parent_id = $product->is_type('variation')
                ? (int) $product->get_parent_id()
                : (int) $product->get_id();
            if ($parent_id <= 0) {
                continue;
            }

            $qty = max(0, (int) $item->get_quantity());
            if ($qty <= 0) {
                continue;
            }

            if (!isset($parent_qty[$parent_id])) {
                $parent_qty[$parent_id] = 0;
            }
            $parent_qty[$parent_id] += $qty;
        }

        return $parent_qty;
    }

    private function map_bonus_tier_name_to_deal_index(string $tier_name): int {
        if (!preg_match('/^tier_(\d+)$/', trim($tier_name), $match)) {
            return 0;
        }

        return max(1, min(3, (int) $match[1]));
    }

    private function get_bridge_bonus_selectors_for_order(WC_Order $order, array $match_selectors, array $tier): array {
        $deal_index = $this->map_bonus_tier_name_to_deal_index((string) ($tier['name'] ?? ''));
        if ($deal_index <= 0) {
            return [];
        }

        $matched_parents = $this->collect_matched_parent_quantities_for_order_bonus($order, $match_selectors);
        if (count($matched_parents) !== 1) {
            return [];
        }

        $product_id = (int) array_key_first($matched_parents);
        if ($product_id <= 0) {
            return [];
        }

        $raw = get_post_meta($product_id, '_nvcc_deal_' . $deal_index . '_bonus_selectors', true);
        if (!is_string($raw) || trim($raw) === '') {
            return [];
        }

        return $this->parse_product_selectors($raw);
    }

    private function get_matched_bonus_tier_for_qty(int $qty, array $settings): array {
        $tiers = [
            [
                'name' => 'tier_1',
                'min_qty' => max(1, (int) ($settings['bonus_tier_1_min_qty'] ?? 1)),
                'selectors' => $this->parse_product_selectors((string) ($settings['bonus_tier_1_selectors'] ?? '')),
            ],
            [
                'name' => 'tier_2',
                'min_qty' => max(1, (int) ($settings['bonus_tier_2_min_qty'] ?? 2)),
                'selectors' => $this->parse_product_selectors((string) ($settings['bonus_tier_2_selectors'] ?? '')),
            ],
            [
                'name' => 'tier_3',
                'min_qty' => max(1, (int) ($settings['bonus_tier_3_min_qty'] ?? 3)),
                'selectors' => $this->parse_product_selectors((string) ($settings['bonus_tier_3_selectors'] ?? '')),
            ],
        ];

        usort($tiers, static function (array $a, array $b): int {
            return (int) $b['min_qty'] <=> (int) $a['min_qty'];
        });

        foreach ($tiers as $tier) {
            if ($qty >= (int) $tier['min_qty']) {
                return $tier;
            }
        }

        return [];
    }

    private function add_bonus_debug_order_note(WC_Order $order, array $settings, string $message): void {
        if (($settings['bonus_debug_order_notes'] ?? 'no') !== 'yes') {
            return;
        }

        $order->add_order_note('[NV Commerce Core] ' . $message);
    }

    public function grant_bonus_downloads(int $order_id, $order = null): void {
        if (!class_exists('WooCommerce')) {
            return;
        }

        $settings = $this->get_bonus_module_settings();
        if (($settings['bonus_entitlements_enabled'] ?? 'yes') !== 'yes') {
            return;
        }

        $wc_order = $order instanceof WC_Order ? $order : wc_get_order($order_id);
        if (!$wc_order instanceof WC_Order) {
            return;
        }

        $meta_key = sanitize_key((string) ($settings['bonus_idempotency_meta_key'] ?? '_nvob_bonuses_granted'));
        if ($meta_key === '') {
            $meta_key = '_nvob_bonuses_granted';
        }

        $already_granted = $wc_order->get_meta($meta_key, true);
        if (!empty($already_granted)) {
            $this->add_bonus_debug_order_note($wc_order, $settings, 'Skipped because bonuses already granted for this order.');
            return;
        }

        $match_selectors = $this->parse_product_selectors((string) ($settings['bonus_match_product_selectors'] ?? ''));
        if (empty($match_selectors)) {
            $this->add_bonus_debug_order_note($wc_order, $settings, 'No match selectors configured.');
            return;
        }

        $target_qty = $this->count_matched_quantity_for_order_bonus($wc_order, $match_selectors);
        if ($target_qty <= 0) {
            return;
        }

        $tier = $this->get_matched_bonus_tier_for_qty($target_qty, $settings);
        if (empty($tier)) {
            $this->add_bonus_debug_order_note($wc_order, $settings, 'No tier matched for quantity ' . $target_qty . '.');
            return;
        }

        $bridge_selectors = $this->get_bridge_bonus_selectors_for_order($wc_order, $match_selectors, $tier);
        $resolved_selectors = !empty($bridge_selectors)
            ? $bridge_selectors
            : (array) ($tier['selectors'] ?? []);

        $bonus_ids = [];
        foreach ($resolved_selectors as $selector) {
            $product_id = $this->resolve_selector_to_product_id($selector);
            if ($product_id > 0) {
                $bonus_ids[] = $product_id;
            }
        }
        $bonus_ids = array_values(array_unique($bonus_ids));

        if (empty($bonus_ids)) {
            $this->add_bonus_debug_order_note($wc_order, $settings, 'No bonus products resolved for matched tier.');
            return;
        }

        $granted_ids = [];
        foreach ($bonus_ids as $bonus_id) {
            $bonus_product = wc_get_product((int) $bonus_id);
            if (!$bonus_product instanceof WC_Product || !$bonus_product->is_downloadable()) {
                continue;
            }

            $downloads = $bonus_product->get_downloads();
            if (empty($downloads)) {
                continue;
            }

            foreach (array_keys($downloads) as $download_key) {
                wc_downloadable_file_permission((string) $download_key, (int) $bonus_id, $wc_order);
            }

            $granted_ids[] = (int) $bonus_id;
        }

        if (empty($granted_ids)) {
            $this->add_bonus_debug_order_note($wc_order, $settings, 'Matched tier but no downloadable products were granted.');
            return;
        }

        $wc_order->update_meta_data($meta_key, [
            'timestamp' => current_time('mysql'),
            'target_qty' => $target_qty,
            'matched_tier' => (string) ($tier['name'] ?? ''),
            'matched_min_qty' => (int) ($tier['min_qty'] ?? 0),
            'selector_source' => !empty($bridge_selectors) ? 'nvcc_product_meta' : 'nvcc_tier_settings',
            'granted_ids' => array_values(array_unique($granted_ids)),
        ]);
        $wc_order->save();

        $this->add_bonus_debug_order_note(
            $wc_order,
            $settings,
            sprintf(
                'Granted %1$d downloadable bonus product(s) for matched quantity %2$d. IDs: %3$s',
                count($granted_ids),
                $target_qty,
                implode(', ', $granted_ids)
            )
        );
    }

    private function resolve_bonus_products_from_selectors_raw(string $selectors_raw, string $thumb_size): array {
        $selectors = $this->parse_product_selectors($selectors_raw);
        if (empty($selectors)) {
            return [];
        }

        $items = [];
        $seen_ids = [];
        foreach ($selectors as $selector) {
            $product_id = $this->resolve_selector_to_product_id($selector);
            if ($product_id <= 0 || isset($seen_ids[$product_id])) {
                continue;
            }

            $product = wc_get_product($product_id);
            if (!$product instanceof WC_Product) {
                continue;
            }

            $seen_ids[$product_id] = true;
            $image_url = '';
            $image_id = (int) $product->get_image_id();
            if ($image_id > 0) {
                $image_url = (string) wp_get_attachment_image_url($image_id, $thumb_size);
            }
            if ($image_url === '') {
                $image_url = (string) wc_placeholder_img_src($thumb_size);
            }

            $items[] = [
                'id' => $product_id,
                'title' => $product->get_name(),
                'image_url' => $image_url,
            ];
        }

        return $items;
    }

    private function get_bonus_display_style_for_deal(array $settings, int $deal_qty): string {
        $style = (string) ($settings['bundle_bonus_display_style'] ?? 'auto');
        if (!in_array($style, ['auto', 'strip', 'grid'], true)) {
            $style = 'auto';
        }

        if ($style === 'auto') {
            return $deal_qty >= 3 ? 'grid' : 'strip';
        }

        return $style;
    }

    private function get_bonus_preview_for_deal(int $product_id, int $deal_num, int $deal_qty, array $deal, array $settings, bool $allow_product_legacy_meta = false): array {
        $raw_selectors = '';
        if ($allow_product_legacy_meta && $this->is_legacy_product_deals_enabled($product_id)) {
            $raw_selectors = trim((string) get_post_meta($product_id, '_nvcc_deal_' . $deal_num . '_bonus_selectors', true));
        }
        if ($raw_selectors === '') {
            $raw_selectors = $this->get_order_bonuses_selectors_for_product_deal($product_id, $deal_num);
        }

        if ($raw_selectors === '') {
            return [];
        }

        $thumb_size = (string) ($settings['bundle_bonus_thumb_size'] ?? 'thumbnail');
        if (!in_array($thumb_size, ['thumbnail', 'woocommerce_thumbnail', 'medium', 'full'], true)) {
            $thumb_size = 'thumbnail';
        }

        $items = $this->resolve_bonus_products_from_selectors_raw($raw_selectors, $thumb_size);
        if (empty($items)) {
            return [];
        }

        $bonus_text = '';
        if ($allow_product_legacy_meta && $this->is_legacy_product_deals_enabled($product_id)) {
            $bonus_text = trim((string) get_post_meta($product_id, '_nvcc_deal_' . $deal_num . '_bonus_label', true));
        }

        $custom_titles_raw = '';
        if ($allow_product_legacy_meta && $this->is_legacy_product_deals_enabled($product_id)) {
            $custom_titles_raw = trim((string) get_post_meta($product_id, '_nvcc_deal_' . $deal_num . '_bonus_titles', true));
        }
        if ($custom_titles_raw !== '') {
            $custom_titles = preg_split('/[\r\n]+/', $custom_titles_raw);
            if (is_array($custom_titles)) {
                foreach ($items as $index => &$item) {
                    if (!isset($custom_titles[$index])) {
                        continue;
                    }
                    $custom_title = trim((string) $custom_titles[$index]);
                    if ($custom_title === '') {
                        continue;
                    }
                    $item['title'] = $custom_title;
                }
                unset($item);
            }
        }

        $details_cta = trim((string) ($settings['bundle_bonus_details_cta'] ?? __('+ Visa alla {count} böcker ▼', 'nv-commerce-core')));
        if ($details_cta === '') {
            $details_cta = __('+ Visa alla {count} böcker ▼', 'nv-commerce-core');
        }
        $details_cta = str_replace('{count}', (string) count($items), $details_cta);

        return [
            'style' => $this->get_bonus_display_style_for_deal($settings, $deal_qty),
            'items' => $items,
            'text' => $bonus_text,
            'cta' => $details_cta,
        ];
    }

    private function get_tiers_from_settings(array $settings): array {
        $tiers = [
            [
                'qty' => max(1, (int) ($settings['tier_2_qty'] ?? 2)),
                'pct' => max(0, (float) ($settings['tier_2_pct'] ?? 10)),
            ],
            [
                'qty' => max(1, (int) ($settings['tier_3_qty'] ?? 3)),
                'pct' => max(0, (float) ($settings['tier_3_pct'] ?? 15)),
            ],
            [
                'qty' => max(1, (int) ($settings['tier_4_qty'] ?? 4)),
                'pct' => max(0, (float) ($settings['tier_4_pct'] ?? 20)),
            ],
        ];

        usort($tiers, static function (array $a, array $b): int {
            return $a['qty'] <=> $b['qty'];
        });

        return $tiers;
    }

    private function get_effective_tiers(array $settings, array $eligible_product_ids): array {
        unset($eligible_product_ids);
        return $this->get_tiers_from_settings($settings);
    }

    private function get_discount_percent_for_qty(int $qty, array $tiers): float {
        $percent = 0.0;
        foreach ($tiers as $tier) {
            if ($qty >= (int) $tier['qty']) {
                $percent = (float) $tier['pct'];
            }
        }

        return $percent;
    }

    private function is_product_bulk_eligible(int $product_id): bool {
        unset($product_id);
        return true;
    }

    /**
     * @param array<string,mixed> $cart_item
     */
    private function get_bundle_custom_discount_mode_from_cart_item(array $cart_item): string {
        return $this->sanitize_deal_discount_mode($cart_item['_nvcc_bundle_deal_mode'] ?? 'auto');
    }

    /**
     * @param array<string,mixed> $cart_item
     */
    private function cart_item_has_custom_bundle_discount(array $cart_item): bool {
        $mode = $this->get_bundle_custom_discount_mode_from_cart_item($cart_item);
        if (!in_array($mode, ['percentage', 'fixed_amount', 'fixed_price'], true)) {
            return false;
        }

        $value = $this->sanitize_deal_discount_value($cart_item['_nvcc_bundle_deal_value'] ?? 0);
        return $value > 0;
    }

    private function is_line_item_bulk_discount_enabled(): bool {
        $settings = get_option('nv_smart_upsell_settings', []);
        return is_array($settings) && (($settings['bulk_discount_enabled'] ?? 'no') === 'yes');
    }

    public function apply_bundle_custom_deal_discounts(WC_Cart $cart): void {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        if ($cart->is_empty()) {
            return;
        }

        $groups = [];

        foreach ($cart->get_cart() as $cart_item) {
            if (!is_array($cart_item) || !$this->cart_item_has_custom_bundle_discount($cart_item)) {
                continue;
            }

            $group_token = sanitize_text_field((string) ($cart_item['_nvcc_bundle_group'] ?? ''));
            if ($group_token === '') {
                continue;
            }

            $mode = $this->get_bundle_custom_discount_mode_from_cart_item($cart_item);
            $value = $this->sanitize_deal_discount_value($cart_item['_nvcc_bundle_deal_value'] ?? 0);
            if ($value <= 0) {
                continue;
            }

            if ($mode === 'percentage' && $this->is_line_item_bulk_discount_enabled()) {
                continue;
            }

            $line_subtotal = isset($cart_item['line_subtotal']) ? (float) $cart_item['line_subtotal'] : 0.0;
            if ($line_subtotal <= 0 && isset($cart_item['data'], $cart_item['quantity']) && $cart_item['data'] instanceof WC_Product) {
                $line_subtotal = ((float) $cart_item['data']->get_price()) * max(0, (int) $cart_item['quantity']);
            }
            if ($line_subtotal <= 0) {
                continue;
            }

            if (!isset($groups[$group_token])) {
                $groups[$group_token] = [
                    'mode' => $mode,
                    'value' => $value,
                    'subtotal' => 0.0,
                    'title' => sanitize_text_field((string) ($cart_item['_nvcc_bundle_deal_title'] ?? '')),
                ];
            }

            $groups[$group_token]['subtotal'] += $line_subtotal;
        }

        if (empty($groups)) {
            return;
        }

        $decimals = wc_get_price_decimals();

        foreach ($groups as $group) {
            $mode = (string) ($group['mode'] ?? 'auto');
            $value = (float) ($group['value'] ?? 0.0);
            $subtotal = max(0.0, (float) ($group['subtotal'] ?? 0.0));
            if ($value <= 0 || $subtotal <= 0) {
                continue;
            }

            $discount = 0.0;
            if ($mode === 'percentage') {
                $discount = $subtotal * (min(100.0, max(0.0, $value)) / 100);
            } elseif ($mode === 'fixed_amount') {
                $discount = min($subtotal, $value);
            } elseif ($mode === 'fixed_price') {
                $discount = max(0.0, $subtotal - $value);
            }

            $discount = round($discount, $decimals);
            if ($discount <= 0) {
                continue;
            }

            $title = trim((string) ($group['title'] ?? ''));
            $label = $title !== ''
                ? sprintf(__('Bundle deal: %s', 'nv-commerce-core'), $title)
                : __('Bundle deal discount', 'nv-commerce-core');

            $cart->add_fee($label, -$discount, false);
        }
    }

    public function apply_bulk_discount(WC_Cart $cart): void {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        $settings = $this->get_settings();
        if (($settings['enable_bulk_discount'] ?? 'no') !== 'yes') {
            return;
        }

        $use_fee_engine = (bool) apply_filters('nvcc_use_fee_bulk_discount', true);
        if (!$use_fee_engine) {
            return;
        }

        if ($cart->is_empty()) {
            return;
        }

        $eligible_qty = 0;
        $eligible_subtotal = 0.0;
        $eligible_product_ids = [];

        foreach ($cart->get_cart() as $cart_item) {
            if (!is_array($cart_item) || $this->cart_item_has_custom_bundle_discount($cart_item)) {
                continue;
            }

            if (!isset($cart_item['data']) || !$cart_item['data'] instanceof WC_Product) {
                continue;
            }

            /** @var WC_Product $item_product */
            $item_product = $cart_item['data'];
            $parent_id = $item_product->is_type('variation') ? $item_product->get_parent_id() : $item_product->get_id();
            $parent_id = (int) $parent_id;

            if ($parent_id <= 0 || !$this->is_product_bulk_eligible($parent_id)) {
                continue;
            }

            $qty = max(0, (int) ($cart_item['quantity'] ?? 0));
            if ($qty <= 0) {
                continue;
            }

            $line_subtotal = isset($cart_item['line_subtotal']) ? (float) $cart_item['line_subtotal'] : ((float) $item_product->get_price() * $qty);
            if ($line_subtotal <= 0) {
                continue;
            }

            $eligible_qty += $qty;
            $eligible_subtotal += $line_subtotal;
            $eligible_product_ids[$parent_id] = $parent_id;
        }

        if ($eligible_qty <= 0 || $eligible_subtotal <= 0) {
            return;
        }

        $tiers = $this->get_effective_tiers($settings, $eligible_product_ids);
        $discount_percent = $this->get_discount_percent_for_qty($eligible_qty, $tiers);

        if ($discount_percent <= 0) {
            return;
        }

        $discount_amount = round($eligible_subtotal * ($discount_percent / 100), wc_get_price_decimals());
        if ($discount_amount <= 0) {
            return;
        }

        $label = trim((string) ($settings['bulk_label'] ?? ''));
        if ($label === '') {
            $label = __('Volymrabatt', 'nv-commerce-core');
        }

        $label_with_percent = sprintf('%s (%s%%)', $label, rtrim(rtrim((string) $discount_percent, '0'), '.'));
        $cart->add_fee($label_with_percent, -$discount_amount, false);
    }

    public function enqueue_assets(): void {
        if (!class_exists('WooCommerce')) {
            return;
        }

        $is_product_request = is_product();
        if (!$is_product_request && !$this->is_elementor_preview_request()) {
            return;
        }

        if ($is_product_request) {
            global $product;
            if (!$product instanceof WC_Product) {
                $product = wc_get_product(get_the_ID());
            }

            if (!$product instanceof WC_Product || !in_array($product->get_type(), ['simple', 'variable'], true)) {
                return;
            }

            if (!$this->is_bundle_enabled_for_product($product->get_id())) {
                return;
            }
        }

        $this->enqueue_bundle_assets();
    }

    public function enqueue_elementor_preview_assets(): void {
        if (!class_exists('WooCommerce')) {
            return;
        }

        $this->enqueue_bundle_assets();
    }

    private function is_elementor_preview_request(): bool {
        return isset($_GET['elementor-preview']) || isset($_GET['elementor_preview']);
    }

    private function enqueue_bundle_assets(): void {
        if ($this->bundle_assets_enqueued) {
            return;
        }

        $this->bundle_assets_enqueued = true;

        /*
         * Enqueue Space Grotesk for price elements (brand guideline v2.1 Section 03).
         * The theme already loads Manrope + Sora; we add Space Grotesk here so the
         * plugin is self-contained even if the theme font stack changes.
         */
        wp_enqueue_style(
            'nv-commerce-core-fonts',
            'https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'nv-commerce-core',
            plugin_dir_url(__FILE__) . 'assets/css/nv-commerce-core.css',
            ['nv-commerce-core-fonts'],
            NVCC_VERSION
        );

        wp_enqueue_script(
            'nv-commerce-core',
            plugin_dir_url(__FILE__) . 'assets/js/nv-commerce-core.js',
            ['jquery'],
            NVCC_VERSION,
            true
        );

        $settings = $this->get_settings();
        $locale = str_replace('_', '-', get_locale());
        $currency = get_woocommerce_currency();
        $add_label = trim((string) ($settings['bundle_cta_label'] ?? ''));
        if ($add_label === '') {
            $add_label = __('Lägg till paket', 'nv-commerce-core');
        }

        $timer_enabled = ($settings['bundle_timer_enabled'] ?? 'no') === 'yes';
        $timer_minutes = max(1, (int) ($settings['bundle_timer_minutes'] ?? 15));
        $buy_now_enabled = $this->is_buy_now_enabled();
        $buy_now_label = $this->get_buy_now_label();
        $buy_now_redirect_url = $this->get_buy_now_redirect_url();

        wp_localize_script('nv-commerce-core', 'NVCommerceCore', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('nvcc_bundle_nonce'),
            'currencyCode' => $currency,
            'locale' => $locale,
            'timerEnabled' => $timer_enabled,
            'timerMinutes' => $timer_minutes,
            'buyNow' => [
                'enabled' => $buy_now_enabled,
                'label' => $buy_now_label,
                'redirectUrl' => $buy_now_redirect_url,
            ],
            'strings' => [
                'selectQty' => __('Välj minst en variant med antal över 0.', 'nv-commerce-core'),
                'selectAll' => __('Välj variant i alla rader först.', 'nv-commerce-core'),
                'adding' => __('Lägger till...', 'nv-commerce-core'),
                'added' => __('Tillagd!', 'nv-commerce-core'),
                'error' => __('Något gick fel. Försök igen.', 'nv-commerce-core'),
                'add' => $add_label,
                'buyNowAdded' => __('Tillagd – skickar till kassan...', 'nv-commerce-core'),
            ],
        ]);
    }

    private function is_bundle_enabled_for_product(int $product_id): bool {
        unset($product_id);
        $settings = $this->get_settings();
        return ($settings['enable_variation_bundle'] ?? 'no') === 'yes';
    }

    private function get_variation_options(WC_Product_Variable $product): array {
        $available = $product->get_available_variations();
        $options = [];

        foreach ($available as $variation_data) {
            $variation_id = (int) ($variation_data['variation_id'] ?? 0);
            if ($variation_id <= 0) {
                continue;
            }

            $variation = wc_get_product($variation_id);
            if (!$variation instanceof WC_Product_Variation || !$variation->is_purchasable() || !$variation->is_in_stock()) {
                continue;
            }

            /*
             * Build a short label from the variation's attribute values only,
             * NOT the full product name (e.g. "Herr" instead of
             * "NiteGuard™ — Portabel Nattflaska för Hela Natten – Herr").
             */
            $attributes = $variation->get_variation_attributes();
            $attr_parts = [];
            foreach ($attributes as $attr_key => $attr_value) {
                if ($attr_value === '') {
                    continue;
                }
                /* Resolve taxonomy term names for global attributes */
                $taxonomy = str_replace('attribute_', '', $attr_key);
                if (taxonomy_exists($taxonomy)) {
                    $term = get_term_by('slug', $attr_value, $taxonomy);
                    if ($term instanceof WP_Term) {
                        $attr_parts[] = $term->name;
                        continue;
                    }
                }
                $attr_parts[] = ucfirst($attr_value);
            }

            $variation_label = implode(', ', $attr_parts);
            if ($variation_label === '') {
                /* Fallback: use formatted variation string */
                $variation_label = wc_get_formatted_variation($variation, true, false, true);
            }
            if ($variation_label === '') {
                $variation_label = $variation->get_name();
            }

            $price = (float) $variation->get_price();
            $regular_price = (float) $variation->get_regular_price();
            if ($regular_price <= 0) {
                $regular_price = $price;
            }

            $image_id = $variation->get_image_id();
            $image_url = '';
            if ($image_id) {
                $thumb = wp_get_attachment_image_url($image_id, 'thumbnail');
                if ($thumb) {
                    $image_url = $thumb;
                }
            }
            if ($image_url === '') {
                $parent_image_id = $product->get_image_id();
                if ($parent_image_id) {
                    $thumb = wp_get_attachment_image_url($parent_image_id, 'thumbnail');
                    if ($thumb) {
                        $image_url = $thumb;
                    }
                }
            }

            $options[] = [
                'id' => $variation_id,
                'type' => 'variation',
                'label' => wp_strip_all_tags($variation_label),
                'price' => $price,
                'regular_price' => $regular_price,
                'image_url' => $image_url,
            ];
        }

        return $options;
    }

    private function get_bundle_product_options(WC_Product $product): array {
        if ($product instanceof WC_Product_Variable) {
            return $this->get_variation_options($product);
        }

        if (!$product->is_type('simple') || !$product->is_purchasable() || !$product->is_in_stock()) {
            return [];
        }

        $price = (float) $product->get_price();
        $regular_price = (float) $product->get_regular_price();
        if ($regular_price <= 0) {
            $regular_price = $price;
        }

        $image_url = '';
        $image_id = $product->get_image_id();
        if ($image_id) {
            $thumb = wp_get_attachment_image_url($image_id, 'thumbnail');
            if ($thumb) {
                $image_url = $thumb;
            }
        }

        return [
            [
                'id' => (int) $product->get_id(),
                'type' => 'simple',
                'label' => wp_strip_all_tags((string) $product->get_name()),
                'price' => $price,
                'regular_price' => $regular_price,
                'image_url' => $image_url,
            ],
        ];
    }

    private function sanitize_deal_discount_mode($mode): string {
        $normalized = sanitize_key((string) $mode);
        if (!in_array($normalized, ['auto', 'percentage', 'fixed_amount', 'fixed_price'], true)) {
            return 'auto';
        }

        return $normalized;
    }

    private function sanitize_deal_discount_value($value): float {
        if (!is_scalar($value)) {
            return 0.0;
        }

        return max(0.0, (float) trim((string) $value));
    }

    /**
     * @param array<string,mixed> $deal_config
     * @param array<int,array<string,mixed>> $tiers
     * @return array{mode:string,value:float,discount_pct:float}
     */
    private function resolve_deal_discount_config(array $deal_config, int $qty, array $tiers): array {
        $mode = $this->sanitize_deal_discount_mode($deal_config['discount_mode'] ?? 'auto');
        $value = $this->sanitize_deal_discount_value($deal_config['discount_value'] ?? ($deal_config['discount'] ?? ''));
        $discount_pct = $this->get_discount_percent_for_qty($qty, $tiers);

        if ($mode === 'percentage') {
            if ($value > 0) {
                $discount_pct = $value;
            } else {
                $mode = 'auto';
            }
        }

        if (($deal_config['bogo'] ?? 'no') === 'yes' && $qty > 1) {
            $mode = 'percentage';
            $value = round(100 / $qty, 2);
            $discount_pct = $value;
        }

        return [
            'mode' => $mode,
            'value' => $value,
            'discount_pct' => max(0.0, $discount_pct),
        ];
    }

    private function build_default_bundle_deals(array $settings, array $tiers): array {
        $deals = [];
        $source_deals = $this->normalize_bundle_deals(
            $settings['bundle_deals'] ?? [],
            $this->get_legacy_deals_from_source($settings, true),
            true
        );
        $deal_count = max(1, count($source_deals));
        $popular_index = max(1, min($deal_count, absint((string) ($settings['bundle_popular_index'] ?? 2))));
        $default_index = max(1, min($deal_count, absint((string) ($settings['bundle_default_index'] ?? 2))));

        foreach ($source_deals as $i => $deal_config) {
            $deal_num = $i + 1;
            $qty = max(1, absint((string) ($deal_config['qty'] ?? $deal_num)));
            $discount_config = $this->resolve_deal_discount_config($deal_config, $qty, $tiers);
            $discount_mode = (string) $discount_config['mode'];
            $discount_value = (float) $discount_config['value'];
            $discount_pct = (float) $discount_config['discount_pct'];

            $title = trim((string) ($deal_config['title'] ?? ''));
            if ($title === '') {
                $title = sprintf(__('Deal %d', 'nv-commerce-core'), $deal_num);
            }

            $subtitle = trim((string) ($deal_config['subtitle'] ?? ''));
            if ($subtitle === '') {
                if ($discount_mode === 'percentage' && $discount_pct > 0) {
                    $subtitle = sprintf(__('Spara %s%%', 'nv-commerce-core'), rtrim(rtrim((string) $discount_pct, '0'), '.'));
                } elseif ($discount_mode === 'fixed_amount' && $discount_value > 0) {
                    $subtitle = __('Fast rabatt', 'nv-commerce-core');
                } elseif ($discount_mode === 'fixed_price' && $discount_value > 0) {
                    $subtitle = __('Fast paketpris', 'nv-commerce-core');
                } else {
                    $subtitle = __('Standardpris', 'nv-commerce-core');
                }
            } else {
                $subtitle = str_replace('{pct}', rtrim(rtrim((string) $discount_pct, '0'), '.'), $subtitle);
                $subtitle = str_replace('{amount}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
                $subtitle = str_replace('{price}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
            }

            $badge = trim((string) ($deal_config['badge'] ?? ''));
            if ($deal_num === $popular_index && $badge === '') {
                $badge = __('Mest populär', 'nv-commerce-core');
            }

            $label = trim((string) ($deal_config['label'] ?? ''));

            $bogo = (($deal_config['bogo'] ?? 'no') === 'yes');

            $deals[] = [
                'deal_num' => $deal_num,
                'qty' => $qty,
                'title' => $title,
                'subtitle' => $subtitle,
                'badge' => $badge,
                'label' => $label,
                'discount_pct' => $discount_pct,
                'discount_mode' => $discount_mode,
                'discount_value' => $discount_value,
                'is_default' => ($deal_num === $default_index),
                'bogo' => $bogo,
            ];
        }

        usort($deals, static function (array $a, array $b): int {
            return ((int) $a['qty']) <=> ((int) $b['qty']);
        });

        return $deals;
    }

    private function get_offer_campaigns_from_settings(array $settings): array {
        $campaigns = $settings['offer_campaigns'] ?? [];
        return is_array($campaigns) ? array_values($campaigns) : [];
    }

    /**
     * @param array<int,array<string,mixed>> $campaigns
     * @return array<int,array<string,mixed>>
     */
    private function hydrate_offer_campaigns_for_admin(array $campaigns): array {
        $hydrated = [];

        foreach ($campaigns as $campaign) {
            if (!is_array($campaign)) {
                continue;
            }

            $hydrated[] = $this->hydrate_offer_campaign_admin_labels($campaign);
        }

        return $hydrated;
    }

    /**
     * @param array<string,mixed> $campaign
     * @return array<string,mixed>
     */
    private function hydrate_offer_campaign_admin_labels(array $campaign): array {
        $campaign['product_labels'] = $this->get_admin_product_label_map($campaign['product_ids'] ?? []);
        $campaign['category_labels'] = $this->get_admin_term_label_map('product_cat', $campaign['category_ids'] ?? []);
        $campaign['tag_labels'] = $this->get_admin_term_label_map('product_tag', $campaign['tag_ids'] ?? []);

        $brand_taxonomies = $this->detect_brand_taxonomies();
        $campaign['brand_labels'] = !empty($brand_taxonomies)
            ? $this->get_admin_term_label_map((string) $brand_taxonomies[0], $campaign['brand_ids'] ?? [])
            : [];

        return $campaign;
    }

    /**
     * @param mixed $ids
     * @return array<string,string>
     */
    private function get_admin_product_label_map($ids): array {
        $labels = [];

        if (!function_exists('wc_get_product')) {
            return $labels;
        }

        foreach ($this->normalize_id_list($ids) as $id) {
            $product = wc_get_product($id);
            if (!$product instanceof WC_Product) {
                continue;
            }

            $label = trim(wp_strip_all_tags((string) $product->get_name()));
            if ($label !== '') {
                $labels[(string) $id] = $label;
            }
        }

        return $labels;
    }

    /**
     * @param mixed $ids
     * @return array<string,string>
     */
    private function get_admin_term_label_map(string $taxonomy, $ids): array {
        $labels = [];

        if ($taxonomy === '' || !taxonomy_exists($taxonomy)) {
            return $labels;
        }

        foreach ($this->normalize_id_list($ids) as $id) {
            $term = get_term($id, $taxonomy);
            if (!$term instanceof WP_Term) {
                continue;
            }

            $label = trim(wp_strip_all_tags((string) $term->name));
            if ($label !== '') {
                $labels[(string) $id] = $label;
            }
        }

        return $labels;
    }

    private function product_matches_term_ids(WC_Product $product, string $taxonomy, array $term_ids): bool {
        if ($taxonomy === '' || empty($term_ids) || !taxonomy_exists($taxonomy)) {
            return false;
        }

        $product_id = (int) $product->get_id();
        if ($product->is_type('variation')) {
            $parent_id = (int) $product->get_parent_id();
            if ($parent_id > 0) {
                $product_id = $parent_id;
            }
        }

        if ($product_id <= 0) {
            return false;
        }

        $product_term_ids = wp_get_post_terms($product_id, $taxonomy, ['fields' => 'ids']);
        if (!is_array($product_term_ids) || empty($product_term_ids)) {
            return false;
        }

        $needle = array_map('intval', $term_ids);
        foreach ($product_term_ids as $term_id) {
            if (in_array((int) $term_id, $needle, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<int,string>
     */
    private function detect_brand_taxonomies(): array {
        $candidates = [
            'product_brand',
            'pwb-brand',
            'yith_product_brand',
            'berocket_brand',
            'pa_brand',
        ];

        $found = [];
        foreach ($candidates as $taxonomy) {
            if (taxonomy_exists($taxonomy)) {
                $found[] = $taxonomy;
            }
        }

        return array_values(array_unique($found));
    }

    private function product_matches_brand_ids(WC_Product $product, array $brand_ids): bool {
        if (empty($brand_ids)) {
            return false;
        }

        foreach ($this->detect_brand_taxonomies() as $taxonomy) {
            if ($this->product_matches_term_ids($product, $taxonomy, $brand_ids)) {
                return true;
            }
        }

        return false;
    }

    private function campaign_matches_target_mode(WC_Product $product, array $campaign): ?bool {
        $target_mode = sanitize_key((string) ($campaign['target_mode'] ?? ''));
        if ($target_mode === '') {
            return null;
        }

        if ($target_mode === 'all_products') {
            return true;
        }

        if ($target_mode === 'specific_products') {
            $ids = $this->normalize_id_list($campaign['product_ids'] ?? []);
            if (empty($ids)) {
                return false;
            }
            return $this->product_matches_selectors(
                $product,
                array_map(static fn (int $id): array => ['type' => 'id', 'value' => (string) $id], $ids)
            );
        }

        if ($target_mode === 'specific_categories') {
            $ids = $this->normalize_id_list($campaign['category_ids'] ?? []);
            if (empty($ids)) {
                return false;
            }
            return $this->product_matches_term_ids($product, 'product_cat', $ids);
        }

        if ($target_mode === 'specific_tags') {
            $ids = $this->normalize_id_list($campaign['tag_ids'] ?? []);
            if (empty($ids)) {
                return false;
            }
            return $this->product_matches_term_ids($product, 'product_tag', $ids);
        }

        if ($target_mode === 'specific_brands') {
            $ids = $this->normalize_id_list($campaign['brand_ids'] ?? []);
            if (empty($ids)) {
                return false;
            }
            return $this->product_matches_brand_ids($product, $ids);
        }

        return null;
    }

    private function get_active_offer_campaign_for_product(WC_Product $product, array $settings): array {
        $campaigns = $this->get_offer_campaigns_from_settings($settings);
        if (empty($campaigns)) {
            return [];
        }

        $matches = [];

        foreach ($campaigns as $index => $campaign) {
            if (!is_array($campaign)) {
                continue;
            }

            $status = sanitize_key((string) ($campaign['status'] ?? 'active'));
            if ($status !== 'active') {
                continue;
            }

            $target_mode_match = $this->campaign_matches_target_mode($product, $campaign);
            if ($target_mode_match !== null) {
                $is_match = (bool) $target_mode_match;
            } else {
                $product_selectors = $this->parse_product_selectors((string) ($campaign['product_selectors'] ?? ''));
                $category_selectors = $this->parse_category_selectors((string) ($campaign['category_selectors'] ?? ''));

                $has_product_selectors = !empty($product_selectors);
                $has_category_selectors = !empty($category_selectors);
                if (!$has_product_selectors && !$has_category_selectors) {
                    continue;
                }

                $product_match = $has_product_selectors ? $this->product_matches_selectors($product, $product_selectors) : false;
                $category_match = $has_category_selectors ? $this->product_matches_category_selectors($product, $category_selectors) : false;

                $match_mode = sanitize_key((string) ($campaign['match_mode'] ?? 'any'));
                if ($match_mode === 'all') {
                    $is_match = (!$has_product_selectors || $product_match) && (!$has_category_selectors || $category_match);
                } else {
                    $is_match = ($has_product_selectors && $product_match) || ($has_category_selectors && $category_match);
                }
            }

            if (!$is_match) {
                continue;
            }

            $matches[] = [
                'priority' => (int) ($campaign['priority'] ?? 0),
                'index' => (int) $index,
                'campaign' => $campaign,
            ];
        }

        if (empty($matches)) {
            return [];
        }

        usort($matches, static function (array $a, array $b): int {
            $priority_compare = ((int) $b['priority']) <=> ((int) $a['priority']);
            if ($priority_compare !== 0) {
                return $priority_compare;
            }

            return ((int) $a['index']) <=> ((int) $b['index']);
        });

        return (array) ($matches[0]['campaign'] ?? []);
    }

    private function build_campaign_bundle_deals(array $campaign, array $tiers): array {
        $deals = [];
        $source_deals = $this->normalize_bundle_deals(
            $campaign['deals'] ?? [],
            $this->get_legacy_deals_from_source($campaign, true),
            true
        );
        $deal_count = max(1, count($source_deals));
        $popular_index = max(1, min($deal_count, absint((string) ($campaign['popular_index'] ?? 2))));
        $default_index = max(1, min($deal_count, absint((string) ($campaign['default_index'] ?? 2))));

        foreach ($source_deals as $i => $deal_config) {
            $deal_num = $i + 1;
            $qty = max(1, absint((string) ($deal_config['qty'] ?? $deal_num)));
            $discount_config = $this->resolve_deal_discount_config($deal_config, $qty, $tiers);
            $discount_mode = (string) $discount_config['mode'];
            $discount_value = (float) $discount_config['value'];
            $discount_pct = (float) $discount_config['discount_pct'];

            $title = trim((string) ($deal_config['title'] ?? ''));
            if ($title === '') {
                $title = sprintf(__('Deal %d', 'nv-commerce-core'), $deal_num);
            }

            $subtitle = trim((string) ($deal_config['subtitle'] ?? ''));
            if ($subtitle === '') {
                if ($discount_mode === 'percentage' && $discount_pct > 0) {
                    $subtitle = sprintf(__('Spara %s%%', 'nv-commerce-core'), rtrim(rtrim((string) $discount_pct, '0'), '.'));
                } elseif ($discount_mode === 'fixed_amount' && $discount_value > 0) {
                    $subtitle = __('Fast rabatt', 'nv-commerce-core');
                } elseif ($discount_mode === 'fixed_price' && $discount_value > 0) {
                    $subtitle = __('Fast paketpris', 'nv-commerce-core');
                } else {
                    $subtitle = __('Standardpris', 'nv-commerce-core');
                }
            } else {
                $subtitle = str_replace('{pct}', rtrim(rtrim((string) $discount_pct, '0'), '.'), $subtitle);
                $subtitle = str_replace('{amount}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
                $subtitle = str_replace('{price}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
            }

            $badge = trim((string) ($deal_config['badge'] ?? ''));
            if ($deal_num === $popular_index && $badge === '') {
                $badge = __('Mest populär', 'nv-commerce-core');
            }

            $label = trim((string) ($deal_config['label'] ?? ''));
            $bogo = (($deal_config['bogo'] ?? 'no') === 'yes');

            $deals[] = [
                'deal_num' => $deal_num,
                'qty' => $qty,
                'title' => $title,
                'subtitle' => $subtitle,
                'badge' => $badge,
                'label' => $label,
                'discount_pct' => $discount_pct,
                'discount_mode' => $discount_mode,
                'discount_value' => $discount_value,
                'is_default' => ($deal_num === $default_index),
                'bogo' => $bogo,
            ];
        }

        usort($deals, static function (array $a, array $b): int {
            return ((int) $a['qty']) <=> ((int) $b['qty']);
        });

        return $deals;
    }

    private function product_has_legacy_deal_data(int $product_id): bool {
        if ($product_id <= 0) {
            return false;
        }

        $legacy_meta_keys = [
            '_nvcc_bundle_deals_json',
            '_nvcc_bundle_headline',
            '_nvcc_deal_1_qty',
            '_nvcc_deal_1_title',
            '_nvcc_deal_1_subtitle',
            '_nvcc_deal_1_badge',
            '_nvcc_deal_1_label',
            '_nvcc_deal_1_discount',
            '_nvcc_deal_1_bonus_label',
            '_nvcc_deal_1_bonus_selectors',
            '_nvcc_deal_1_bonus_titles',
            '_nvcc_deal_2_qty',
            '_nvcc_deal_2_title',
            '_nvcc_deal_2_subtitle',
            '_nvcc_deal_2_badge',
            '_nvcc_deal_2_label',
            '_nvcc_deal_2_discount',
            '_nvcc_deal_2_bonus_label',
            '_nvcc_deal_2_bonus_selectors',
            '_nvcc_deal_2_bonus_titles',
            '_nvcc_deal_3_qty',
            '_nvcc_deal_3_title',
            '_nvcc_deal_3_subtitle',
            '_nvcc_deal_3_badge',
            '_nvcc_deal_3_label',
            '_nvcc_deal_3_discount',
            '_nvcc_deal_3_bonus_label',
            '_nvcc_deal_3_bonus_selectors',
            '_nvcc_deal_3_bonus_titles',
        ];

        foreach ($legacy_meta_keys as $meta_key) {
            $value = get_post_meta($product_id, $meta_key, true);
            if (is_array($value)) {
                if (!empty($value)) {
                    return true;
                }
                continue;
            }

            if (trim((string) $value) !== '') {
                return true;
            }
        }

        return false;
    }

    private function is_legacy_product_deals_enabled(int $product_id): bool {
        if ($product_id <= 0) {
            return false;
        }

        $mode = sanitize_key((string) get_post_meta($product_id, '_nvcc_legacy_deals_enabled', true));
        if ($mode === 'yes') {
            return true;
        }
        if ($mode === 'no') {
            return false;
        }

        return $this->product_has_legacy_deal_data($product_id);
    }

    private function get_product_bundle_deals_override(int $product_id, array $tiers): array {
        $raw = get_post_meta($product_id, '_nvcc_bundle_deals_json', true);
        if (!is_string($raw) || trim($raw) === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }

        $deals = [];
        foreach ($decoded as $item) {
            if (!is_array($item)) {
                continue;
            }

            $qty = max(1, absint((string) ($item['qty'] ?? 1)));
            $discount_config = $this->resolve_deal_discount_config($item, $qty, $tiers);
            $discount_mode = (string) $discount_config['mode'];
            $discount_value = (float) $discount_config['value'];
            $discount_pct = (float) $discount_config['discount_pct'];
            $title = trim((string) ($item['title'] ?? ''));
            if ($title === '') {
                continue;
            }

            $subtitle = trim((string) ($item['subtitle'] ?? ''));
            if ($subtitle === '') {
                if ($discount_mode === 'percentage' && $discount_pct > 0) {
                    $subtitle = sprintf(__('Spara %s%%', 'nv-commerce-core'), rtrim(rtrim((string) $discount_pct, '0'), '.'));
                } elseif ($discount_mode === 'fixed_amount' && $discount_value > 0) {
                    $subtitle = __('Fast rabatt', 'nv-commerce-core');
                } elseif ($discount_mode === 'fixed_price' && $discount_value > 0) {
                    $subtitle = __('Fast paketpris', 'nv-commerce-core');
                } else {
                    $subtitle = __('Standardpris', 'nv-commerce-core');
                }
            } else {
                $subtitle = str_replace('{pct}', rtrim(rtrim((string) $discount_pct, '0'), '.'), $subtitle);
                $subtitle = str_replace('{amount}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
                $subtitle = str_replace('{price}', rtrim(rtrim((string) $discount_value, '0'), '.'), $subtitle);
            }

            $bogo = !empty($item['bogo']);

            $deals[] = [
                'deal_num' => max(0, absint((string) ($item['deal_num'] ?? 0))),
                'qty' => $qty,
                'title' => $title,
                'subtitle' => $subtitle,
                'badge' => trim((string) ($item['badge'] ?? '')),
                'label' => trim((string) ($item['label'] ?? '')),
                'discount_pct' => $discount_pct,
                'discount_mode' => $discount_mode,
                'discount_value' => $discount_value,
                'is_default' => !empty($item['default']),
                'bogo' => $bogo,
            ];
        }

        usort($deals, static function (array $a, array $b): int {
            return ((int) $a['qty']) <=> ((int) $b['qty']);
        });

        return $deals;
    }

    private function get_bundle_deals_for_product(array $settings, array $tiers, int $product_id, ?array $active_campaign = null): array {
        if ($active_campaign === null) {
            $product = wc_get_product($product_id);
            if ($product instanceof WC_Product) {
                $active_campaign = $this->get_active_offer_campaign_for_product($product, $settings);
            } else {
                $active_campaign = [];
            }
        }

        // Level 1 — Plugin-level offer campaign takes highest priority
        if (!empty($active_campaign)) {
            $campaign_deals = $this->build_campaign_bundle_deals($active_campaign, $tiers);
            if (!empty($campaign_deals)) {
                return $campaign_deals;
            }
        }

        return $this->build_default_bundle_deals($settings, $tiers);
    }

    private function get_initial_bundle_totals(array $variation_options, int $qty, string $discount_mode, float $discount_value, float $discount_pct): array {
        if (empty($variation_options)) {
            return ['current' => 0.0, 'regular' => 0.0];
        }

        $first = $variation_options[0];
        $base_price = (float) ($first['price'] ?? 0);
        $base_regular = (float) ($first['regular_price'] ?? $base_price);

        $current_total = $base_price * max(1, $qty);
        $regular_total = $base_regular * max(1, $qty);

        if ($discount_mode === 'percentage' || $discount_mode === 'auto') {
            if ($discount_pct > 0) {
                $current_total = $current_total * (1 - ($discount_pct / 100));
            }
        } elseif ($discount_mode === 'fixed_amount') {
            if ($discount_value > 0) {
                $current_total = max(0.0, $current_total - $discount_value);
            }
        } elseif ($discount_mode === 'fixed_price') {
            if ($discount_value > 0) {
                $current_total = min($current_total, $discount_value);
            }
        }

        return [
            'current' => max(0, $current_total),
            'regular' => max(0, $regular_total),
        ];
    }

    private function get_next_tier_message(array $tiers, int $current_qty): string {
        /*
         * The headline should tell the customer how many MORE items they need
         * to reach the NEXT discount tier, and what that tier's discount is.
         *
         * Example with tiers [2 → 10%, 3 → 15%, 4 → 20%]:
         *   0 items in cart → "Lägg till 2 och få 10% rabatt"
         *   1 item  in cart → "Lägg till 1 till och få 10% rabatt"
         *   2 items in cart → "Lägg till 1 till och få 15% rabatt"
         *   3 items in cart → "Lägg till 1 till och få 20% rabatt"
         *   4+ items        → "Du har redan högsta rabattnivån"
         */
        foreach ($tiers as $tier) {
            $tier_qty = (int) $tier['qty'];
            $tier_pct = (float) $tier['pct'];

            if ($tier_qty > $current_qty && $tier_pct > 0) {
                $needed = $tier_qty - $current_qty;
                $pct_str = (floor($tier_pct) == $tier_pct) ? (string)(int)$tier_pct : rtrim(rtrim(number_format($tier_pct, 2, '.', ''), '0'), '.');
                return sprintf(
                    __('Lägg till %1$d till och få %2$s%% rabatt', 'nv-commerce-core'),
                    $needed,
                    $pct_str
                );
            }
        }

        /* Customer is at or above the highest tier */
        $current_pct = $this->get_discount_percent_for_qty($current_qty, $tiers);
        if ($current_pct > 0) {
            $pct_str = (floor($current_pct) == $current_pct) ? (string)(int)$current_pct : rtrim(rtrim(number_format($current_pct, 2, '.', ''), '0'), '.');
            return sprintf(
                __('Du sparar %s%% — högsta rabattnivån!', 'nv-commerce-core'),
                $pct_str
            );
        }

        return __('Köp fler och spara — mängdrabatt tillämpas automatiskt', 'nv-commerce-core');
    }

    public function render_variation_mix_bundle($hooked_product = null): void {
        $resolved_product = null;

        if ($hooked_product instanceof WC_Product) {
            $resolved_product = $hooked_product;
        } else {
            global $product;
            if ($product instanceof WC_Product) {
                $resolved_product = $product;
            }
        }

        if (!$resolved_product instanceof WC_Product) {
            $product_id = get_the_ID();
            if ($product_id) {
                $candidate = wc_get_product($product_id);
                if ($candidate instanceof WC_Product) {
                    $resolved_product = $candidate;
                }
            }
        }

        if (!$resolved_product instanceof WC_Product || !in_array($resolved_product->get_type(), ['simple', 'variable'], true)) {
            return;
        }

        if (!$this->is_bundle_enabled_for_product($resolved_product->get_id())) {
            return;
        }

        $product_id = (int) $resolved_product->get_id();
        if ($product_id <= 0) {
            return;
        }

        if (isset($this->rendered_bundle_product_ids[$product_id])) {
            return;
        }

        $bundle_options = $this->get_bundle_product_options($resolved_product);
        if (empty($bundle_options)) {
            return;
        }

        $settings = $this->get_settings();
        $tiers = $this->get_tiers_from_settings($settings);
        $active_campaign = $this->get_active_offer_campaign_for_product($resolved_product, $settings);
        $deals = $this->get_bundle_deals_for_product($settings, $tiers, $product_id, $active_campaign);
        if (empty($deals)) {
            return;
        }

        $this->rendered_bundle_product_ids[$product_id] = true;
        $this->print_hide_default_add_to_cart_style();

        $cart_qty = $this->get_current_bulk_eligible_qty();

        $custom_headline = trim((string) ($active_campaign['headline'] ?? ''));
        if ($custom_headline === '') {
            $custom_headline = trim((string) ($settings['bundle_headline'] ?? ''));
        }
        if ($custom_headline !== '') {
            // Replace placeholders
            $next_tier_pct = 0;
            $next_tier_needed = 0;
            foreach ($tiers as $tier) {
                if ((int) $tier['qty'] > $cart_qty && (float) $tier['pct'] > 0) {
                    $next_tier_needed = (int) $tier['qty'] - $cart_qty;
                    $next_tier_pct = (float) $tier['pct'];
                    break;
                }
            }
            if ($next_tier_pct <= 0) {
                $next_tier_pct = $this->get_discount_percent_for_qty($cart_qty, $tiers);
            }
            $pct_display = (floor($next_tier_pct) == $next_tier_pct) ? (string)(int)$next_tier_pct : rtrim(rtrim(number_format($next_tier_pct, 2, '.', ''), '0'), '.');
            $headline = str_replace(['{needed}', '{pct}'], [(string)$next_tier_needed, $pct_display], $custom_headline);
        } else {
            $headline = $this->get_next_tier_message($tiers, $cart_qty);
        }
        $subtitle = trim((string) ($settings['bundle_subtitle'] ?? ''));
        $cta_label = trim((string) ($settings['bundle_cta_label'] ?? ''));
        if ($cta_label === '') {
            $cta_label = __('Lägg till paket', 'nv-commerce-core');
        }

        $variant_style = sanitize_key((string) ($settings['bundle_variant_style'] ?? 'a'));
        if (!in_array($variant_style, ['a', 'b', 'c'], true)) {
            $variant_style = 'a';
        }

        $group_name = 'nvcc_bundle_deal_' . $product_id;
        $has_default_deal = false;
        foreach ($deals as $deal) {
            if (!empty($deal['is_default'])) {
                $has_default_deal = true;
                break;
            }
        }
        $default_rendered = false;
        ?>
        <section class="nvcc-bundle nvcc-bundle--deals nvcc-bundle--variant-<?php echo esc_attr($variant_style); ?>" data-product-id="<?php echo esc_attr((string) $product_id); ?>">
            <?php
            $timer_enabled = ($settings['bundle_timer_enabled'] ?? 'no') === 'yes';
            $timer_minutes = max(1, (int) ($settings['bundle_timer_minutes'] ?? 15));
            if ($timer_enabled) : ?>
                <div class="nvcc-bundle__timer" data-timer-minutes="<?php echo esc_attr((string) $timer_minutes); ?>">
                    <span class="nvcc-bundle__timer-icon">⏰</span>
                    <span class="nvcc-bundle__timer-text"><?php echo esc_html((string) ($settings['bundle_timer_text'] ?? __('Erbjudandet slutar om', 'nv-commerce-core'))); ?></span>
                    <span class="nvcc-bundle__timer-clock">--:--</span>
                </div>
            <?php endif; ?>
            <h3 class="nvcc-bundle__title"><?php echo esc_html($headline); ?></h3>
            <?php if ($subtitle !== '') : ?>
                <p class="nvcc-bundle__subtitle"><?php echo esc_html($subtitle); ?></p>
            <?php endif; ?>

            <div class="nvcc-deals" role="radiogroup" aria-label="<?php esc_attr_e('Välj bundle deal', 'nv-commerce-core'); ?>">
                <?php foreach ($deals as $index => $deal) :
                    $deal_index = $index + 1;
                    $deal_qty = max(1, (int) ($deal['qty'] ?? 1));
                    $deal_discount = max(0, (float) ($deal['discount_pct'] ?? 0));
                    $deal_discount_mode = $this->sanitize_deal_discount_mode($deal['discount_mode'] ?? 'auto');
                    $deal_discount_value = $this->sanitize_deal_discount_value($deal['discount_value'] ?? 0);
                    $deal_badge = trim((string) ($deal['badge'] ?? ''));
                    $deal_label = trim((string) ($deal['label'] ?? ''));
                    $deal_id = 'nvcc_bundle_' . $product_id . '_' . $deal_index;
                    $deal_num_for_bonus = max(1, min(3, (int) ($deal['deal_num'] ?? $deal_index)));
                    $bonus_preview_enabled = (string) ($settings['bundle_bonus_preview_enabled'] ?? 'yes') === 'yes';
                    $bonus_preview = $bonus_preview_enabled
                        ? $this->get_bonus_preview_for_deal($product_id, $deal_num_for_bonus, $deal_qty, $deal, $settings, false)
                        : [];

                    $is_default_candidate = !empty($deal['is_default']) || (!$has_default_deal && $deal_index === 1);
                    $is_default = $is_default_candidate && !$default_rendered;
                    if ($is_default) {
                        $default_rendered = true;
                    }

                    $totals = $this->get_initial_bundle_totals($bundle_options, $deal_qty, $deal_discount_mode, $deal_discount_value, $deal_discount);
                    ?>
                    <?php
                    $savings_amount = $totals['regular'] - $totals['current'];
                    ?>
                    <article class="nvcc-deal<?php echo $is_default ? ' is-selected' : ''; ?><?php echo $deal_badge !== '' ? ' nvcc-deal--has-badge' : ''; ?>" data-deal-index="<?php echo esc_attr((string) $deal_index); ?>" data-qty="<?php echo esc_attr((string) $deal_qty); ?>" data-discount="<?php echo esc_attr((string) $deal_discount); ?>" data-discount-mode="<?php echo esc_attr($deal_discount_mode); ?>" data-discount-value="<?php echo esc_attr((string) $deal_discount_value); ?>"<?php echo !empty($deal['bogo']) ? ' data-bogo="1"' : ''; ?>>
                        <label class="nvcc-deal__head" for="<?php echo esc_attr($deal_id); ?>">
                            <span class="nvcc-deal__radio-wrap">
                                <input type="radio" id="<?php echo esc_attr($deal_id); ?>" name="<?php echo esc_attr($group_name); ?>" value="<?php echo esc_attr((string) $deal_index); ?>" <?php checked($is_default); ?> />
                            </span>
                            <span class="nvcc-deal__copy">
                                <span class="nvcc-deal__title"><?php echo esc_html((string) ($deal['title'] ?? '')); ?></span>
                                <span class="nvcc-deal__subtitle"><?php echo esc_html((string) ($deal['subtitle'] ?? '')); ?></span>
                                <?php if (($deal_discount_mode === 'percentage' || $deal_discount_mode === 'auto') && $deal_discount > 0) : ?>
                                    <span class="nvcc-deal__pct-badge">-<?php echo esc_html((floor($deal_discount) == $deal_discount) ? (string)(int)$deal_discount : rtrim(rtrim(number_format($deal_discount, 2, '.', ''), '0'), '.')); ?>%</span>
                                <?php elseif ($deal_discount_mode === 'fixed_amount' && $deal_discount_value > 0) : ?>
                                    <span class="nvcc-deal__pct-badge">-<?php echo wp_kses_post(wc_price($deal_discount_value)); ?></span>
                                <?php elseif ($deal_discount_mode === 'fixed_price' && $deal_discount_value > 0) : ?>
                                    <span class="nvcc-deal__pct-badge"><?php echo esc_html__('Fast pris', 'nv-commerce-core'); ?></span>
                                <?php endif; ?>
                                <?php if ($deal_label !== '') : ?>
                                    <span class="nvcc-deal__label"><?php echo esc_html($deal_label); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($deal['bogo'])) : ?>
                                    <span class="nvcc-deal__bogo-badge"><?php echo esc_html(sprintf(__('Köp %d betala för %d', 'nv-commerce-core'), $deal_qty, $deal_qty - 1)); ?></span>
                                <?php endif; ?>
                            </span>
                            <span class="nvcc-deal__prices">
                                <span class="nvcc-deal__price-current" data-price-current><?php echo wp_kses_post(wc_price($totals['current'])); ?></span>
                                <span class="nvcc-deal__price-regular" data-price-regular><?php echo wp_kses_post(wc_price($totals['regular'])); ?></span>
                                <?php if ($deal_qty > 1) : ?>
                                    <span class="nvcc-deal__per-unit" data-per-unit><?php echo wp_kses_post(wc_price($totals['current'] / $deal_qty)); ?>/st</span>
                                <?php endif; ?>
                                <?php if ($savings_amount > 0.009) : ?>
                                    <span class="nvcc-deal__savings" data-savings><?php echo wp_kses_post(sprintf(
                                        /* translators: %s = formatted price */
                                        __('Du sparar %s', 'nv-commerce-core'),
                                        wc_price($savings_amount)
                                    )); ?></span>
                                <?php endif; ?>
                            </span>
                        </label>

                        <?php if (!empty($bonus_preview['items']) && is_array($bonus_preview['items'])) :
                            $bonus_style = (string) ($bonus_preview['style'] ?? 'strip');
                            $bonus_items = $bonus_preview['items'];
                            $bonus_text = trim((string) ($bonus_preview['text'] ?? ''));
                            $bonus_cta = trim((string) ($bonus_preview['cta'] ?? __('+ Visa alla {count} böcker ▼', 'nv-commerce-core')));
                            if ($bonus_cta === '') {
                                $bonus_cta = __('+ Visa alla {count} böcker ▼', 'nv-commerce-core');
                            }

                            $bonus_panel_id = 'nvcc-bonus-panel-' . $product_id . '-' . $deal_index;
                            if ($deal_num_for_bonus <= 1) {
                                $visible_count = 1;
                            } elseif ($deal_num_for_bonus >= 3) {
                                $visible_count = 5;
                            } else {
                                $visible_count = 3;
                            }
                            $visible_items = array_slice($bonus_items, 0, $visible_count);
                            $first_visible_item = !empty($visible_items[0]) && is_array($visible_items[0]) ? $visible_items[0] : [];
                            $bonus_count = count($bonus_items);
                            $show_toggle = false;
                            if ($deal_num_for_bonus === 2) {
                                // Duo should expose the expandable title list even when exactly 3 bonuses exist.
                                $show_toggle = $bonus_count >= $visible_count;
                            } elseif ($deal_num_for_bonus >= 3) {
                                $show_toggle = $bonus_count > $visible_count;
                            }
                        ?>
                            <div class="nvcc-bonus nvcc-bonus--<?php echo esc_attr($bonus_style); ?> nvcc-bonus--deal-<?php echo esc_attr((string) $deal_num_for_bonus); ?>">
                                <?php if ($deal_num_for_bonus <= 1) : ?>
                                    <div class="nvcc-bonus__preview nvcc-bonus__preview--single" aria-label="<?php esc_attr_e('Bonusprodukter', 'nv-commerce-core'); ?>">
                                        <img
                                            class="nvcc-bonus__thumb"
                                            src="<?php echo esc_url((string) ($first_visible_item['image_url'] ?? '')); ?>"
                                            alt="<?php echo esc_attr((string) ($first_visible_item['title'] ?? '')); ?>"
                                            width="44"
                                            height="60"
                                            loading="lazy"
                                        />
                                        <span class="nvcc-bonus__single-title"><?php echo esc_html((string) ($first_visible_item['title'] ?? '')); ?></span>
                                    </div>
                                <?php else : ?>
                                    <div class="nvcc-bonus__preview nvcc-bonus__preview--compact">
                                        <div class="nvcc-bonus__strip" aria-label="<?php esc_attr_e('Bonusprodukter', 'nv-commerce-core'); ?>">
                                            <?php foreach ($visible_items as $item) : ?>
                                                <img
                                                    class="nvcc-bonus__thumb"
                                                    src="<?php echo esc_url((string) ($item['image_url'] ?? '')); ?>"
                                                    alt="<?php echo esc_attr((string) ($item['title'] ?? '')); ?>"
                                                    width="44"
                                                    height="60"
                                                    loading="lazy"
                                                />
                                            <?php endforeach; ?>
                                        </div>
                                        <?php if ($show_toggle) : ?>
                                            <button
                                                type="button"
                                                class="nvcc-bonus__toggle nvcc-bonus__toggle--inline"
                                                aria-expanded="false"
                                                aria-controls="<?php echo esc_attr($bonus_panel_id); ?>"
                                                data-open-text="<?php echo esc_attr(__('Visa färre ▲', 'nv-commerce-core')); ?>"
                                                data-close-text="<?php echo esc_attr($bonus_cta); ?>"
                                            >
                                                <?php echo esc_html($bonus_cta); ?>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($bonus_text !== '') : ?>
                                    <div class="nvcc-bonus__meta">
                                        <span class="nvcc-bonus__text"><?php echo esc_html($bonus_text); ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if ($show_toggle) : ?>
                                    <div id="<?php echo esc_attr($bonus_panel_id); ?>" class="nvcc-bonus__panel" hidden>
                                        <div class="nvcc-bonus__panel-grid">
                                            <?php foreach ($bonus_items as $item) : ?>
                                                <div class="nvcc-bonus__panel-item">
                                                    <img
                                                        class="nvcc-bonus__thumb"
                                                        src="<?php echo esc_url((string) ($item['image_url'] ?? '')); ?>"
                                                        alt="<?php echo esc_attr((string) ($item['title'] ?? '')); ?>"
                                                        width="44"
                                                        height="60"
                                                        loading="lazy"
                                                    />
                                                    <span class="nvcc-bonus__title"><?php echo esc_html((string) ($item['title'] ?? '')); ?></span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($deal_badge !== '') : ?>
                            <span class="nvcc-deal__badge"><?php echo esc_html($deal_badge); ?></span>
                        <?php endif; ?>

                        <div class="nvcc-deal__mix"<?php echo $is_default ? '' : ' hidden'; ?>>
                            <div class="nvcc-deal__mix-grid">
                                <?php for ($slot = 1; $slot <= $deal_qty; $slot++) :
                                    $first_option = !empty($bundle_options[0]) ? $bundle_options[0] : null;
                                    $default_thumb = $first_option ? esc_url((string) ($first_option['image_url'] ?? '')) : '';
                                ?>
                                    <div class="nvcc-deal__mix-row">
                                        <label><?php echo esc_html('#' . $slot); ?></label>
                                        <?php if ($default_thumb !== '') : ?>
                                            <img class="nvcc-deal__thumb" src="<?php echo $default_thumb; ?>" alt="" width="40" height="40" loading="lazy" />
                                        <?php endif; ?>
                                        <select class="nvcc-deal__select" data-slot="<?php echo esc_attr((string) $slot); ?>">
                                            <?php foreach ($bundle_options as $option) : ?>
                                                <option
                                                    value="<?php echo esc_attr((string) $option['id']); ?>"
                                                    data-type="<?php echo esc_attr((string) ($option['type'] ?? 'variation')); ?>"
                                                    data-price="<?php echo esc_attr((string) $option['price']); ?>"
                                                    data-regular="<?php echo esc_attr((string) $option['regular_price']); ?>"
                                                    data-thumb="<?php echo esc_url((string) ($option['image_url'] ?? '')); ?>"
                                                >
                                                    <?php echo esc_html((string) $option['label']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>

            <button type="button" class="button alt nvcc-bundle__submit"><?php echo esc_html($cta_label); ?></button>
            <?php if ($this->is_buy_now_enabled()) : ?>
                <button type="button" class="button nvcc-bundle__buy-now"><?php echo esc_html($this->get_buy_now_label()); ?></button>
            <?php endif; ?>
            <p class="nvcc-bundle__status" aria-live="polite"></p>
        </section>
        <?php
    }

    private function get_current_bulk_eligible_qty(): int {
        if (!function_exists('WC') || !WC() || !WC()->cart) {
            return 0;
        }

        $qty = 0;
        foreach (WC()->cart->get_cart() as $cart_item) {
            if (!isset($cart_item['data']) || !$cart_item['data'] instanceof WC_Product) {
                continue;
            }

            $item_product = $cart_item['data'];
            $parent_id = $item_product->is_type('variation') ? $item_product->get_parent_id() : $item_product->get_id();
            if ($parent_id <= 0 || !$this->is_product_bulk_eligible((int) $parent_id)) {
                continue;
            }

            $qty += max(0, (int) ($cart_item['quantity'] ?? 0));
        }

        return $qty;
    }

    public function handle_bundle_ajax(): void {
        $nonce = isset($_POST['nonce'])
            ? sanitize_text_field(wp_unslash((string) $_POST['nonce']))
            : '';

        if (!wp_verify_nonce($nonce, 'nvcc_bundle_nonce')) {
            wp_send_json_error([
                'code' => 'invalid_nonce',
                'message' => __('Din session uppdaterades. Försök igen.', 'nv-commerce-core'),
                'nonce' => wp_create_nonce('nvcc_bundle_nonce'),
            ], 403);
        }

        if (!function_exists('WC') || !WC() || !WC()->cart) {
            wp_send_json_error(['message' => __('Kunde inte nå varukorgen.', 'nv-commerce-core')], 400);
        }

        $product_id = isset($_POST['product_id']) ? absint((string) $_POST['product_id']) : 0;
        $items = $_POST['items'] ?? null;
        $deal = $_POST['deal'] ?? null;

        $product = $product_id > 0 ? wc_get_product($product_id) : null;
        if (!$product instanceof WC_Product || !is_array($items)) {
            wp_send_json_error(['message' => __('Ogiltig produktdata.', 'nv-commerce-core')], 400);
        }

        if (!in_array($product->get_type(), ['simple', 'variable'], true)) {
            wp_send_json_error(['message' => __('Den här produkttypen stöds inte av paketköp.', 'nv-commerce-core')], 400);
        }

        $deal_mode = 'auto';
        $deal_value = 0.0;
        $deal_title = '';
        if (is_array($deal)) {
            $deal_mode = $this->sanitize_deal_discount_mode($deal['mode'] ?? 'auto');
            $deal_value = $this->sanitize_deal_discount_value($deal['value'] ?? 0);
            $deal_title = sanitize_text_field((string) ($deal['title'] ?? ''));
        }
        $has_custom_deal_discount = in_array($deal_mode, ['percentage', 'fixed_amount', 'fixed_price'], true) && $deal_value > 0;
        $bundle_group_token = $has_custom_deal_discount ? wp_generate_uuid4() : '';

        $added_total = 0;

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $qty = absint((string) ($item['qty'] ?? 0));

            if ($qty <= 0) {
                continue;
            }

            $cart_item_data = [];
            if ($has_custom_deal_discount) {
                $cart_item_data['_nvcc_bundle_group'] = $bundle_group_token;
                $cart_item_data['_nvcc_bundle_deal_mode'] = $deal_mode;
                $cart_item_data['_nvcc_bundle_deal_value'] = $deal_value;
                if ($deal_title !== '') {
                    $cart_item_data['_nvcc_bundle_deal_title'] = $deal_title;
                }
            }

            if ($product->is_type('simple')) {
                $item_product_id = absint((string) ($item['product_id'] ?? $product_id));
                if ($item_product_id !== (int) $product_id || !$product->is_purchasable() || !$product->is_in_stock()) {
                    continue;
                }

                $added = WC()->cart->add_to_cart($product_id, $qty, 0, [], $cart_item_data);
                if ($added) {
                    $added_total += $qty;
                }

                continue;
            }

            $variation_id = absint((string) ($item['variation_id'] ?? 0));
            if ($variation_id <= 0) {
                continue;
            }

            $variation = wc_get_product($variation_id);
            if (!$variation instanceof WC_Product_Variation || (int) $variation->get_parent_id() !== (int) $product_id) {
                continue;
            }

            $attributes = [];
            foreach ($variation->get_attributes() as $attribute_name => $attribute_value) {
                $key = strpos((string) $attribute_name, 'attribute_') === 0
                    ? (string) $attribute_name
                    : 'attribute_' . sanitize_title((string) $attribute_name);
                $attributes[$key] = (string) $attribute_value;
            }

            $added = WC()->cart->add_to_cart($product_id, $qty, $variation_id, $attributes, $cart_item_data);
            if ($added) {
                $added_total += $qty;
            }
        }

        if ($added_total <= 0) {
            wp_send_json_error(['message' => __('Ingen produkt kunde läggas till.', 'nv-commerce-core')], 400);
        }

        wp_send_json_success([
            'message' => __('Produkter tillagda i varukorgen.', 'nv-commerce-core'),
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_hash' => WC()->cart->get_cart_hash(),
        ]);
    }

    public function handle_bundle_nonce_refresh_ajax(): void {
        nocache_headers();
        wp_send_json_success([
            'nonce' => wp_create_nonce('nvcc_bundle_nonce'),
        ]);
    }

    public function handle_admin_target_search_ajax(): void {
        if (!$this->has_admin_access()) {
            wp_send_json_error(['message' => __('Saknar behörighet.', 'nv-commerce-core')], 403);
        }

        $nonce = isset($_GET['nonce']) ? sanitize_text_field(wp_unslash((string) $_GET['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'nvcc_admin_target_search')) {
            wp_send_json_error(['message' => __('Ogiltig nonce.', 'nv-commerce-core')], 403);
        }

        $entity = sanitize_key((string) ($_GET['entity'] ?? ''));
        $query = sanitize_text_field((string) ($_GET['q'] ?? ''));
        $results = [];

        if ($entity === 'product') {
            $products = wc_get_products([
                'status' => 'publish',
                'limit' => 20,
                's' => $query,
            ]);

            foreach ($products as $product) {
                if (!$product instanceof WC_Product) {
                    continue;
                }
                $results[] = [
                    'id' => (int) $product->get_id(),
                    'label' => (string) $product->get_name(),
                ];
            }
        } else {
            $taxonomy = '';
            if ($entity === 'category') {
                $taxonomy = 'product_cat';
            } elseif ($entity === 'tag') {
                $taxonomy = 'product_tag';
            } elseif ($entity === 'brand') {
                $brand_taxonomies = $this->detect_brand_taxonomies();
                $taxonomy = !empty($brand_taxonomies) ? (string) $brand_taxonomies[0] : '';
            }

            if ($taxonomy === '' || !taxonomy_exists($taxonomy)) {
                wp_send_json_success([]);
            }

            $terms = get_terms([
                'taxonomy' => $taxonomy,
                'hide_empty' => false,
                'number' => 20,
                'search' => $query,
            ]);

            if (is_array($terms)) {
                foreach ($terms as $term) {
                    if (!$term instanceof WP_Term) {
                        continue;
                    }
                    $results[] = [
                        'id' => (int) $term->term_id,
                        'label' => (string) $term->name,
                    ];
                }
            }
        }

        wp_send_json_success($results);
    }

    public function enqueue_admin_assets(string $hook): void {
        $core_slugs = [
            'toplevel_page_' . self::CORE_MENU_SLUG,
            'woocommerce_page_' . self::CORE_MENU_SLUG,
            'settings_page_' . self::CORE_MENU_SLUG,
        ];
        if (!in_array($hook, $core_slugs, true)) {
            return;
        }
        wp_enqueue_style(
            'nvcc-admin-dashboard',
            plugin_dir_url(__FILE__) . 'assets/css/nv-commerce-core-admin.css',
            [],
            NVCC_VERSION
        );
    }

    public function register_admin_menu(): void {
        $capability = $this->resolve_admin_capability();

        add_menu_page(
            __('AS Commerce Core', 'nv-commerce-core'),
            __('AS Commerce Core', 'nv-commerce-core'),
            $capability,
            self::CORE_MENU_SLUG,
            [$this, 'render_settings_page'],
            'dashicons-store',
            self::MENU_POSITION
        );
    }

    private function resolve_admin_capability(): string {
        $capability = apply_filters('nvcc_admin_capability', 'manage_woocommerce');
        if (!is_string($capability) || $capability === '') {
            return 'manage_woocommerce';
        }

        return sanitize_key($capability);
    }

    private function has_admin_access(): bool {
        return current_user_can($this->resolve_admin_capability())
            || current_user_can('manage_woocommerce')
            || current_user_can('manage_options')
            || current_user_can('activate_plugins');
    }

    public function redirect_legacy_settings_pages(): void {
        if (!is_admin() || !isset($_GET['page'])) {
            return;
        }

        $page = sanitize_key((string) wp_unslash($_GET['page']));
        if ($page === self::LEGACY_CORE_MENU_SLUG) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::CORE_MENU_SLUG));
            exit;
        }

        if ($page === self::LEGACY_SMART_UPSELL_MENU_SLUG) {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SMART_UPSELL_MENU_SLUG));
            exit;
        }
    }

    public function add_plugin_action_links(array $links): array {
        $core_url = admin_url('admin.php?page=' . self::CORE_MENU_SLUG);
        $upsell_url = admin_url('admin.php?page=' . self::SMART_UPSELL_MENU_SLUG);

        array_unshift(
            $links,
            '<a href="' . esc_url($core_url) . '">' . esc_html__('Inställningar', 'nv-commerce-core') . '</a>'
        );
        $links[] = '<a href="' . esc_url($upsell_url) . '">' . esc_html__('Smart Upsell', 'nv-commerce-core') . '</a>';

        return $links;
    }

    public function register_settings(): void {
        register_setting('nvcc_settings_group', self::OPTION_KEY, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => $this->get_settings(),
        ]);
    }

    private function sanitize_offer_campaigns($raw): array {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : [];
        }

        if (!is_array($raw)) {
            return [];
        }

        $campaigns = [];

        foreach ($raw as $index => $campaign) {
            if (!is_array($campaign)) {
                continue;
            }

            $name = sanitize_text_field((string) ($campaign['name'] ?? ''));
            $target_mode = sanitize_key((string) ($campaign['target_mode'] ?? ''));
            if (!in_array($target_mode, ['all_products', 'specific_products', 'specific_categories', 'specific_tags', 'specific_brands'], true)) {
                $target_mode = '';
            }

            $product_ids = $this->normalize_id_list($campaign['product_ids'] ?? []);
            $category_ids = $this->normalize_id_list($campaign['category_ids'] ?? []);
            $tag_ids = $this->normalize_id_list($campaign['tag_ids'] ?? []);
            $brand_ids = $this->normalize_id_list($campaign['brand_ids'] ?? []);

            $product_selectors = sanitize_textarea_field((string) ($campaign['product_selectors'] ?? ''));
            $category_selectors = sanitize_textarea_field((string) ($campaign['category_selectors'] ?? ''));

            if (empty($product_ids) && $product_selectors !== '') {
                $product_ids = $this->extract_id_values_from_selectors($product_selectors);
            }

            if (empty($category_ids) && $category_selectors !== '') {
                $category_ids = $this->extract_id_values_from_selectors($category_selectors);
            }

            if ($target_mode === '') {
                if (!empty($product_ids)) {
                    $target_mode = 'specific_products';
                } elseif (!empty($category_ids)) {
                    $target_mode = 'specific_categories';
                } else {
                    $target_mode = 'specific_products';
                }
            }

            $product_selectors = '';
            $category_selectors = '';

            $has_target_payload = ($target_mode === 'all_products')
                || !empty($product_ids)
                || !empty($category_ids)
                || !empty($tag_ids)
                || !empty($brand_ids);

            if (
                $name === '' &&
                !$has_target_payload &&
                trim($product_selectors) === '' &&
                trim($category_selectors) === ''
            ) {
                continue;
            }

            $id = sanitize_key((string) ($campaign['id'] ?? ''));
            if ($id === '') {
                $id = 'campaign_' . substr(md5((string) $index . '|' . $name . '|' . wp_json_encode($campaign)), 0, 12);
            }

            $deals = $this->normalize_bundle_deals(
                $campaign['deals'] ?? [],
                $this->get_legacy_deals_from_source($campaign, true),
                true
            );
            $deal_count = max(1, count($deals));

            $sanitized_campaign = [
                'id' => $id,
                'name' => $name === '' ? sprintf(__('Campaign %d', 'nv-commerce-core'), (int) $index + 1) : $name,
                'status' => sanitize_key((string) ($campaign['status'] ?? 'active')) === 'inactive' ? 'inactive' : 'active',
                'priority' => max(0, absint((string) ($campaign['priority'] ?? 0))),
                'match_mode' => sanitize_key((string) ($campaign['match_mode'] ?? 'any')) === 'all' ? 'all' : 'any',
                'target_mode' => $target_mode,
                'product_ids' => $product_ids,
                'category_ids' => $category_ids,
                'tag_ids' => $tag_ids,
                'brand_ids' => $brand_ids,
                'product_selectors' => trim($product_selectors),
                'category_selectors' => trim($category_selectors),
                'headline' => sanitize_text_field((string) ($campaign['headline'] ?? '')),
                'popular_index' => max(1, min($deal_count, absint((string) ($campaign['popular_index'] ?? 2)))),
                'default_index' => max(1, min($deal_count, absint((string) ($campaign['default_index'] ?? 2)))),
                'deals' => $deals,
            ];

            for ($i = 1; $i <= 3; $i++) {
                $deal = $deals[$i - 1] ?? [
                    'qty' => $i,
                    'title' => '',
                    'subtitle' => '',
                    'badge' => '',
                    'label' => '',
                    'discount_mode' => 'auto',
                    'discount_value' => '',
                    'discount' => '',
                    'bogo' => 'no',
                ];

                $sanitized_campaign['deal_' . $i . '_qty'] = max(1, absint((string) ($deal['qty'] ?? $i)));
                $sanitized_campaign['deal_' . $i . '_title'] = sanitize_text_field((string) ($deal['title'] ?? ''));
                $sanitized_campaign['deal_' . $i . '_subtitle'] = sanitize_text_field((string) ($deal['subtitle'] ?? ''));
                $sanitized_campaign['deal_' . $i . '_badge'] = sanitize_text_field((string) ($deal['badge'] ?? ''));
                $sanitized_campaign['deal_' . $i . '_label'] = sanitize_text_field((string) ($deal['label'] ?? ''));

                $discount_raw = $deal['discount'] ?? '';
                $discount_raw = is_scalar($discount_raw) ? trim((string) $discount_raw) : '';
                $discount_mode = $this->sanitize_deal_discount_mode($deal['discount_mode'] ?? 'auto');
                $discount_value = $this->sanitize_deal_discount_value($deal['discount_value'] ?? ($discount_raw === '' ? 0 : $discount_raw));
                if ($discount_mode === 'auto' && $discount_raw !== '') {
                    $discount_mode = 'percentage';
                }
                $sanitized_campaign['deal_' . $i . '_discount_mode'] = $discount_mode;
                $sanitized_campaign['deal_' . $i . '_discount_value'] = $discount_value;
                $sanitized_campaign['deal_' . $i . '_discount'] = $discount_raw === '' ? '' : max(0.0, (float) $discount_raw);
                if ($discount_mode === 'percentage' && $discount_value > 0) {
                    $sanitized_campaign['deal_' . $i . '_discount'] = $discount_value;
                }
                $sanitized_campaign['deal_' . $i . '_bogo'] = (($deal['bogo'] ?? 'no') === 'yes') ? 'yes' : 'no';
            }

            $campaigns[] = $sanitized_campaign;
        }

        return $campaigns;
    }

    public function sanitize_settings($input): array {
        $defaults = $this->get_settings();
        $input = is_array($input) ? $input : [];
        $bundle_deals = $this->normalize_bundle_deals(
            $input['bundle_deals_json'] ?? ($input['bundle_deals'] ?? []),
            $this->get_legacy_deals_from_source($input, true),
            true
        );
        $deal_count = max(1, count($bundle_deals));

        $sanitized = [
            'enable_bulk_discount' => (!empty($input['enable_bulk_discount']) && $input['enable_bulk_discount'] === 'yes') ? 'yes' : 'no',
            'bulk_label' => sanitize_text_field((string) ($input['bulk_label'] ?? $defaults['bulk_label'])),
            'tier_2_qty' => max(1, absint((string) ($input['tier_2_qty'] ?? $defaults['tier_2_qty']))),
            'tier_2_pct' => max(0, (float) ($input['tier_2_pct'] ?? $defaults['tier_2_pct'])),
            'tier_3_qty' => max(1, absint((string) ($input['tier_3_qty'] ?? $defaults['tier_3_qty']))),
            'tier_3_pct' => max(0, (float) ($input['tier_3_pct'] ?? $defaults['tier_3_pct'])),
            'tier_4_qty' => max(1, absint((string) ($input['tier_4_qty'] ?? $defaults['tier_4_qty']))),
            'tier_4_pct' => max(0, (float) ($input['tier_4_pct'] ?? $defaults['tier_4_pct'])),
            'enable_variation_bundle' => (!empty($input['enable_variation_bundle']) && $input['enable_variation_bundle'] === 'yes') ? 'yes' : 'no',
            'bundle_subtitle' => sanitize_text_field((string) ($input['bundle_subtitle'] ?? $defaults['bundle_subtitle'])),
            'bundle_variant_style' => in_array(($input['bundle_variant_style'] ?? 'a'), ['a', 'b', 'c'], true) ? (string) $input['bundle_variant_style'] : 'a',
            'bundle_cta_label' => sanitize_text_field((string) ($input['bundle_cta_label'] ?? $defaults['bundle_cta_label'])),
            'bundle_headline' => sanitize_text_field((string) ($input['bundle_headline'] ?? $defaults['bundle_headline'] ?? '')),
            'bundle_timer_enabled' => (!empty($input['bundle_timer_enabled']) && $input['bundle_timer_enabled'] === 'yes') ? 'yes' : 'no',
            'bundle_timer_minutes' => max(1, min(1440, absint((string) ($input['bundle_timer_minutes'] ?? ($defaults['bundle_timer_minutes'] ?? 15))))),
            'bundle_timer_text' => sanitize_text_field((string) ($input['bundle_timer_text'] ?? ($defaults['bundle_timer_text'] ?? __('Erbjudandet slutar om', 'nv-commerce-core')))),
            'bundle_popular_index' => max(1, min($deal_count, absint((string) ($input['bundle_popular_index'] ?? $defaults['bundle_popular_index'])))),
            'bundle_default_index' => max(1, min($deal_count, absint((string) ($input['bundle_default_index'] ?? $defaults['bundle_default_index'])))),
            'bundle_deals' => $bundle_deals,
            'bundle_bonus_preview_enabled' => (!empty($input['bundle_bonus_preview_enabled']) && $input['bundle_bonus_preview_enabled'] === 'yes') ? 'yes' : 'no',
            'bundle_bonus_display_style' => in_array((string) ($input['bundle_bonus_display_style'] ?? 'auto'), ['auto', 'strip', 'grid'], true) ? (string) $input['bundle_bonus_display_style'] : 'auto',
            'bundle_bonus_thumb_size' => in_array((string) ($input['bundle_bonus_thumb_size'] ?? 'thumbnail'), ['thumbnail', 'woocommerce_thumbnail', 'medium', 'full'], true) ? (string) $input['bundle_bonus_thumb_size'] : 'thumbnail',
            'bundle_bonus_details_cta' => sanitize_text_field((string) ($input['bundle_bonus_details_cta'] ?? $defaults['bundle_bonus_details_cta'] ?? __('+ Visa alla {count} böcker ▼', 'nv-commerce-core'))),
            'buy_now_enabled' => (($input['buy_now_enabled'] ?? ($defaults['buy_now_enabled'] ?? 'yes')) === 'no') ? 'no' : 'yes',
            'buy_now_label' => sanitize_text_field((string) ($input['buy_now_label'] ?? ($defaults['buy_now_label'] ?? __('Buy Now', 'nv-commerce-core')))),
            'buy_now_redirect_target' => in_array(sanitize_key((string) ($input['buy_now_redirect_target'] ?? ($defaults['buy_now_redirect_target'] ?? 'checkout'))), ['checkout', 'cart'], true)
                ? sanitize_key((string) ($input['buy_now_redirect_target'] ?? ($defaults['buy_now_redirect_target'] ?? 'checkout')))
                : 'checkout',
            'offer_campaigns' => $this->sanitize_offer_campaigns($input['offer_campaigns_json'] ?? ($input['offer_campaigns'] ?? ($defaults['offer_campaigns'] ?? []))),
            'bonus_entitlements_enabled' => (array_key_exists('bonus_entitlements_enabled', $input) && (string) $input['bonus_entitlements_enabled'] === 'no') ? 'no' : (array_key_exists('bonus_entitlements_enabled', $input) ? 'yes' : ((string) ($defaults['bonus_entitlements_enabled'] ?? 'yes') === 'no' ? 'no' : 'yes')),
            'bonus_match_product_selectors' => trim((string) ($input['bonus_match_product_selectors'] ?? ($defaults['bonus_match_product_selectors'] ?? ''))),
            'bonus_tier_1_min_qty' => max(1, (int) ($input['bonus_tier_1_min_qty'] ?? ($defaults['bonus_tier_1_min_qty'] ?? 1))),
            'bonus_tier_1_selectors' => trim((string) ($input['bonus_tier_1_selectors'] ?? ($defaults['bonus_tier_1_selectors'] ?? ''))),
            'bonus_tier_2_min_qty' => max(1, (int) ($input['bonus_tier_2_min_qty'] ?? ($defaults['bonus_tier_2_min_qty'] ?? 2))),
            'bonus_tier_2_selectors' => trim((string) ($input['bonus_tier_2_selectors'] ?? ($defaults['bonus_tier_2_selectors'] ?? ''))),
            'bonus_tier_3_min_qty' => max(1, (int) ($input['bonus_tier_3_min_qty'] ?? ($defaults['bonus_tier_3_min_qty'] ?? 3))),
            'bonus_tier_3_selectors' => trim((string) ($input['bonus_tier_3_selectors'] ?? ($defaults['bonus_tier_3_selectors'] ?? ''))),
            'bonus_idempotency_meta_key' => sanitize_key((string) ($input['bonus_idempotency_meta_key'] ?? ($defaults['bonus_idempotency_meta_key'] ?? '_nvob_bonuses_granted'))),
            'bonus_debug_order_notes' => (array_key_exists('bonus_debug_order_notes', $input) && (string) $input['bonus_debug_order_notes'] === 'yes') ? 'yes' : ((string) ($defaults['bonus_debug_order_notes'] ?? 'no') === 'yes' ? 'yes' : 'no'),
        ];

        $bonus_defaults = $this->get_bonus_module_defaults();
        if ($sanitized['bonus_match_product_selectors'] === '') {
            $sanitized['bonus_match_product_selectors'] = (string) $bonus_defaults['bonus_match_product_selectors'];
        }
        if ($sanitized['bonus_tier_1_selectors'] === '') {
            $sanitized['bonus_tier_1_selectors'] = (string) $bonus_defaults['bonus_tier_1_selectors'];
        }
        if ($sanitized['bonus_tier_2_selectors'] === '') {
            $sanitized['bonus_tier_2_selectors'] = (string) $bonus_defaults['bonus_tier_2_selectors'];
        }
        if ($sanitized['bonus_tier_3_selectors'] === '') {
            $sanitized['bonus_tier_3_selectors'] = (string) $bonus_defaults['bonus_tier_3_selectors'];
        }
        if ($sanitized['bonus_idempotency_meta_key'] === '') {
            $sanitized['bonus_idempotency_meta_key'] = (string) $bonus_defaults['bonus_idempotency_meta_key'];
        }

        $legacy_defaults = $this->get_legacy_deals_from_source($defaults, true);
        for ($i = 1; $i <= 3; $i++) {
            $deal = $bundle_deals[$i - 1] ?? ($legacy_defaults[$i - 1] ?? [
                'qty' => $i,
                'title' => '',
                'subtitle' => '',
                'badge' => '',
                'label' => '',
                'discount_mode' => 'auto',
                'discount_value' => '',
                'discount' => '',
                'bogo' => 'no',
            ]);

            $sanitized['bundle_deal_' . $i . '_qty'] = max(1, absint((string) ($deal['qty'] ?? $i)));
            $sanitized['bundle_deal_' . $i . '_title'] = sanitize_text_field((string) ($deal['title'] ?? ''));
            $sanitized['bundle_deal_' . $i . '_subtitle'] = sanitize_text_field((string) ($deal['subtitle'] ?? ''));
            $sanitized['bundle_deal_' . $i . '_badge'] = sanitize_text_field((string) ($deal['badge'] ?? ''));
            $sanitized['bundle_deal_' . $i . '_label'] = sanitize_text_field((string) ($deal['label'] ?? ''));
            $discount_mode = $this->sanitize_deal_discount_mode($deal['discount_mode'] ?? 'auto');
            $discount_value = $this->sanitize_deal_discount_value($deal['discount_value'] ?? ($deal['discount'] ?? 0));
            if ($discount_mode === 'auto' && trim((string) ($deal['discount'] ?? '')) !== '') {
                $discount_mode = 'percentage';
            }
            $sanitized['bundle_deal_' . $i . '_discount_mode'] = $discount_mode;
            $sanitized['bundle_deal_' . $i . '_discount_value'] = $discount_value;
            $sanitized['bundle_deal_' . $i . '_discount'] = ($discount_mode === 'percentage' && $discount_value > 0) ? $discount_value : '';
            $sanitized['bundle_deal_' . $i . '_bogo'] = (($deal['bogo'] ?? 'no') === 'yes') ? 'yes' : 'no';
        }

        return $sanitized;
    }

    public function render_settings_page(): void {
        if (!$this->has_admin_access()) {
            return;
        }

        $settings = $this->get_settings();
        $option_key = self::OPTION_KEY;
        $bundle_deals = $this->normalize_bundle_deals(
            $settings['bundle_deals'] ?? [],
            $this->get_legacy_deals_from_source($settings, true),
            true
        );
        $bundle_deals_json = wp_json_encode($bundle_deals, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($bundle_deals_json)) {
            $bundle_deals_json = '[]';
        }
        $offer_campaigns = $this->hydrate_offer_campaigns_for_admin($this->get_offer_campaigns_from_settings($settings));
        $offer_campaigns_json = wp_json_encode($offer_campaigns, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($offer_campaigns_json)) {
            $offer_campaigns_json = '[]';
        }
        $admin_target_search_nonce = wp_create_nonce('nvcc_admin_target_search');

        $active_modules = 0;
        if (($settings['enable_bulk_discount'] ?? '') === 'yes') { $active_modules++; }
        if (($settings['enable_variation_bundle'] ?? '') === 'yes') { $active_modules++; }
        if (($settings['buy_now_enabled'] ?? 'yes') === 'yes') { $active_modules++; }
        if (($settings['bundle_bonus_preview_enabled'] ?? 'yes') === 'yes') { $active_modules++; }
        if (($settings['bundle_timer_enabled'] ?? 'no') === 'yes') { $active_modules++; }
        $campaign_count = is_array($offer_campaigns) ? count($offer_campaigns) : 0;
        $deal_count = is_array($bundle_deals) ? count($bundle_deals) : 0;
        ?>
        <div class="wrap nvcc-admin-wrap" data-nvcc-theme="light">

            <div class="nvcc-admin-header">
                <div class="nvcc-admin-header-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2.5 3.5h2.2l2.2 11.2a1.6 1.6 0 0 0 1.6 1.3h8.4a1.6 1.6 0 0 0 1.6-1.3L20.5 7H6"/></svg></div>
                <div class="nvcc-admin-header-content">
                    <h1 class="nvcc-admin-header-title">NV Commerce Core <span class="nvcc-admin-header-badge"><?php echo esc_html('v' . NVCC_VERSION); ?></span></h1>
                    <p class="nvcc-admin-header-subtitle"><?php esc_html_e('Bundle deals, volume discounts and conversion tools for product pages', 'nv-commerce-core'); ?></p>
                </div>
                <div class="nvcc-admin-header-actions">
                    <button type="button" class="nvcc-admin-theme-toggle" id="nvcc-theme-toggle" aria-label="<?php esc_attr_e('Toggle dark mode', 'nv-commerce-core'); ?>" title="<?php esc_attr_e('Toggle dark mode', 'nv-commerce-core'); ?>"></button>
                    <button type="submit" form="nvcc-settings-form" id="nvcc-save-top" class="nvcc-admin-btn nvcc-admin-btn--primary" disabled aria-disabled="true"><?php esc_html_e('Save Changes', 'nv-commerce-core'); ?></button>
                </div>
            </div>

            <div class="nvcc-admin-stats">
                <div class="nvcc-admin-stat-card">
                    <div class="nvcc-admin-stat-icon nvcc-admin-stat-icon--teal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.3 7L12 12l8.7-5M12 22V12"/></svg></div>
                    <div class="nvcc-admin-stat-content">
                        <div class="nvcc-admin-stat-number"><?php echo esc_html((string) $active_modules); ?><span class="nvcc-admin-stat-number-sub"> / 6</span></div>
                        <div class="nvcc-admin-stat-label"><?php esc_html_e('Active Modules', 'nv-commerce-core'); ?></div>
                        <div class="nvcc-admin-stat-bar"><span style="width:<?php echo esc_attr((string) (int) round(($active_modules / 6) * 100)); ?>%;"></span></div>
                    </div>
                </div>
                <div class="nvcc-admin-stat-card">
                    <div class="nvcc-admin-stat-icon nvcc-admin-stat-icon--blue"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.3"/></svg></div>
                    <div class="nvcc-admin-stat-content">
                        <div class="nvcc-admin-stat-number"><?php echo esc_html((string) $campaign_count); ?></div>
                        <div class="nvcc-admin-stat-label"><?php esc_html_e('Campaigns', 'nv-commerce-core'); ?></div>
                        <span class="nvcc-admin-stat-hint"><?php esc_html_e('Targeted product offers', 'nv-commerce-core'); ?></span>
                    </div>
                </div>
                <div class="nvcc-admin-stat-card">
                    <div class="nvcc-admin-stat-icon nvcc-admin-stat-icon--amber"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.6 13.4l-7.2 7.2a2 2 0 0 1-2.83 0l-7-7A2 2 0 0 1 3 12.17V5a2 2 0 0 1 2-2h7.17a2 2 0 0 1 1.41.59l7.02 7.02a2 2 0 0 1 0 2.79z"/><circle cx="7.5" cy="7.5" r="1.4"/></svg></div>
                    <div class="nvcc-admin-stat-content">
                        <div class="nvcc-admin-stat-number"><?php echo esc_html((string) $deal_count); ?></div>
                        <div class="nvcc-admin-stat-label"><?php esc_html_e('Bundle Deals', 'nv-commerce-core'); ?></div>
                        <span class="nvcc-admin-stat-hint"><?php esc_html_e('Global deal tiers', 'nv-commerce-core'); ?></span>
                    </div>
                </div>
                <div class="nvcc-admin-stat-card">
                    <div class="nvcc-admin-stat-icon nvcc-admin-stat-icon--purple"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L4.5 13.5H11l-1 8.5L19.5 10.5H13z"/></svg></div>
                    <div class="nvcc-admin-stat-content">
                        <div class="nvcc-admin-stat-number">3</div>
                        <div class="nvcc-admin-stat-label"><?php esc_html_e('Discount Tiers', 'nv-commerce-core'); ?></div>
                        <span class="nvcc-admin-stat-hint"><?php esc_html_e('Volume pricing', 'nv-commerce-core'); ?></span>
                    </div>
                </div>
            </div>

            <div class="nvcc-admin-content">

                <div class="nvcc-admin-tabs" role="tablist">
                    <button type="button" class="nvcc-admin-tab is-active" role="tab" data-nvcc-tab="modules"><?php esc_html_e('Modules', 'nv-commerce-core'); ?> <span class="nvcc-admin-tab-count">6</span></button>
                    <button type="button" class="nvcc-admin-tab" role="tab" data-nvcc-tab="campaigns"><?php esc_html_e('Offer Campaigns', 'nv-commerce-core'); ?> <span class="nvcc-admin-tab-count"><?php echo esc_html((string) $campaign_count); ?></span></button>
                    <button type="button" class="nvcc-admin-tab" role="tab" data-nvcc-tab="deals"><?php esc_html_e('Bundle Deals', 'nv-commerce-core'); ?> <span class="nvcc-admin-tab-count"><?php echo esc_html((string) $deal_count); ?></span></button>
                    <button type="button" class="nvcc-admin-tab" role="tab" data-nvcc-tab="settings"><?php esc_html_e('Global Settings', 'nv-commerce-core'); ?></button>
                </div>

                <form method="post" action="options.php" id="nvcc-settings-form">
                    <?php settings_fields('nvcc_settings_group'); ?>

                    <!-- ═══ MODULES TAB ═══ -->
                    <div class="nvcc-admin-tab-panel is-active" data-nvcc-panel="modules">
                        <div class="nvcc-admin-modules-grid">
                            <div class="nvcc-admin-module-card<?php echo ($settings['enable_bulk_discount'] ?? '') === 'yes' ? ' is-active' : ''; ?>">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 5L5 19"/><circle cx="7.5" cy="7.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Volume Discounts', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version">Volymrabatt</span>
                                    </div>
                                    <label class="nvcc-admin-toggle">
                                        <input type="checkbox" name="<?php echo esc_attr($option_key); ?>[enable_bulk_discount]" value="yes" <?php checked($settings['enable_bulk_discount'], 'yes'); ?> data-nvcc-module-toggle>
                                        <span class="nvcc-admin-toggle-track"></span>
                                    </label>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Tiered pricing that rewards customers for buying more. Shows discount badges and savings on the product page.', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--pricing"><?php esc_html_e('Pricing', 'nv-commerce-core'); ?></span>
                                    <a href="#" class="nvcc-admin-module-link" data-nvcc-goto="settings"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>

                            <div class="nvcc-admin-module-card<?php echo ($settings['enable_variation_bundle'] ?? '') === 'yes' ? ' is-active' : ''; ?>">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Bundle Layout', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version"><?php esc_html_e('Variation bundle display', 'nv-commerce-core'); ?></span>
                                    </div>
                                    <label class="nvcc-admin-toggle">
                                        <input type="checkbox" name="<?php echo esc_attr($option_key); ?>[enable_variation_bundle]" value="yes" <?php checked($settings['enable_variation_bundle'], 'yes'); ?> data-nvcc-module-toggle>
                                        <span class="nvcc-admin-toggle-track"></span>
                                    </label>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Kaching-style bundle selector with headlines, CTA buttons and variant styles (A / B / C).', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--layout"><?php esc_html_e('Layout', 'nv-commerce-core'); ?></span>
                                    <a href="#" class="nvcc-admin-module-link" data-nvcc-goto="settings"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>

                            <div class="nvcc-admin-module-card<?php echo ($settings['buy_now_enabled'] ?? 'yes') === 'yes' ? ' is-active' : ''; ?>">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L4.5 13.5H11l-1 8.5L19.5 10.5H13z"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Buy Now', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version"><?php esc_html_e('Quick checkout button', 'nv-commerce-core'); ?></span>
                                    </div>
                                    <label class="nvcc-admin-toggle">
                                        <input type="checkbox" name="<?php echo esc_attr($option_key); ?>[buy_now_enabled]" value="yes" <?php checked(($settings['buy_now_enabled'] ?? 'yes'), 'yes'); ?> data-nvcc-module-toggle>
                                        <span class="nvcc-admin-toggle-track"></span>
                                    </label>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Adds a prominent "Buy Now" button that skips the cart and sends customers directly to checkout.', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--conversion"><?php esc_html_e('Conversion', 'nv-commerce-core'); ?></span>
                                    <a href="#" class="nvcc-admin-module-link" data-nvcc-goto="settings"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>

                            <div class="nvcc-admin-module-card<?php echo ($settings['bundle_bonus_preview_enabled'] ?? 'yes') === 'yes' ? ' is-active' : ''; ?>">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8"/><rect x="2.5" y="7.5" width="19" height="4.5" rx="1"/><path d="M12 7.5V21"/><path d="M12 7.5H7.75a2.25 2.25 0 0 1 0-4.5C11 3 12 7.5 12 7.5z"/><path d="M12 7.5h4.25a2.25 2.25 0 0 0 0-4.5C13 3 12 7.5 12 7.5z"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Bonus Display', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version"><?php esc_html_e('Free gift previews', 'nv-commerce-core'); ?></span>
                                    </div>
                                    <label class="nvcc-admin-toggle">
                                        <input type="checkbox" name="<?php echo esc_attr($option_key); ?>[bundle_bonus_preview_enabled]" value="yes" <?php checked(($settings['bundle_bonus_preview_enabled'] ?? 'yes'), 'yes'); ?> data-nvcc-module-toggle>
                                        <span class="nvcc-admin-toggle-track"></span>
                                    </label>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Shows thumbnails and details of bonus products included with the deal — strip, grid or auto layout.', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--upsell"><?php esc_html_e('Upsell', 'nv-commerce-core'); ?></span>
                                    <a href="#" class="nvcc-admin-module-link" data-nvcc-goto="settings"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>

                            <div class="nvcc-admin-module-card<?php echo ($settings['bundle_timer_enabled'] ?? 'no') === 'yes' ? ' is-active' : ''; ?>">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Urgency Timer', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version"><?php esc_html_e('Countdown on product page', 'nv-commerce-core'); ?></span>
                                    </div>
                                    <label class="nvcc-admin-toggle">
                                        <input type="checkbox" name="<?php echo esc_attr($option_key); ?>[bundle_timer_enabled]" value="yes" <?php checked(($settings['bundle_timer_enabled'] ?? 'no'), 'yes'); ?> data-nvcc-module-toggle>
                                        <span class="nvcc-admin-toggle-track"></span>
                                    </label>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Creates urgency with a configurable countdown timer. Resets per session to keep offers feeling fresh.', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--urgency"><?php esc_html_e('Urgency', 'nv-commerce-core'); ?></span>
                                    <a href="#" class="nvcc-admin-module-link" data-nvcc-goto="settings"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>

                            <div class="nvcc-admin-module-card">
                                <div class="nvcc-admin-module-header">
                                    <div class="nvcc-admin-module-icon nvcc-admin-module-icon--accent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 4.9L18.7 9.7l-4.9 1.8L12 16.4l-1.8-4.9L5.3 9.7l4.9-1.8z"/><path d="M19 14.5l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/></svg></div>
                                    <div class="nvcc-admin-module-info">
                                        <span class="nvcc-admin-module-title"><?php esc_html_e('Smart Upsell', 'nv-commerce-core'); ?></span>
                                        <span class="nvcc-admin-module-version"><?php esc_html_e('Post-add-to-cart upsells', 'nv-commerce-core'); ?></span>
                                    </div>
                                </div>
                                <p class="nvcc-admin-module-description"><?php esc_html_e('Intelligent product recommendations shown after adding to cart. Configured in the Smart Upsell submenu.', 'nv-commerce-core'); ?></p>
                                <div class="nvcc-admin-module-footer">
                                    <span class="nvcc-admin-module-tag nvcc-admin-module-tag--upsell"><?php esc_html_e('Upsell', 'nv-commerce-core'); ?></span>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=' . self::SMART_UPSELL_MENU_SLUG)); ?>" class="nvcc-admin-module-link"><?php esc_html_e('Configure', 'nv-commerce-core'); ?> &rarr;</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ═══ CAMPAIGNS TAB ═══ -->
                    <div class="nvcc-admin-tab-panel" data-nvcc-panel="campaigns">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                            <h3 style="font-size:16px;font-weight:700;color:#111827;margin:0;"><?php esc_html_e('Offer Campaigns', 'nv-commerce-core'); ?></h3>
                            <button type="button" class="nvcc-admin-btn nvcc-admin-btn--primary" id="nvcc-add-offer-campaign"><?php esc_html_e('+ New Campaign', 'nv-commerce-core'); ?></button>
                        </div>
                        <input type="hidden" id="nvcc-offer-campaigns-json" name="<?php echo esc_attr($option_key); ?>[offer_campaigns_json]" value="<?php echo esc_attr($offer_campaigns_json); ?>" />
                        <div id="nvcc-offer-campaign-list"></div>
                    </div>

                    <!-- ═══ BUNDLE DEALS TAB ═══ -->
                    <div class="nvcc-admin-tab-panel" data-nvcc-panel="deals">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
                            <h3 style="font-size:16px;font-weight:700;color:#111827;margin:0;"><?php esc_html_e('Global Bundle Deals', 'nv-commerce-core'); ?></h3>
                            <button type="button" class="nvcc-admin-btn nvcc-admin-btn--primary" id="nvcc-add-bundle-deal"><?php esc_html_e('+ Add Deal Tier', 'nv-commerce-core'); ?></button>
                        </div>
                        <input type="hidden" id="nvcc-bundle-deals-json" name="<?php echo esc_attr($option_key); ?>[bundle_deals_json]" value="<?php echo esc_attr($bundle_deals_json); ?>" />
                        <div id="nvcc-bundle-deals-list"></div>
                        <p class="nvcc-admin-hint" style="margin-top:12px;"><?php esc_html_e('Tips: använd {pct} i undertitel för att visa rabattprocent.', 'nv-commerce-core'); ?></p>
                    </div>

                    <!-- ═══ GLOBAL SETTINGS TAB ═══ -->
                    <div class="nvcc-admin-tab-panel" data-nvcc-panel="settings">
                        <p style="font-size:13px;color:#6B7280;margin-bottom:20px;line-height:1.6;"><?php esc_html_e('Configure default labels, display options and behaviors that apply across all modules unless overridden by a campaign.', 'nv-commerce-core'); ?></p>

                        <!-- Volume Discounts -->
                        <details class="nvcc-admin-accordion-section" open>
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#FEF3C7;color:#D97706;">%</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Volume Discounts', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Label and tier thresholds', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <div class="nvcc-admin-field-grid">
                                    <div class="nvcc-admin-field nvcc-admin-field--full">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Discount Label', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bulk_label]" value="<?php echo esc_attr((string) $settings['bulk_label']); ?>" />
                                        <p class="nvcc-admin-hint"><?php esc_html_e('Shown above the tier selector on the product page', 'nv-commerce-core'); ?></p>
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 2 &mdash; Quantity', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="1" name="<?php echo esc_attr($option_key); ?>[tier_2_qty]" value="<?php echo esc_attr((string) $settings['tier_2_qty']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 2 &mdash; Discount %', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="0" step="0.1" name="<?php echo esc_attr($option_key); ?>[tier_2_pct]" value="<?php echo esc_attr((string) $settings['tier_2_pct']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 3 &mdash; Quantity', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="1" name="<?php echo esc_attr($option_key); ?>[tier_3_qty]" value="<?php echo esc_attr((string) $settings['tier_3_qty']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 3 &mdash; Discount %', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="0" step="0.1" name="<?php echo esc_attr($option_key); ?>[tier_3_pct]" value="<?php echo esc_attr((string) $settings['tier_3_pct']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 4 &mdash; Quantity', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="1" name="<?php echo esc_attr($option_key); ?>[tier_4_qty]" value="<?php echo esc_attr((string) $settings['tier_4_qty']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Tier 4 &mdash; Discount %', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="0" step="0.1" name="<?php echo esc_attr($option_key); ?>[tier_4_pct]" value="<?php echo esc_attr((string) $settings['tier_4_pct']); ?>" />
                                    </div>
                                </div>
                            </div>
                        </details>

                        <!-- Bundle Layout -->
                        <details class="nvcc-admin-accordion-section">
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#DBEAFE;color:#2563EB;">&#9638;</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Bundle Layout', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Headlines, button text and variant style', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <div class="nvcc-admin-field-grid">
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Subtitle', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bundle_subtitle]" value="<?php echo esc_attr((string) $settings['bundle_subtitle']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('CTA Button Label', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bundle_cta_label]" value="<?php echo esc_attr((string) $settings['bundle_cta_label']); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field nvcc-admin-field--full">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Headline', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bundle_headline]" value="<?php echo esc_attr((string) ($settings['bundle_headline'] ?? '')); ?>" />
                                        <p class="nvcc-admin-hint"><?php esc_html_e('Leave empty for auto-generated headline. Placeholders: {pct} = discount %, {needed} = qty needed.', 'nv-commerce-core'); ?></p>
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Variant Style', 'nv-commerce-core'); ?></label>
                                        <select class="nvcc-admin-select" name="<?php echo esc_attr($option_key); ?>[bundle_variant_style]">
                                            <option value="a" <?php selected((string) $settings['bundle_variant_style'], 'a'); ?>><?php esc_html_e('Style A &mdash; Compact', 'nv-commerce-core'); ?></option>
                                            <option value="b" <?php selected((string) $settings['bundle_variant_style'], 'b'); ?>><?php esc_html_e('Style B &mdash; Cards', 'nv-commerce-core'); ?></option>
                                            <option value="c" <?php selected((string) $settings['bundle_variant_style'], 'c'); ?>><?php esc_html_e('Style C &mdash; Detailed', 'nv-commerce-core'); ?></option>
                                        </select>
                                    </div>
                                    <div class="nvcc-admin-field" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                                        <div>
                                            <label class="nvcc-admin-label"><?php esc_html_e('Popular Index', 'nv-commerce-core'); ?></label>
                                            <input type="number" class="nvcc-admin-input" min="1" max="6" name="<?php echo esc_attr($option_key); ?>[bundle_popular_index]" value="<?php echo esc_attr((string) $settings['bundle_popular_index']); ?>" />
                                        </div>
                                        <div>
                                            <label class="nvcc-admin-label"><?php esc_html_e('Default Index', 'nv-commerce-core'); ?></label>
                                            <input type="number" class="nvcc-admin-input" min="1" max="6" name="<?php echo esc_attr($option_key); ?>[bundle_default_index]" value="<?php echo esc_attr((string) $settings['bundle_default_index']); ?>" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </details>

                        <!-- Buy Now -->
                        <details class="nvcc-admin-accordion-section">
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#CCFBF1;color:#0F766E;">&#9889;</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Buy Now', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Button label and redirect target', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <div class="nvcc-admin-field-grid">
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Button Label', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[buy_now_label]" value="<?php echo esc_attr((string) ($settings['buy_now_label'] ?? __('Buy Now', 'nv-commerce-core'))); ?>" />
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Redirect To', 'nv-commerce-core'); ?></label>
                                        <select class="nvcc-admin-select" name="<?php echo esc_attr($option_key); ?>[buy_now_redirect_target]">
                                            <option value="checkout" <?php selected((string) ($settings['buy_now_redirect_target'] ?? 'checkout'), 'checkout'); ?>><?php esc_html_e('Checkout', 'nv-commerce-core'); ?></option>
                                            <option value="cart" <?php selected((string) ($settings['buy_now_redirect_target'] ?? 'checkout'), 'cart'); ?>><?php esc_html_e('Cart', 'nv-commerce-core'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </details>

                        <!-- Bonus Display -->
                        <details class="nvcc-admin-accordion-section">
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#D1FAE5;color:#059669;">&#127873;</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Bonus Display', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Thumbnail layout and detail link text', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <div class="nvcc-admin-field-grid">
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Display Style', 'nv-commerce-core'); ?></label>
                                        <select class="nvcc-admin-select" name="<?php echo esc_attr($option_key); ?>[bundle_bonus_display_style]">
                                            <option value="auto" <?php selected((string) ($settings['bundle_bonus_display_style'] ?? 'auto'), 'auto'); ?>><?php esc_html_e('Auto', 'nv-commerce-core'); ?></option>
                                            <option value="strip" <?php selected((string) ($settings['bundle_bonus_display_style'] ?? 'auto'), 'strip'); ?>><?php esc_html_e('Strip', 'nv-commerce-core'); ?></option>
                                            <option value="grid" <?php selected((string) ($settings['bundle_bonus_display_style'] ?? 'auto'), 'grid'); ?>><?php esc_html_e('Grid', 'nv-commerce-core'); ?></option>
                                        </select>
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Image Size', 'nv-commerce-core'); ?></label>
                                        <select class="nvcc-admin-select" name="<?php echo esc_attr($option_key); ?>[bundle_bonus_thumb_size]">
                                            <option value="thumbnail" <?php selected((string) ($settings['bundle_bonus_thumb_size'] ?? 'thumbnail'), 'thumbnail'); ?>>thumbnail</option>
                                            <option value="woocommerce_thumbnail" <?php selected((string) ($settings['bundle_bonus_thumb_size'] ?? 'thumbnail'), 'woocommerce_thumbnail'); ?>>woocommerce_thumbnail</option>
                                            <option value="medium" <?php selected((string) ($settings['bundle_bonus_thumb_size'] ?? 'thumbnail'), 'medium'); ?>>medium</option>
                                            <option value="full" <?php selected((string) ($settings['bundle_bonus_thumb_size'] ?? 'thumbnail'), 'full'); ?>>full</option>
                                        </select>
                                    </div>
                                    <div class="nvcc-admin-field nvcc-admin-field--full">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Details CTA Text', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bundle_bonus_details_cta]" value="<?php echo esc_attr((string) ($settings['bundle_bonus_details_cta'] ?? __('+ Visa alla {count} böcker ▼', 'nv-commerce-core'))); ?>" />
                                        <p class="nvcc-admin-hint"><?php esc_html_e('Use {count} for the number of bonus products', 'nv-commerce-core'); ?></p>
                                    </div>
                                </div>
                            </div>
                        </details>

                        <!-- Urgency Timer -->
                        <details class="nvcc-admin-accordion-section">
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#FFE4E6;color:#E11D48;">&#9201;</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Urgency Timer', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Countdown duration and message', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <div class="nvcc-admin-field-grid">
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Timer Duration (minutes)', 'nv-commerce-core'); ?></label>
                                        <input type="number" class="nvcc-admin-input" min="1" max="1440" name="<?php echo esc_attr($option_key); ?>[bundle_timer_minutes]" value="<?php echo esc_attr((string) ($settings['bundle_timer_minutes'] ?? '15')); ?>" />
                                        <p class="nvcc-admin-hint"><?php esc_html_e('1 to 1440 minutes', 'nv-commerce-core'); ?></p>
                                    </div>
                                    <div class="nvcc-admin-field">
                                        <label class="nvcc-admin-label"><?php esc_html_e('Timer Text', 'nv-commerce-core'); ?></label>
                                        <input type="text" class="nvcc-admin-input" name="<?php echo esc_attr($option_key); ?>[bundle_timer_text]" value="<?php echo esc_attr((string) ($settings['bundle_timer_text'] ?? __('Erbjudandet slutar om', 'nv-commerce-core'))); ?>" />
                                    </div>
                                </div>
                            </div>
                        </details>

                        <!-- Shortcode Info -->
                        <details class="nvcc-admin-accordion-section">
                            <summary class="nvcc-admin-accordion-trigger">
                                <span class="nvcc-admin-accordion-icon" style="background:#F3F4F6;color:#6B7280;">&lt;/&gt;</span>
                                <span class="nvcc-admin-accordion-text">
                                    <span class="nvcc-admin-accordion-title"><?php esc_html_e('Shortcode & Elementor', 'nv-commerce-core'); ?></span>
                                    <span class="nvcc-admin-accordion-desc"><?php esc_html_e('Fallback shortcode for Elementor templates', 'nv-commerce-core'); ?></span>
                                </span>
                                <span class="nvcc-admin-accordion-arrow">&#9660;</span>
                            </summary>
                            <div class="nvcc-admin-accordion-body">
                                <p style="font-size:13px;color:#6B7280;margin:0 0 8px;">
                                    <?php esc_html_e('Use this shortcode in your Elementor product template if the bundle block is not displayed via theme hooks:', 'nv-commerce-core'); ?>
                                </p>
                                <code style="display:inline-block;padding:8px 14px;background:#F3F4F6;border-radius:6px;font-size:13px;color:#374151;">[nvcc_variation_bundle]</code>
                            </div>
                        </details>
                    </div>

                    <div class="nvcc-admin-save-bar">
                        <div class="nvcc-admin-save-bar-status" id="nvcc-save-status"
                             data-clean="<?php esc_attr_e('All changes saved', 'nv-commerce-core'); ?>"
                             data-dirty="<?php esc_attr_e('You have unsaved changes', 'nv-commerce-core'); ?>"><?php esc_html_e('All changes saved', 'nv-commerce-core'); ?></div>
                        <div class="nvcc-admin-save-bar-actions">
                            <button type="submit" id="nvcc-save-bottom" class="nvcc-admin-btn nvcc-admin-btn--primary" disabled aria-disabled="true"><?php esc_html_e('Save Changes', 'nv-commerce-core'); ?></button>
                        </div>
                    </div>
                            <script>
                                (function(){
                                    const bundleHidden = document.getElementById('nvcc-bundle-deals-json');
                                    const bundleList = document.getElementById('nvcc-bundle-deals-list');
                                    const addBundleBtn = document.getElementById('nvcc-add-bundle-deal');

                                    const campaignHidden = document.getElementById('nvcc-offer-campaigns-json');
                                    const campaignList = document.getElementById('nvcc-offer-campaign-list');
                                    const addCampaignBtn = document.getElementById('nvcc-add-offer-campaign');

                                    if (!bundleHidden || !bundleList || !addBundleBtn || !campaignHidden || !campaignList || !addCampaignBtn) {
                                        return;
                                    }

                                    const adminAjaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
                                    const targetSearchNonce = <?php echo wp_json_encode($admin_target_search_nonce); ?>;

                                    const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
                                    const asInt = (value, fallback = 0) => {
                                        const parsed = parseInt(String(value), 10);
                                        return Number.isFinite(parsed) ? parsed : fallback;
                                    };
                                    const escHtml = (value) => String(value ?? '')
                                        .replace(/&/g, '&amp;')
                                        .replace(/</g, '&lt;')
                                        .replace(/>/g, '&gt;')
                                        .replace(/"/g, '&quot;');
                                    const newId = () => 'campaign_' + Math.random().toString(36).slice(2, 10);
                                    const normalizeIds = (value) => Array.from(new Set((Array.isArray(value) ? value : [])
                                        .map((id) => asInt(id, 0))
                                        .filter((id) => id > 0)));
                                    const openBundleDeals = new Set();
                                    const openCampaigns = new Set();
                                    const openCampaignDeals = new Set();

                                    const normalizeLabelMap = (value, ids) => {
                                        const labels = {};
                                        if (value && typeof value === 'object' && !Array.isArray(value)) {
                                            Object.keys(value).forEach((key) => {
                                                const id = asInt(key, 0);
                                                const label = String(value[key] || '').trim();
                                                if (id > 0 && label !== '') {
                                                    labels[String(id)] = label;
                                                }
                                            });
                                        }

                                        (Array.isArray(ids) ? ids : []).forEach((id) => {
                                            const key = String(asInt(id, 0));
                                            if (key !== '0' && !Object.prototype.hasOwnProperty.call(labels, key)) {
                                                labels[key] = '';
                                            }
                                        });

                                        return labels;
                                    };

                                    const getTargetName = (campaign, entity, id) => {
                                        const labels = campaign && campaign[entity + '_labels'];
                                        const label = labels && typeof labels === 'object' ? String(labels[String(id)] || '').trim() : '';
                                        if (label !== '') {
                                            return label;
                                        }

                                        if (entity === 'category') {
                                            return '<?php echo esc_js(__('Okänd kategori', 'nv-commerce-core')); ?>';
                                        }
                                        if (entity === 'tag') {
                                            return '<?php echo esc_js(__('Okänd tagg', 'nv-commerce-core')); ?>';
                                        }
                                        if (entity === 'brand') {
                                            return '<?php echo esc_js(__('Okänt varumärke', 'nv-commerce-core')); ?>';
                                        }
                                        return '<?php echo esc_js(__('Okänd produkt', 'nv-commerce-core')); ?>';
                                    };

                                    const targetModeLabel = (mode) => {
                                        if (mode === 'all_products') {
                                            return 'All products';
                                        }
                                        if (mode === 'specific_categories') {
                                            return 'Specific categories';
                                        }
                                        if (mode === 'specific_tags') {
                                            return 'Specific tags';
                                        }
                                        if (mode === 'specific_brands') {
                                            return 'Specific brands';
                                        }
                                        return 'Specific products';
                                    };

                                    const parseIdsFromSelectors = (raw) => {
                                        return String(raw || '')
                                            .split(/\r?\n|,/)
                                            .map((line) => String(line).trim())
                                            .filter(Boolean)
                                            .map((line) => {
                                                const match = line.match(/^id\s*:\s*(\d+)$/i);
                                                if (match) {
                                                    return asInt(match[1], 0);
                                                }
                                                if (/^\d+$/.test(line)) {
                                                    return asInt(line, 0);
                                                }
                                                return 0;
                                            })
                                            .filter((id) => id > 0);
                                    };

                                    const normalizeDiscountMode = (value) => {
                                        const mode = String(value || '').trim();
                                        if (mode === 'percentage' || mode === 'fixed_amount' || mode === 'fixed_price') {
                                            return mode;
                                        }
                                        return 'auto';
                                    };

                                    const normalizeDeal = (deal, index) => {
                                        const legacyDiscount = String((deal && deal.discount) ?? '').trim();
                                        let discountMode = normalizeDiscountMode(deal && deal.discount_mode);
                                        let discountValue = String((deal && deal.discount_value) ?? '').trim();
                                        if (discountMode === 'auto' && legacyDiscount !== '' && discountValue === '') {
                                            discountMode = 'percentage';
                                            discountValue = legacyDiscount;
                                        } else if (discountMode === 'percentage' && discountValue === '' && legacyDiscount !== '') {
                                            discountValue = legacyDiscount;
                                        }

                                        const normalized = {
                                            qty: Math.max(1, asInt(deal && deal.qty, index + 1)),
                                            title: String((deal && deal.title) || ''),
                                            subtitle: String((deal && deal.subtitle) || ''),
                                            badge: String((deal && deal.badge) || ''),
                                            label: String((deal && deal.label) || ''),
                                            discount_mode: discountMode,
                                            discount_value: discountValue,
                                            discount: legacyDiscount,
                                            bogo: (deal && deal.bogo) === 'yes' ? 'yes' : 'no',
                                        };
                                        if (!normalized.title) {
                                            normalized.title = 'Deal ' + (index + 1);
                                        }
                                        return normalized;
                                    };

                                    const normalizeCampaign = (campaign, index) => {
                                        const productIds = normalizeIds((campaign && campaign.product_ids) || parseIdsFromSelectors(campaign && campaign.product_selectors));
                                        const categoryIds = normalizeIds((campaign && campaign.category_ids) || parseIdsFromSelectors(campaign && campaign.category_selectors));
                                        let targetMode = String((campaign && campaign.target_mode) || '');
                                        if (!targetMode) {
                                            targetMode = categoryIds.length && !productIds.length ? 'specific_categories' : 'specific_products';
                                        }

                                        const normalized = {
                                            id: String((campaign && campaign.id) || newId()),
                                            name: String((campaign && campaign.name) || ('Campaign ' + (index + 1))),
                                            status: (campaign && campaign.status) === 'inactive' ? 'inactive' : 'active',
                                            priority: Math.max(0, asInt(campaign && campaign.priority, 0)),
                                            match_mode: (campaign && campaign.match_mode) === 'all' ? 'all' : 'any',
                                            target_mode: targetMode,
                                            product_ids: productIds,
                                            category_ids: categoryIds,
                                            tag_ids: normalizeIds((campaign && campaign.tag_ids) || []),
                                            brand_ids: normalizeIds((campaign && campaign.brand_ids) || []),
                                            product_selectors: '',
                                            category_selectors: '',
                                            product_labels: {},
                                            category_labels: {},
                                            tag_labels: {},
                                            brand_labels: {},
                                            headline: String((campaign && campaign.headline) || ''),
                                            deals: [],
                                            popular_index: 1,
                                            default_index: 1,
                                        };

                                        normalized.product_labels = normalizeLabelMap(campaign && campaign.product_labels, normalized.product_ids);
                                        normalized.category_labels = normalizeLabelMap(campaign && campaign.category_labels, normalized.category_ids);
                                        normalized.tag_labels = normalizeLabelMap(campaign && campaign.tag_labels, normalized.tag_ids);
                                        normalized.brand_labels = normalizeLabelMap(campaign && campaign.brand_labels, normalized.brand_ids);

                                        let dealRows = [];
                                        if (Array.isArray(campaign && campaign.deals) && campaign.deals.length) {
                                            dealRows = campaign.deals;
                                        } else {
                                            let hasLegacyDealPayload = false;
                                            for (let i = 1; i <= 3; i++) {
                                                const legacyRow = {
                                                    qty: campaign && campaign['deal_' + i + '_qty'],
                                                    title: campaign && campaign['deal_' + i + '_title'],
                                                    subtitle: campaign && campaign['deal_' + i + '_subtitle'],
                                                    badge: campaign && campaign['deal_' + i + '_badge'],
                                                    label: campaign && campaign['deal_' + i + '_label'],
                                                    discount_mode: campaign && campaign['deal_' + i + '_discount_mode'],
                                                    discount_value: campaign && campaign['deal_' + i + '_discount_value'],
                                                    discount: campaign && campaign['deal_' + i + '_discount'],
                                                    bogo: campaign && campaign['deal_' + i + '_bogo'],
                                                };
                                                if (
                                                    legacyRow.qty !== undefined ||
                                                    String(legacyRow.title || '').trim() !== '' ||
                                                    String(legacyRow.subtitle || '').trim() !== '' ||
                                                    String(legacyRow.badge || '').trim() !== '' ||
                                                    String(legacyRow.label || '').trim() !== '' ||
                                                    String(legacyRow.discount || '').trim() !== '' ||
                                                    String(legacyRow.discount_value || '').trim() !== '' ||
                                                    String(legacyRow.discount_mode || '').trim() !== '' ||
                                                    String(legacyRow.bogo || '').trim() !== ''
                                                ) {
                                                    hasLegacyDealPayload = true;
                                                }
                                                dealRows.push(legacyRow);
                                            }
                                            if (!hasLegacyDealPayload) {
                                                dealRows = [normalizeDeal({}, 0)];
                                            }
                                        }

                                        normalized.deals = dealRows
                                            .map((deal, dealIndex) => normalizeDeal(deal || {}, dealIndex))
                                            .filter((deal) => deal.qty > 0);
                                        if (!normalized.deals.length) {
                                            normalized.deals = [normalizeDeal({}, 0)];
                                        }
                                        const maxDeals = Math.max(1, normalized.deals.length);
                                        normalized.popular_index = clamp(asInt(campaign && campaign.popular_index, 2), 1, maxDeals);
                                        normalized.default_index = clamp(asInt(campaign && campaign.default_index, 2), 1, maxDeals);

                                        return normalized;
                                    };

                                    const parseJsonList = (raw, normalizer, fallbackItem) => {
                                        try {
                                            const parsed = JSON.parse(raw || '[]');
                                            if (Array.isArray(parsed) && parsed.length) {
                                                return parsed.map((item, index) => normalizer(item || {}, index));
                                            }
                                        } catch (e) {
                                            // ignore
                                        }
                                        return [normalizer(fallbackItem, 0)];
                                    };

                                    let bundleDeals = parseJsonList(bundleHidden.value, normalizeDeal, {
                                        qty: 1,
                                        title: 'Deal 1',
                                        subtitle: '',
                                        badge: '',
                                        label: '',
                                        discount_mode: 'auto',
                                        discount_value: '',
                                        discount: '',
                                        bogo: 'no'
                                    });
                                    let campaigns = parseJsonList(campaignHidden.value, normalizeCampaign, {
                                        name: 'Campaign 1',
                                        status: 'active',
                                        priority: 0,
                                        match_mode: 'any',
                                        target_mode: 'specific_products',
                                        product_selectors: '',
                                        category_selectors: '',
                                        deals: [{
                                            qty: 1,
                                            title: 'Deal 1',
                                            subtitle: '',
                                            badge: '',
                                            label: '',
                                            discount_mode: 'auto',
                                            discount_value: '',
                                            discount: '',
                                            bogo: 'no'
                                        }],
                                    });

                                    const serialize = () => {
                                        bundleHidden.value = JSON.stringify(bundleDeals);
                                        campaignHidden.value = JSON.stringify(campaigns);
                                    };

                                    const renderBundleDeal = (deal, index) => {
                                        const title = deal.title || ('Deal ' + (index + 1));
                                        const isOpen = openBundleDeals.has(String(index));
                                        return '' +
                                            '<details class="nvcc-bundle-deal-card" data-bundle-index="' + index + '"' + (isOpen ? ' open' : '') + '>' +
                                                '<summary class="nvcc-card-summary"><span data-bundle-title="' + index + '">' + escHtml(title) + '</span><span class="nvcc-card-meta">' + escHtml(deal.qty) + ' <?php echo esc_js(__('st', 'nv-commerce-core')); ?></span></summary>' +
                                                '<div class="nvcc-card-body">' +
                                                    '<div class="nvcc-bundle-deal-header">' +
                                                    '<button type="button" class="button button-secondary" data-bundle-action="duplicate" data-bundle-index="' + index + '"><?php echo esc_js(__('Duplicera', 'nv-commerce-core')); ?></button>' +
                                                    '<button type="button" class="button button-link-delete" data-bundle-action="remove" data-bundle-index="' + index + '"><?php echo esc_js(__('Ta bort', 'nv-commerce-core')); ?></button>' +
                                                    '</div>' +
                                                    '<div class="nvcc-bundle-deal-grid">' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Antal (qty)', 'nv-commerce-core')); ?></label><input type="number" min="1" step="1" data-bundle-field="qty" data-bundle-index="' + index + '" value="' + escHtml(deal.qty) + '"></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Titel', 'nv-commerce-core')); ?></label><input type="text" data-bundle-field="title" data-bundle-index="' + index + '" value="' + escHtml(deal.title) + '"></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Undertitel ({pct} stöds)', 'nv-commerce-core')); ?></label><input type="text" data-bundle-field="subtitle" data-bundle-index="' + index + '" value="' + escHtml(deal.subtitle) + '"></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Badge', 'nv-commerce-core')); ?></label><input type="text" data-bundle-field="badge" data-bundle-index="' + index + '" value="' + escHtml(deal.badge) + '"></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Etikett', 'nv-commerce-core')); ?></label><input type="text" data-bundle-field="label" data-bundle-index="' + index + '" value="' + escHtml(deal.label) + '"></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Rabatttyp', 'nv-commerce-core')); ?></label><select data-bundle-field="discount_mode" data-bundle-index="' + index + '"><option value="auto"' + (deal.discount_mode === 'auto' ? ' selected' : '') + '><?php echo esc_js(__('Auto (%)', 'nv-commerce-core')); ?></option><option value="percentage"' + (deal.discount_mode === 'percentage' ? ' selected' : '') + '><?php echo esc_js(__('Percentage (%)', 'nv-commerce-core')); ?></option><option value="fixed_amount"' + (deal.discount_mode === 'fixed_amount' ? ' selected' : '') + '><?php echo esc_js(__('Fixed discount amount', 'nv-commerce-core')); ?></option><option value="fixed_price"' + (deal.discount_mode === 'fixed_price' ? ' selected' : '') + '><?php echo esc_js(__('Fixed total price', 'nv-commerce-core')); ?></option></select></div>' +
                                                    '<div><label class="nvcc-bundle-label"><?php echo esc_js(__('Rabattvärde', 'nv-commerce-core')); ?></label><input type="number" min="0" step="0.01" data-bundle-field="discount_value" data-bundle-index="' + index + '" value="' + escHtml(deal.discount_value) + '"></div>' +
                                                    '<div style="grid-column:1 / -1;"><label><input type="checkbox" data-bundle-field="bogo" data-bundle-index="' + index + '" ' + (deal.bogo === 'yes' ? 'checked' : '') + '> <?php echo esc_js(__('BOGO (Köp X betala för X-1)', 'nv-commerce-core')); ?></label></div>' +
                                                    '</div>' +
                                                '</div>' +
                                            '</details>';
                                    };

                                    const renderBundleDeals = () => {
                                        if (!bundleDeals.length) {
                                            bundleList.innerHTML = '<div class="nvcc-bundle-empty"><?php echo esc_js(__('Inga deals ännu. Klicka på "+ Lägg till deal".', 'nv-commerce-core')); ?></div>';
                                            serialize();
                                            return;
                                        }
                                        bundleList.innerHTML = bundleDeals.map((deal, index) => renderBundleDeal(deal, index)).join('');
                                        serialize();
                                    };

                                    const renderTargetChips = (campaign, campaignIndex, entity) => {
                                        const ids = campaign[entity + '_ids'] || [];
                                        if (!Array.isArray(ids) || !ids.length) {
                                            return '<div class="description"><?php echo esc_js(__('Inga val ännu.', 'nv-commerce-core')); ?></div>';
                                        }
                                        return '<div class="nvcc-target-chips">' + ids.map((id) => {
                                            const label = getTargetName(campaign, entity, id);
                                            return '<span class="nvcc-target-chip">' + escHtml(label) + '<button type="button" aria-label="<?php echo esc_js(__('Ta bort', 'nv-commerce-core')); ?>" data-remove-target="1" data-campaign-index="' + campaignIndex + '" data-target-entity="' + entity + '" data-target-id="' + escHtml(id) + '">×</button></span>';
                                        }).join('') + '</div>';
                                    };

                                    const renderTargetPicker = (campaign, campaignIndex, entity, title) => {
                                        const ids = campaign[entity + '_ids'] || [];
                                        const searchId = 'nvcc-target-search-' + campaignIndex + '-' + entity;
                                        const resultsId = 'nvcc-target-results-' + campaignIndex + '-' + entity;
                                        return '' +
                                            '<div class="nvcc-target-picker">' +
                                                '<label class="nvcc-campaign-label" for="' + searchId + '">' + escHtml(title) + '</label>' +
                                                '<input id="' + searchId + '" type="text" data-target-search="1" data-campaign-index="' + campaignIndex + '" data-target-entity="' + entity + '" placeholder="<?php echo esc_js(__('Sök...', 'nv-commerce-core')); ?>" autocomplete="off">' +
                                                renderTargetChips(campaign, campaignIndex, entity) +
                                                '<div id="' + resultsId + '" class="nvcc-target-results" data-target-results="1" data-campaign-index="' + campaignIndex + '" data-target-entity="' + entity + '"></div>' +
                                            '</div>';
                                    };

                                    const clampCampaignIndices = (campaign) => {
                                        if (!campaign || !Array.isArray(campaign.deals)) {
                                            return;
                                        }
                                        const maxDeals = Math.max(1, campaign.deals.length);
                                        campaign.popular_index = clamp(asInt(campaign.popular_index, 2), 1, maxDeals);
                                        campaign.default_index = clamp(asInt(campaign.default_index, 2), 1, maxDeals);
                                    };

                                    const renderCampaignDeal = (campaign, campaignIndex, deal, dealIndex) => {
                                        const title = deal.title || ('Deal ' + (dealIndex + 1));
                                        const dealKey = String(campaign.id || campaignIndex) + ':' + dealIndex;
                                        const isOpen = openCampaignDeals.has(dealKey);
                                        return '' +
                                            '<details class="nvcc-campaign-deal-card" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" data-campaign-deal-key="' + escHtml(dealKey) + '"' + (isOpen ? ' open' : '') + '>' +
                                                '<summary class="nvcc-card-summary"><span data-campaign-deal-title="' + campaignIndex + '-' + dealIndex + '">' + escHtml(title) + '</span><span class="nvcc-card-meta">' + escHtml(deal.qty) + ' <?php echo esc_js(__('st', 'nv-commerce-core')); ?></span></summary>' +
                                                '<div class="nvcc-card-body">' +
                                                    '<div class="nvcc-campaign-deal-header">' +
                                                    '<button type="button" class="button button-secondary" data-deal-action="duplicate" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '"><?php echo esc_js(__('Duplicera', 'nv-commerce-core')); ?></button>' +
                                                    '<button type="button" class="button button-link-delete" data-deal-action="remove" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '"><?php echo esc_js(__('Ta bort', 'nv-commerce-core')); ?></button>' +
                                                    '</div>' +
                                                    '<div class="nvcc-campaign-deal-grid">' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Antal (qty)', 'nv-commerce-core')); ?></label><input type="number" min="1" step="1" data-deal-field="qty" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.qty) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Titel', 'nv-commerce-core')); ?></label><input type="text" data-deal-field="title" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.title) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Undertitel ({pct}/{amount}/{price})', 'nv-commerce-core')); ?></label><input type="text" data-deal-field="subtitle" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.subtitle) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Badge', 'nv-commerce-core')); ?></label><input type="text" data-deal-field="badge" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.badge) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Etikett', 'nv-commerce-core')); ?></label><input type="text" data-deal-field="label" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.label) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Rabatttyp', 'nv-commerce-core')); ?></label><select data-deal-field="discount_mode" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '"><option value="auto"' + (deal.discount_mode === 'auto' ? ' selected' : '') + '><?php echo esc_js(__('Auto (%)', 'nv-commerce-core')); ?></option><option value="percentage"' + (deal.discount_mode === 'percentage' ? ' selected' : '') + '><?php echo esc_js(__('Percentage (%)', 'nv-commerce-core')); ?></option><option value="fixed_amount"' + (deal.discount_mode === 'fixed_amount' ? ' selected' : '') + '><?php echo esc_js(__('Fixed discount amount', 'nv-commerce-core')); ?></option><option value="fixed_price"' + (deal.discount_mode === 'fixed_price' ? ' selected' : '') + '><?php echo esc_js(__('Fixed total price', 'nv-commerce-core')); ?></option></select></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Rabattvärde', 'nv-commerce-core')); ?></label><input type="number" min="0" step="0.01" data-deal-field="discount_value" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '" value="' + escHtml(deal.discount_value) + '"></div>' +
                                                    '<div style="grid-column:1 / -1;"><label><input type="checkbox" data-deal-field="bogo" data-campaign-index="' + campaignIndex + '" data-campaign-deal-index="' + dealIndex + '"' + (deal.bogo === 'yes' ? ' checked' : '') + '> <?php echo esc_js(__('BOGO (Köp X betala för X-1)', 'nv-commerce-core')); ?></label></div>' +
                                                    '</div>' +
                                                '</div>' +
                                            '</details>';
                                    };

                                    const renderCampaignDeals = (campaign, campaignIndex) => {
                                        const deals = Array.isArray(campaign.deals) ? campaign.deals : [];
                                        let html = '<div class="nvcc-campaign-deals-actions"><button type="button" class="button button-secondary" data-deal-action="add" data-campaign-index="' + campaignIndex + '"><?php echo esc_js(__('+ Lägg till deal', 'nv-commerce-core')); ?></button>';
                                        html += '<span class="description"><?php echo esc_js(__('Starta med 1 deal och lägg till fler vid behov.', 'nv-commerce-core')); ?></span></div>';
                                        html += deals.map((deal, dealIndex) => renderCampaignDeal(campaign, campaignIndex, deal, dealIndex)).join('');
                                        return html;
                                    };

                                    const renderTargetModeBlock = (campaign, campaignIndex) => {
                                        const mode = campaign.target_mode || '';
                                        if (mode === 'all_products') {
                                            return '<div class="description"><?php echo esc_js(__('Matchar alla produkter.', 'nv-commerce-core')); ?></div>';
                                        }
                                        if (mode === 'specific_products') {
                                            return renderTargetPicker(campaign, campaignIndex, 'product', '<?php echo esc_js(__('Specifika produkter', 'nv-commerce-core')); ?>');
                                        }
                                        if (mode === 'specific_categories') {
                                            return renderTargetPicker(campaign, campaignIndex, 'category', '<?php echo esc_js(__('Specifika kategorier', 'nv-commerce-core')); ?>');
                                        }
                                        if (mode === 'specific_tags') {
                                            return renderTargetPicker(campaign, campaignIndex, 'tag', '<?php echo esc_js(__('Specifika taggar', 'nv-commerce-core')); ?>');
                                        }
                                        if (mode === 'specific_brands') {
                                            return renderTargetPicker(campaign, campaignIndex, 'brand', '<?php echo esc_js(__('Specifika varumärken', 'nv-commerce-core')); ?>');
                                        }
                                        return renderTargetPicker(campaign, campaignIndex, 'product', '<?php echo esc_js(__('Specifika produkter', 'nv-commerce-core')); ?>');
                                    };

                                    const renderCampaign = (campaign, campaignIndex) => {
                                        const title = String(campaign.name || ('Campaign ' + (campaignIndex + 1))).trim() || ('Campaign ' + (campaignIndex + 1));
                                        const campaignKey = String(campaign.id || campaignIndex);
                                        const isOpen = openCampaigns.has(campaignKey);
                                        const dealCount = Array.isArray(campaign.deals) ? campaign.deals.length : 0;
                                        return '' +
                                            '<details class="nvcc-campaign-card" data-campaign-index="' + campaignIndex + '" data-campaign-key="' + escHtml(campaignKey) + '"' + (isOpen ? ' open' : '') + '>' +
                                                '<summary class="nvcc-card-summary"><span data-campaign-title="' + campaignIndex + '">' + escHtml(title) + '</span><span class="nvcc-card-meta">' + escHtml(targetModeLabel(campaign.target_mode)) + '</span><span class="nvcc-card-meta">' + escHtml(dealCount) + ' <?php echo esc_js(__('deals', 'nv-commerce-core')); ?></span></summary>' +
                                                '<div class="nvcc-card-body">' +
                                                    '<div class="nvcc-campaign-header">' +
                                                    '<button type="button" class="button button-secondary" data-action="duplicate" data-campaign-index="' + campaignIndex + '"><?php echo esc_js(__('Duplicera', 'nv-commerce-core')); ?></button>' +
                                                    '<button type="button" class="button button-link-delete" data-action="remove" data-campaign-index="' + campaignIndex + '"><?php echo esc_js(__('Ta bort', 'nv-commerce-core')); ?></button>' +
                                                    '</div>' +
                                                    '<div class="nvcc-campaign-grid">' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Namn', 'nv-commerce-core')); ?></label><input type="text" data-field="name" data-campaign-index="' + campaignIndex + '" value="' + escHtml(campaign.name) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Status', 'nv-commerce-core')); ?></label><select data-field="status" data-campaign-index="' + campaignIndex + '"><option value="active"' + (campaign.status === 'active' ? ' selected' : '') + '>Active</option><option value="inactive"' + (campaign.status === 'inactive' ? ' selected' : '') + '>Inactive</option></select></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Prioritet (högre = vinner)', 'nv-commerce-core')); ?></label><input type="number" min="0" step="1" data-field="priority" data-campaign-index="' + campaignIndex + '" value="' + escHtml(campaign.priority) + '"></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Match mode', 'nv-commerce-core')); ?></label><select data-field="match_mode" data-campaign-index="' + campaignIndex + '"><option value="any"' + (campaign.match_mode === 'any' ? ' selected' : '') + '>Any selector match</option><option value="all"' + (campaign.match_mode === 'all' ? ' selected' : '') + '>All provided selector groups</option></select></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Target mode', 'nv-commerce-core')); ?></label><select data-field="target_mode" data-campaign-index="' + campaignIndex + '"><option value="all_products"' + (campaign.target_mode === 'all_products' ? ' selected' : '') + '>All products</option><option value="specific_products"' + (campaign.target_mode === 'specific_products' ? ' selected' : '') + '>Specific products</option><option value="specific_categories"' + (campaign.target_mode === 'specific_categories' ? ' selected' : '') + '>Specific categories</option><option value="specific_tags"' + (campaign.target_mode === 'specific_tags' ? ' selected' : '') + '>Specific tags</option><option value="specific_brands"' + (campaign.target_mode === 'specific_brands' ? ' selected' : '') + '>Specific brands</option></select></div>' +
                                                    '<div><label class="nvcc-campaign-label"><?php echo esc_js(__('Kampanjrubrik (valfritt)', 'nv-commerce-core')); ?></label><input type="text" data-field="headline" data-campaign-index="' + campaignIndex + '" value="' + escHtml(campaign.headline) + '" placeholder="t.ex. Limited offer: {pct}% idag"></div>' +
                                                    '<div style="display:grid;grid-template-columns:repeat(2,minmax(120px,1fr));gap:8px;"><div><label class="nvcc-campaign-label"><?php echo esc_js(__('Popular index', 'nv-commerce-core')); ?></label><input type="number" min="1" step="1" data-field="popular_index" data-campaign-index="' + campaignIndex + '" value="' + escHtml(campaign.popular_index) + '"></div><div><label class="nvcc-campaign-label"><?php echo esc_js(__('Default index', 'nv-commerce-core')); ?></label><input type="number" min="1" step="1" data-field="default_index" data-campaign-index="' + campaignIndex + '" value="' + escHtml(campaign.default_index) + '"></div></div>' +
                                                    '</div>' +
                                                    '<div style="margin-top:10px;">' + renderTargetModeBlock(campaign, campaignIndex) + '</div>' +
                                                    '<div class="nvcc-campaign-deals">' + renderCampaignDeals(campaign, campaignIndex) + '</div>' +
                                                '</div>' +
                                            '</details>';
                                    };

                                    const renderCampaigns = () => {
                                        if (!campaigns.length) {
                                            campaignList.innerHTML = '<div class="nvcc-campaign-empty"><?php echo esc_js(__('Inga kampanjer än. Klicka på "+ Lägg till kampanj" för att skapa din första.', 'nv-commerce-core')); ?></div>';
                                            serialize();
                                            return;
                                        }

                                        campaignList.innerHTML = campaigns.map((campaign, index) => renderCampaign(campaign, index)).join('');
                                        serialize();
                                    };

                                    const requestTargetSearch = (campaignIndex, entity, query, output) => {
                                        const trimmed = String(query || '').trim();
                                        if (!trimmed || trimmed.length < 2) {
                                            output.innerHTML = '';
                                            return;
                                        }

                                        const params = new URLSearchParams({
                                            action: 'nvcc_search_admin_targets',
                                            nonce: targetSearchNonce,
                                            entity: entity,
                                            q: trimmed,
                                        });

                                        fetch(adminAjaxUrl + '?' + params.toString(), { credentials: 'same-origin' })
                                            .then((r) => r.json())
                                            .then((payload) => {
                                                const rows = Array.isArray(payload && payload.data) ? payload.data : [];
                                                if (!rows.length) {
                                                    output.innerHTML = '<div class="description"><?php echo esc_js(__('Inga träffar.', 'nv-commerce-core')); ?></div>';
                                                    return;
                                                }

                                                output.innerHTML = rows.map((row) => {
                                                    const id = asInt(row.id, 0);
                                                    const label = String(row.label || '').trim();
                                                    if (!id || !label) {
                                                        return '';
                                                    }
                                                    return '<div class="nvcc-target-result"><span>' + escHtml(label) + '</span><button type="button" class="button button-small" data-add-target="1" data-campaign-index="' + campaignIndex + '" data-target-entity="' + entity + '" data-target-id="' + id + '" data-target-label="' + escHtml(label) + '"><?php echo esc_js(__('Lägg till', 'nv-commerce-core')); ?></button></div>';
                                                }).join('');
                                            })
                                            .catch(() => {
                                                output.innerHTML = '<div class="description"><?php echo esc_js(__('Sökningen misslyckades.', 'nv-commerce-core')); ?></div>';
                                            });
                                    };

                                    addBundleBtn.addEventListener('click', () => {
                                        bundleDeals.push(normalizeDeal({}, bundleDeals.length));
                                        openBundleDeals.add(String(bundleDeals.length - 1));
                                        renderBundleDeals();
                                    });

                                    bundleList.addEventListener('click', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLElement)) {
                                            return;
                                        }
                                        const action = target.getAttribute('data-bundle-action');
                                        const index = asInt(target.getAttribute('data-bundle-index'), -1);
                                        if (index < 0 || index >= bundleDeals.length) {
                                            return;
                                        }

                                        if (action === 'duplicate') {
                                            const copy = normalizeDeal(bundleDeals[index], bundleDeals.length);
                                            bundleDeals.splice(index + 1, 0, copy);
                                            openBundleDeals.add(String(index + 1));
                                            renderBundleDeals();
                                        }
                                        if (action === 'remove') {
                                            bundleDeals.splice(index, 1);
                                            if (!bundleDeals.length) {
                                                bundleDeals.push(normalizeDeal({}, 0));
                                            }
                                            renderBundleDeals();
                                        }
                                    });

                                    const updateBundleField = (el, isCheckbox) => {
                                        const index = asInt(el.getAttribute('data-bundle-index'), -1);
                                        const field = el.getAttribute('data-bundle-field') || '';
                                        if (index < 0 || index >= bundleDeals.length || !field) {
                                            return;
                                        }

                                        let value = isCheckbox ? (el.checked ? 'yes' : 'no') : el.value;
                                        if (field === 'qty') {
                                            value = Math.max(1, asInt(value, 1));
                                        } else if (field === 'discount_value') {
                                            value = String(value).trim();
                                            bundleDeals[index].discount = (bundleDeals[index].discount_mode === 'percentage') ? value : '';
                                        } else if (field === 'discount_mode') {
                                            value = normalizeDiscountMode(value);
                                            if (value !== 'percentage') {
                                                bundleDeals[index].discount = '';
                                            } else {
                                                bundleDeals[index].discount = String(bundleDeals[index].discount_value || '').trim();
                                            }
                                        }
                                        bundleDeals[index][field] = value;
                                        if (field === 'title') {
                                            const titleNode = bundleList.querySelector('[data-bundle-title="' + index + '"]');
                                            if (titleNode) {
                                                titleNode.textContent = String(value || ('Deal ' + (index + 1)));
                                            }
                                        }
                                        serialize();
                                    };

                                    bundleList.addEventListener('input', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement)) {
                                            return;
                                        }
                                        if (!target.hasAttribute('data-bundle-field')) {
                                            return;
                                        }
                                        if (target instanceof HTMLInputElement && target.type === 'checkbox') {
                                            return;
                                        }
                                        updateBundleField(target, false);
                                    });

                                    bundleList.addEventListener('change', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement)) {
                                            return;
                                        }
                                        if (!target.hasAttribute('data-bundle-field')) {
                                            return;
                                        }
                                        updateBundleField(target, target instanceof HTMLInputElement && target.type === 'checkbox');
                                    });

                                    addCampaignBtn.addEventListener('click', () => {
                                        const campaign = normalizeCampaign({}, campaigns.length);
                                        campaigns.push(campaign);
                                        openCampaigns.add(String(campaign.id));
                                        renderCampaigns();
                                    });

                                    campaignList.addEventListener('click', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLElement)) {
                                            return;
                                        }

                                        if (target.hasAttribute('data-add-target')) {
                                            const index = asInt(target.getAttribute('data-campaign-index'), -1);
                                            const entity = String(target.getAttribute('data-target-entity') || '');
                                            const id = asInt(target.getAttribute('data-target-id'), 0);
                                            const label = String(target.getAttribute('data-target-label') || '').trim();
                                            const key = entity + '_ids';
                                            const labelKey = entity + '_labels';
                                            if (index < 0 || index >= campaigns.length || !entity || !id || !Array.isArray(campaigns[index][key])) {
                                                return;
                                            }
                                            if (!campaigns[index][labelKey] || typeof campaigns[index][labelKey] !== 'object') {
                                                campaigns[index][labelKey] = {};
                                            }
                                            if (!campaigns[index][key].includes(id)) {
                                                campaigns[index][key].push(id);
                                            }
                                            if (label !== '') {
                                                campaigns[index][labelKey][String(id)] = label;
                                            }
                                            renderCampaigns();
                                            return;
                                        }

                                        if (target.hasAttribute('data-remove-target')) {
                                            const index = asInt(target.getAttribute('data-campaign-index'), -1);
                                            const entity = String(target.getAttribute('data-target-entity') || '');
                                            const id = asInt(target.getAttribute('data-target-id'), 0);
                                            const key = entity + '_ids';
                                            const labelKey = entity + '_labels';
                                            if (index < 0 || index >= campaigns.length || !entity || !id || !Array.isArray(campaigns[index][key])) {
                                                return;
                                            }
                                            campaigns[index][key] = campaigns[index][key].filter((item) => item !== id);
                                            if (campaigns[index][labelKey] && typeof campaigns[index][labelKey] === 'object') {
                                                delete campaigns[index][labelKey][String(id)];
                                            }
                                            renderCampaigns();
                                            return;
                                        }

                                        if (target.hasAttribute('data-deal-action')) {
                                            const dealAction = String(target.getAttribute('data-deal-action') || '');
                                            const index = asInt(target.getAttribute('data-campaign-index'), -1);
                                            if (index < 0 || index >= campaigns.length) {
                                                return;
                                            }

                                            if (!Array.isArray(campaigns[index].deals)) {
                                                campaigns[index].deals = [normalizeDeal({}, 0)];
                                            }

                                            if (dealAction === 'add') {
                                                campaigns[index].deals.push(normalizeDeal({}, campaigns[index].deals.length));
                                                openCampaignDeals.add(String(campaigns[index].id || index) + ':' + (campaigns[index].deals.length - 1));
                                                clampCampaignIndices(campaigns[index]);
                                                renderCampaigns();
                                                return;
                                            }

                                            const dealIndex = asInt(target.getAttribute('data-campaign-deal-index'), -1);
                                            if (dealIndex < 0 || dealIndex >= campaigns[index].deals.length) {
                                                return;
                                            }

                                            if (dealAction === 'duplicate') {
                                                const copy = normalizeDeal(campaigns[index].deals[dealIndex], campaigns[index].deals.length);
                                                campaigns[index].deals.splice(dealIndex + 1, 0, copy);
                                                openCampaignDeals.add(String(campaigns[index].id || index) + ':' + (dealIndex + 1));
                                                clampCampaignIndices(campaigns[index]);
                                                renderCampaigns();
                                                return;
                                            }

                                            if (dealAction === 'remove') {
                                                campaigns[index].deals.splice(dealIndex, 1);
                                                if (!campaigns[index].deals.length) {
                                                    campaigns[index].deals.push(normalizeDeal({}, 0));
                                                }
                                                clampCampaignIndices(campaigns[index]);
                                                renderCampaigns();
                                            }
                                            return;
                                        }

                                        const action = target.getAttribute('data-action');
                                        const index = asInt(target.getAttribute('data-campaign-index'), -1);
                                        if (index < 0 || index >= campaigns.length) {
                                            return;
                                        }

                                        if (action === 'duplicate') {
                                            const copy = normalizeCampaign(campaigns[index], campaigns.length);
                                            copy.id = newId();
                                            copy.name = copy.name + ' (copy)';
                                            campaigns.splice(index + 1, 0, copy);
                                            openCampaigns.add(String(copy.id));
                                            renderCampaigns();
                                        }

                                        if (action === 'remove') {
                                            campaigns.splice(index, 1);
                                            if (!campaigns.length) {
                                                campaigns.push(normalizeCampaign({}, 0));
                                            }
                                            renderCampaigns();
                                        }
                                    });

                                    const updateCampaignField = (element, isCheckbox) => {
                                        const index = asInt(element.getAttribute('data-campaign-index'), -1);
                                        const field = element.getAttribute('data-field') || '';
                                        if (index < 0 || index >= campaigns.length || field === '') {
                                            return;
                                        }

                                        let nextValue = isCheckbox ? (element.checked ? 'yes' : 'no') : element.value;
                                        if (field === 'priority') {
                                            nextValue = Math.max(0, asInt(nextValue, 0));
                                        } else if (field === 'popular_index' || field === 'default_index') {
                                            const maxDeals = Math.max(1, Array.isArray(campaigns[index].deals) ? campaigns[index].deals.length : 1);
                                            nextValue = clamp(asInt(nextValue, 1), 1, maxDeals);
                                        }

                                        campaigns[index][field] = nextValue;
                                        if (field === 'name') {
                                            const titleNode = campaignList.querySelector('[data-campaign-title="' + index + '"]');
                                            if (titleNode) {
                                                titleNode.textContent = String(nextValue || ('Campaign ' + (index + 1)));
                                            }
                                        }
                                        serialize();

                                        if (field === 'target_mode') {
                                            renderCampaigns();
                                        }
                                    };

                                    const updateCampaignDealField = (element, isCheckbox) => {
                                        const index = asInt(element.getAttribute('data-campaign-index'), -1);
                                        const dealIndex = asInt(element.getAttribute('data-campaign-deal-index'), -1);
                                        const field = element.getAttribute('data-deal-field') || '';
                                        if (
                                            index < 0 ||
                                            index >= campaigns.length ||
                                            !Array.isArray(campaigns[index].deals) ||
                                            dealIndex < 0 ||
                                            dealIndex >= campaigns[index].deals.length ||
                                            field === ''
                                        ) {
                                            return;
                                        }

                                        let nextValue = isCheckbox ? (element.checked ? 'yes' : 'no') : element.value;
                                        if (field === 'qty') {
                                            nextValue = Math.max(1, asInt(nextValue, 1));
                                        } else if (field === 'discount_mode') {
                                            nextValue = normalizeDiscountMode(nextValue);
                                        } else if (field === 'discount_value') {
                                            nextValue = String(nextValue).trim();
                                        }

                                        campaigns[index].deals[dealIndex][field] = nextValue;
                                        if (field === 'discount_mode') {
                                            if (nextValue !== 'percentage') {
                                                campaigns[index].deals[dealIndex].discount = '';
                                            } else {
                                                campaigns[index].deals[dealIndex].discount = String(campaigns[index].deals[dealIndex].discount_value || '').trim();
                                            }
                                        }
                                        if (field === 'discount_value' && campaigns[index].deals[dealIndex].discount_mode === 'percentage') {
                                            campaigns[index].deals[dealIndex].discount = String(nextValue).trim();
                                        }
                                        if (field === 'title') {
                                            const titleNode = campaignList.querySelector('[data-campaign-deal-title="' + index + '-' + dealIndex + '"]');
                                            if (titleNode) {
                                                titleNode.textContent = String(nextValue || ('Deal ' + (dealIndex + 1)));
                                            }
                                        }

                                        serialize();
                                    };

                                    campaignList.addEventListener('input', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement)) {
                                            return;
                                        }

                                        if (target.hasAttribute('data-target-search')) {
                                            const index = asInt(target.getAttribute('data-campaign-index'), -1);
                                            const entity = String(target.getAttribute('data-target-entity') || '');
                                            const results = campaignList.querySelector('[data-target-results="1"][data-campaign-index="' + index + '"][data-target-entity="' + entity + '"]');
                                            if (!(results instanceof HTMLElement)) {
                                                return;
                                            }
                                            requestTargetSearch(index, entity, target.value, results);
                                            return;
                                        }

                                        if (!target.hasAttribute('data-field')) {
                                            if (!target.hasAttribute('data-deal-field')) {
                                                return;
                                            }
                                            if (target instanceof HTMLInputElement && target.type === 'checkbox') {
                                                return;
                                            }
                                            updateCampaignDealField(target, false);
                                            return;
                                        }
                                        if (target instanceof HTMLInputElement && target.type === 'checkbox') {
                                            return;
                                        }
                                        updateCampaignField(target, false);
                                    });

                                    campaignList.addEventListener('change', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement)) {
                                            return;
                                        }
                                        if (!target.hasAttribute('data-field')) {
                                            if (!target.hasAttribute('data-deal-field')) {
                                                return;
                                            }
                                            updateCampaignDealField(target, target instanceof HTMLInputElement && target.type === 'checkbox');
                                            return;
                                        }
                                        updateCampaignField(target, target instanceof HTMLInputElement && target.type === 'checkbox');
                                    });

                                    bundleList.addEventListener('toggle', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLDetailsElement) || !target.classList.contains('nvcc-bundle-deal-card')) {
                                            return;
                                        }

                                        const key = String(target.getAttribute('data-bundle-index') || '');
                                        if (!key) {
                                            return;
                                        }
                                        if (target.open) {
                                            openBundleDeals.add(key);
                                        } else {
                                            openBundleDeals.delete(key);
                                        }
                                    }, true);

                                    campaignList.addEventListener('toggle', (event) => {
                                        const target = event.target;
                                        if (!(target instanceof HTMLDetailsElement)) {
                                            return;
                                        }

                                        if (target.classList.contains('nvcc-campaign-card')) {
                                            const key = String(target.getAttribute('data-campaign-key') || '');
                                            if (!key) {
                                                return;
                                            }
                                            if (target.open) {
                                                openCampaigns.add(key);
                                            } else {
                                                openCampaigns.delete(key);
                                            }
                                            return;
                                        }

                                        if (target.classList.contains('nvcc-campaign-deal-card')) {
                                            const key = String(target.getAttribute('data-campaign-deal-key') || '');
                                            if (!key) {
                                                return;
                                            }
                                            if (target.open) {
                                                openCampaignDeals.add(key);
                                            } else {
                                                openCampaignDeals.delete(key);
                                            }
                                        }
                                    }, true);

                                    renderBundleDeals();
                                    renderCampaigns();
                                })();
                            </script>

                </form>

                <script>
                (function() {
                    var tabs = document.querySelectorAll('[data-nvcc-tab]');
                    var panels = document.querySelectorAll('[data-nvcc-panel]');

                    tabs.forEach(function(tab) {
                        tab.addEventListener('click', function() {
                            var target = this.getAttribute('data-nvcc-tab');
                            tabs.forEach(function(t) { t.classList.remove('is-active'); });
                            panels.forEach(function(p) { p.classList.remove('is-active'); });
                            this.classList.add('is-active');
                            var panel = document.querySelector('[data-nvcc-panel="' + target + '"]');
                            if (panel) { panel.classList.add('is-active'); }
                        });
                    });

                    document.querySelectorAll('[data-nvcc-goto]').forEach(function(link) {
                        link.addEventListener('click', function(e) {
                            e.preventDefault();
                            var target = this.getAttribute('data-nvcc-goto');
                            var tab = document.querySelector('[data-nvcc-tab="' + target + '"]');
                            if (tab) { tab.click(); }
                        });
                    });

                    document.querySelectorAll('[data-nvcc-module-toggle]').forEach(function(toggle) {
                        toggle.addEventListener('change', function() {
                            var card = this.closest('.nvcc-admin-module-card');
                            if (card) {
                                if (this.checked) { card.classList.add('is-active'); }
                                else { card.classList.remove('is-active'); }
                            }
                        });
                    });
                })();
                </script>

                <script>
                (function() {
                    var wrap = document.querySelector('.nvcc-admin-wrap');
                    if (!wrap) { return; }

                    /* ---- Light / dark theme toggle (persisted per browser) ---- */
                    var STORAGE_KEY = 'nvccAdminTheme';
                    var toggle = document.getElementById('nvcc-theme-toggle');
                    var MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg>';
                    var SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
                    function applyTheme(mode) {
                        wrap.setAttribute('data-nvcc-theme', mode);
                        document.body.classList.toggle('nvcc-admin-dark', mode === 'dark');
                        if (toggle) { toggle.innerHTML = (mode === 'dark') ? SUN : MOON; }
                    }
                    var saved = 'light';
                    try { saved = window.localStorage.getItem(STORAGE_KEY) || 'light'; } catch (e) {}
                    applyTheme(saved === 'dark' ? 'dark' : 'light');
                    if (toggle) {
                        toggle.addEventListener('click', function() {
                            var next = (wrap.getAttribute('data-nvcc-theme') === 'dark') ? 'light' : 'dark';
                            applyTheme(next);
                            try { window.localStorage.setItem(STORAGE_KEY, next); } catch (e) {}
                        });
                    }

                    /* ---- Unsaved-changes detection -> enable Save only when dirty ---- */
                    var form = document.getElementById('nvcc-settings-form');
                    var saveButtons = [document.getElementById('nvcc-save-top'), document.getElementById('nvcc-save-bottom')];
                    var status = document.getElementById('nvcc-save-status');
                    if (!form) { return; }

                    var dirty = false;
                    var submitting = false;

                    function setButtons(enabled) {
                        saveButtons.forEach(function(btn) {
                            if (!btn) { return; }
                            btn.disabled = !enabled;
                            btn.setAttribute('aria-disabled', enabled ? 'false' : 'true');
                        });
                    }
                    function markDirty() {
                        if (dirty) { return; }
                        dirty = true;
                        setButtons(true);
                        if (status) {
                            var msg = status.getAttribute('data-dirty') || 'You have unsaved changes';
                            status.innerHTML = '<span class="nvcc-admin-dirty-dot" aria-hidden="true"></span>' + msg;
                        }
                    }

                    setButtons(false);

                    form.addEventListener('input', markDirty);
                    form.addEventListener('change', markDirty);
                    /* Structural edits in the campaign / deal builders use type=button controls
                       that mutate hidden JSON fields without firing input/change. */
                    form.addEventListener('click', function(event) {
                        var btn = event.target.closest('button');
                        if (!btn || btn.type === 'submit') { return; }
                        markDirty();
                    });

                    form.addEventListener('submit', function() {
                        submitting = true;
                        dirty = false;
                    });

                    window.addEventListener('beforeunload', function(event) {
                        if (dirty && !submitting) {
                            event.preventDefault();
                            event.returnValue = '';
                            return '';
                        }
                    });
                })();
                </script>

            </div><!-- .nvcc-admin-content -->

        </div><!-- .nvcc-admin-wrap -->
        <?php
    }

    public function register_product_meta_box(): void {
        add_meta_box(
            'nvcc_product_meta',
            __('NV Commerce Core - Produktinställningar', 'nv-commerce-core'),
            [$this, 'render_product_meta_box'],
            'product',
            'normal',
            'default'
        );
    }

    public function render_product_meta_box(WP_Post $post): void {
        wp_nonce_field('nvcc_product_meta_nonce_action', 'nvcc_product_meta_nonce');

        $bulk_mode = (string) get_post_meta($post->ID, '_nvcc_bulk_mode', true);
        if ($bulk_mode === '') {
            $bulk_mode = 'inherit';
        }

        $bundle_mode = (string) get_post_meta($post->ID, '_nvcc_bundle_mode', true);
        if ($bundle_mode === '') {
            $bundle_mode = 'inherit';
        }
        $legacy_deals_mode = sanitize_key((string) get_post_meta($post->ID, '_nvcc_legacy_deals_enabled', true));
        if (!in_array($legacy_deals_mode, ['auto', 'yes', 'no'], true)) {
            $legacy_deals_mode = 'auto';
        }
        $legacy_deals_effective = $this->is_legacy_product_deals_enabled((int) $post->ID);

        $bulk_override = (string) get_post_meta($post->ID, '_nvcc_bulk_override', true) === 'yes' ? 'yes' : 'no';
        $tier2 = (string) get_post_meta($post->ID, '_nvcc_tier_2_pct', true);
        $tier3 = (string) get_post_meta($post->ID, '_nvcc_tier_3_pct', true);
        $tier4 = (string) get_post_meta($post->ID, '_nvcc_tier_4_pct', true);
        $bundle_deals_json = (string) get_post_meta($post->ID, '_nvcc_bundle_deals_json', true);

        $benefits = (string) get_post_meta($post->ID, '_nv_pdp_benefits', true);
        $trust = (string) get_post_meta($post->ID, '_nv_pdp_trust_badges', true);
        $faq = (string) get_post_meta($post->ID, '_nv_pdp_faq_items', true);
        $story_blocks = get_post_meta($post->ID, '_nv_pdp_story_blocks', true);
        if (is_array($story_blocks)) {
            $story_blocks = wp_json_encode($story_blocks, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        }
        ?>
        <p><strong><?php esc_html_e('Volymrabatt', 'nv-commerce-core'); ?></strong></p>
        <p>
            <label><?php esc_html_e('Bulk mode', 'nv-commerce-core'); ?></label>
            <select name="nvcc_bulk_mode">
                <option value="inherit" <?php selected($bulk_mode, 'inherit'); ?>><?php esc_html_e('Ärv global', 'nv-commerce-core'); ?></option>
                <option value="yes" <?php selected($bulk_mode, 'yes'); ?>><?php esc_html_e('Aktivera', 'nv-commerce-core'); ?></option>
                <option value="no" <?php selected($bulk_mode, 'no'); ?>><?php esc_html_e('Inaktivera', 'nv-commerce-core'); ?></option>
            </select>
        </p>
        <p><small><?php esc_html_e('Huvudflödet är globala Offer Campaigns. Öppna avancerade överskrivningar endast vid undantag per produkt.', 'nv-commerce-core'); ?></small></p>
        <details style="margin:8px 0 12px;">
            <summary style="cursor:pointer;font-weight:600;"><?php esc_html_e('Avancerade bulk-överskrivningar (valfritt)', 'nv-commerce-core'); ?></summary>
            <p>
                <label><input type="checkbox" name="nvcc_bulk_override" value="yes" <?php checked($bulk_override, 'yes'); ?> /> <?php esc_html_e('Överskriv rabattprocent för denna produkt', 'nv-commerce-core'); ?></label>
            </p>
            <p>
                <label><?php esc_html_e('Nivå 1 (%)', 'nv-commerce-core'); ?></label>
                <input type="number" step="0.1" min="0" name="nvcc_tier_2_pct" value="<?php echo esc_attr($tier2); ?>" />
                <label><?php esc_html_e('Nivå 2 (%)', 'nv-commerce-core'); ?></label>
                <input type="number" step="0.1" min="0" name="nvcc_tier_3_pct" value="<?php echo esc_attr($tier3); ?>" />
                <label><?php esc_html_e('Nivå 3 (%)', 'nv-commerce-core'); ?></label>
                <input type="number" step="0.1" min="0" name="nvcc_tier_4_pct" value="<?php echo esc_attr($tier4); ?>" />
            </p>
        </details>

        <hr />

        <p><strong><?php esc_html_e('Variation-mix bundle', 'nv-commerce-core'); ?></strong></p>
        <p>
            <label><?php esc_html_e('Bundle mode', 'nv-commerce-core'); ?></label>
            <select name="nvcc_bundle_mode">
                <option value="inherit" <?php selected($bundle_mode, 'inherit'); ?>><?php esc_html_e('Ärv global', 'nv-commerce-core'); ?></option>
                <option value="yes" <?php selected($bundle_mode, 'yes'); ?>><?php esc_html_e('Aktivera', 'nv-commerce-core'); ?></option>
                <option value="no" <?php selected($bundle_mode, 'no'); ?>><?php esc_html_e('Inaktivera', 'nv-commerce-core'); ?></option>
            </select>
        </p>
        <details style="margin:8px 0 12px;">
            <summary style="cursor:pointer;font-weight:600;"><?php esc_html_e('Avancerade bundle-överskrivningar (legacy, valfritt)', 'nv-commerce-core'); ?></summary>
        <p>
            <label><?php esc_html_e('Legacy deal-override för denna produkt', 'nv-commerce-core'); ?></label>
            <select name="nvcc_legacy_deals_enabled">
                <option value="auto" <?php selected($legacy_deals_mode, 'auto'); ?>><?php esc_html_e('Auto (aktiveras om legacy-data finns)', 'nv-commerce-core'); ?></option>
                <option value="yes" <?php selected($legacy_deals_mode, 'yes'); ?>><?php esc_html_e('Aktivera legacy-fält', 'nv-commerce-core'); ?></option>
                <option value="no" <?php selected($legacy_deals_mode, 'no'); ?>><?php esc_html_e('Inaktivera legacy-fält', 'nv-commerce-core'); ?></option>
            </select>
            <br /><small><?php echo esc_html($legacy_deals_effective ? __('Nu: Legacy aktiv', 'nv-commerce-core') : __('Nu: Legacy avstängd', 'nv-commerce-core')); ?></small>
        </p>
        <?php
        // Per-product deal fields
        $deal_fields = [];
        for ($n = 1; $n <= 3; $n++) {
            $deal_fields[$n] = [
                'qty'      => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_qty', true),
                'title'    => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_title', true),
                'subtitle' => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_subtitle', true),
                'badge'    => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_badge', true),
                'label'    => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_label', true),
                'discount' => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_discount', true),
                'popular'  => get_post_meta($post->ID, '_nvcc_deal_' . $n . '_popular', true),
                'default'  => get_post_meta($post->ID, '_nvcc_deal_' . $n . '_default', true),
                'bonus_label' => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_bonus_label', true),
                'bonus_selectors' => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_bonus_selectors', true),
                'bonus_titles' => (string) get_post_meta($post->ID, '_nvcc_deal_' . $n . '_bonus_titles', true),
            ];
        }
        $bundle_headline = (string) get_post_meta($post->ID, '_nvcc_bundle_headline', true);
        ?>
        <details<?php echo $legacy_deals_effective ? ' open' : ''; ?> style="margin:10px 0 12px;">
            <summary style="cursor:pointer;font-weight:600;"><?php esc_html_e('Legacy deal-inställningar (valfritt)', 'nv-commerce-core'); ?></summary>
            <p><small><?php esc_html_e('Tomma fält ärver de globala inställningarna. Fyll endast i dessa om du behöver produktspecifika legacy-undantag.', 'nv-commerce-core'); ?></small></p>
        <table style="width:100%;border-collapse:collapse;margin-bottom:8px;">
            <thead>
                <tr style="background:#f0f0f0;">
                    <th style="padding:6px 8px;text-align:left;font-weight:600;"><?php esc_html_e('', 'nv-commerce-core'); ?></th>
                    <th style="padding:6px 8px;text-align:left;font-weight:600;"><?php esc_html_e('Deal 1', 'nv-commerce-core'); ?></th>
                    <th style="padding:6px 8px;text-align:left;font-weight:600;"><?php esc_html_e('Deal 2', 'nv-commerce-core'); ?></th>
                    <th style="padding:6px 8px;text-align:left;font-weight:600;"><?php esc_html_e('Deal 3', 'nv-commerce-core'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Antal (qty)', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="number" min="1" step="1" name="nvcc_deal_<?php echo $n; ?>_qty"
                               value="<?php echo esc_attr($deal_fields[$n]['qty']); ?>"
                               placeholder="<?php echo esc_attr((string) $n); ?>"
                               style="width:70px;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Titel', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="text" name="nvcc_deal_<?php echo $n; ?>_title"
                               value="<?php echo esc_attr($deal_fields[$n]['title']); ?>"
                               placeholder="t.ex. Bas / Duo / Familjepaket"
                               style="width:100%;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Undertext', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="text" name="nvcc_deal_<?php echo $n; ?>_subtitle"
                               value="<?php echo esc_attr($deal_fields[$n]['subtitle']); ?>"
                               placeholder="t.ex. Spara {pct}%"
                               style="width:100%;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Badge', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="text" name="nvcc_deal_<?php echo $n; ?>_badge"
                               value="<?php echo esc_attr($deal_fields[$n]['badge']); ?>"
                               placeholder="t.ex. POPULÄRT VAL"
                               style="width:100%;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Etikett', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="text" name="nvcc_deal_<?php echo $n; ?>_label"
                               value="<?php echo esc_attr($deal_fields[$n]['label']); ?>"
                               placeholder="t.ex. Fri frakt"
                               style="width:100%;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Bonus-rubrik (valfritt)', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="text" name="nvcc_deal_<?php echo $n; ?>_bonus_label"
                               value="<?php echo esc_attr($deal_fields[$n]['bonus_label']); ?>"
                               placeholder="t.ex. Gratis e-böcker inkluderade:"
                               style="width:100%;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Bonus korta titlar', 'nv-commerce-core'); ?><br /><small><?php esc_html_e('En rad per bonusprodukt (samma ordning som selectors)', 'nv-commerce-core'); ?></small></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <textarea name="nvcc_deal_<?php echo $n; ?>_bonus_titles"
                                  rows="4"
                                  placeholder="Kort titel 1&#10;Kort titel 2"
                                  style="width:100%;"><?php echo esc_textarea($deal_fields[$n]['bonus_titles']); ?></textarea>
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Bonus selectors', 'nv-commerce-core'); ?><br /><small><?php esc_html_e('id:17248 eller slug:hygienguide', 'nv-commerce-core'); ?></small></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <textarea name="nvcc_deal_<?php echo $n; ?>_bonus_selectors"
                                  rows="4"
                                  placeholder="slug:hygienguide&#10;id:17248"
                                  style="width:100%;"><?php echo esc_textarea($deal_fields[$n]['bonus_selectors']); ?></textarea>
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Rabatt % (explicit)', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <input type="number" min="0" max="100" step="0.1" name="nvcc_deal_<?php echo $n; ?>_discount"
                               value="<?php echo esc_attr($deal_fields[$n]['discount']); ?>"
                               placeholder="auto"
                               style="width:70px;" />
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Populär', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <select name="nvcc_deal_<?php echo $n; ?>_popular">
                            <option value="" <?php selected($deal_fields[$n]['popular'], ''); ?>><?php esc_html_e('– ärv –', 'nv-commerce-core'); ?></option>
                            <option value="yes" <?php selected($deal_fields[$n]['popular'], 'yes'); ?>><?php esc_html_e('Ja', 'nv-commerce-core'); ?></option>
                            <option value="no" <?php selected($deal_fields[$n]['popular'], 'no'); ?>><?php esc_html_e('Nej', 'nv-commerce-core'); ?></option>
                        </select>
                    </td>
                    <?php endfor; ?>
                </tr>
                <tr>
                    <td style="padding:5px 8px;font-weight:500;"><?php esc_html_e('Standard (förvald)', 'nv-commerce-core'); ?></td>
                    <?php for ($n = 1; $n <= 3; $n++) : ?>
                    <td style="padding:5px 8px;">
                        <select name="nvcc_deal_<?php echo $n; ?>_default">
                            <option value="" <?php selected($deal_fields[$n]['default'], ''); ?>><?php esc_html_e('– ärv –', 'nv-commerce-core'); ?></option>
                            <option value="yes" <?php selected($deal_fields[$n]['default'], 'yes'); ?>><?php esc_html_e('Ja', 'nv-commerce-core'); ?></option>
                            <option value="no" <?php selected($deal_fields[$n]['default'], 'no'); ?>><?php esc_html_e('Nej', 'nv-commerce-core'); ?></option>
                        </select>
                    </td>
                    <?php endfor; ?>
                </tr>
            </tbody>
        </table>
        <p><small><?php esc_html_e('Bonus selectors är produktspecifika. Om de lämnas tomma används globala tier-selectors från NV Commerce Core (med legacy-läsning från NV Order Bonuses under övergångsperioden).', 'nv-commerce-core'); ?></small></p>
        <p>
            <label for="nvcc_bundle_headline"><strong><?php esc_html_e('Rubrik för bundle-widget (valfritt)', 'nv-commerce-core'); ?></strong></label><br />
            <input type="text" id="nvcc_bundle_headline" name="nvcc_bundle_headline"
                   value="<?php echo esc_attr($bundle_headline); ?>"
                   placeholder="t.ex. Köp fler, spara mer — {needed} till för {pct}% rabatt"
                   style="width:100%;" />
        </p>
        <p>
            <label for="nvcc_bundle_deals_json"><strong><?php esc_html_e('Produktspecifik deal JSON (avancerat, valfritt — åsidosätter allt ovan)', 'nv-commerce-core'); ?></strong></label><br />
            <textarea id="nvcc_bundle_deals_json" name="nvcc_bundle_deals_json" rows="5" style="width:100%;"><?php echo esc_textarea($bundle_deals_json); ?></textarea>
            <small>
                <?php esc_html_e('Format: [{"qty":2,"title":"Duo","subtitle":"Spara {pct}%","badge":"Mest populär","label":"Fri frakt","default":true}]', 'nv-commerce-core'); ?>
            </small>
        </p>
        </details>
        </details>

        <hr />

        <details style="margin:8px 0 0;">
            <summary style="cursor:pointer;font-weight:600;"><?php esc_html_e('PDP innehållsöverskrivningar (legacy, valfritt)', 'nv-commerce-core'); ?></summary>
            <p><small><?php esc_html_e('Behålls för bakåtkompatibilitet. Om du bygger via Elementor-widgets kan dessa fält lämnas tomma.', 'nv-commerce-core'); ?></small></p>
        <p>
            <label for="nv_pdp_benefits"><strong><?php esc_html_e('Fördelar (en rad per punkt)', 'nv-commerce-core'); ?></strong></label><br />
            <textarea id="nv_pdp_benefits" name="nv_pdp_benefits" rows="5" style="width:100%;"><?php echo esc_textarea($benefits); ?></textarea>
        </p>
        <p>
            <label for="nv_pdp_trust_badges"><strong><?php esc_html_e('Trust badges (en rad per badge)', 'nv-commerce-core'); ?></strong></label><br />
            <textarea id="nv_pdp_trust_badges" name="nv_pdp_trust_badges" rows="4" style="width:100%;"><?php echo esc_textarea($trust); ?></textarea>
        </p>
        <p>
            <label for="nv_pdp_faq_items"><strong><?php esc_html_e('FAQ (format: Fråga::Svar, en rad per FAQ)', 'nv-commerce-core'); ?></strong></label><br />
            <textarea id="nv_pdp_faq_items" name="nv_pdp_faq_items" rows="6" style="width:100%;"><?php echo esc_textarea($faq); ?></textarea>
        </p>
        <p>
            <label for="nv_pdp_story_blocks"><strong><?php esc_html_e('Story blocks JSON (valfritt)', 'nv-commerce-core'); ?></strong></label><br />
            <textarea id="nv_pdp_story_blocks" name="nv_pdp_story_blocks" rows="8" style="width:100%;"><?php echo esc_textarea((string) $story_blocks); ?></textarea>
        </p>
        </details>
        <?php
    }

    public function save_product_meta(int $post_id): void {
        if (!isset($_POST['nvcc_product_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash((string) $_POST['nvcc_product_meta_nonce'])), 'nvcc_product_meta_nonce_action')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_product', $post_id)) {
            return;
        }

        $bulk_mode = isset($_POST['nvcc_bulk_mode']) ? sanitize_key((string) wp_unslash((string) $_POST['nvcc_bulk_mode'])) : 'inherit';
        if (!in_array($bulk_mode, ['inherit', 'yes', 'no'], true)) {
            $bulk_mode = 'inherit';
        }
        update_post_meta($post_id, '_nvcc_bulk_mode', $bulk_mode);

        $bundle_mode = isset($_POST['nvcc_bundle_mode']) ? sanitize_key((string) wp_unslash((string) $_POST['nvcc_bundle_mode'])) : 'inherit';
        if (!in_array($bundle_mode, ['inherit', 'yes', 'no'], true)) {
            $bundle_mode = 'inherit';
        }
        update_post_meta($post_id, '_nvcc_bundle_mode', $bundle_mode);

        $legacy_deals_mode = isset($_POST['nvcc_legacy_deals_enabled']) ? sanitize_key((string) wp_unslash((string) $_POST['nvcc_legacy_deals_enabled'])) : 'auto';
        if (!in_array($legacy_deals_mode, ['auto', 'yes', 'no'], true)) {
            $legacy_deals_mode = 'auto';
        }
        update_post_meta($post_id, '_nvcc_legacy_deals_enabled', $legacy_deals_mode);

        $bulk_override = (!empty($_POST['nvcc_bulk_override']) && $_POST['nvcc_bulk_override'] === 'yes') ? 'yes' : 'no';
        update_post_meta($post_id, '_nvcc_bulk_override', $bulk_override);

        foreach (['_nvcc_tier_2_pct' => 'nvcc_tier_2_pct', '_nvcc_tier_3_pct' => 'nvcc_tier_3_pct', '_nvcc_tier_4_pct' => 'nvcc_tier_4_pct'] as $meta_key => $field_name) {
            $value = isset($_POST[$field_name]) ? (float) wp_unslash((string) $_POST[$field_name]) : '';
            if ($value === '') {
                delete_post_meta($post_id, $meta_key);
            } else {
                update_post_meta($post_id, $meta_key, max(0, $value));
            }
        }

        /* Per-product bundle headline */
        if (isset($_POST['nvcc_bundle_headline'])) {
            $val = sanitize_text_field((string) wp_unslash((string) $_POST['nvcc_bundle_headline']));
            if ($val === '') {
                delete_post_meta($post_id, '_nvcc_bundle_headline');
            } else {
                update_post_meta($post_id, '_nvcc_bundle_headline', $val);
            }
        }

        /* Per-product deal fields: qty, title, subtitle, badge, label, discount%, popular, default */
        foreach ([1, 2, 3] as $deal_num) {
            $prefix = 'nvcc_deal_' . $deal_num . '_';
            $meta_prefix = '_nvcc_deal_' . $deal_num . '_';

            // Qty
            $qty_raw = isset($_POST[$prefix . 'qty']) ? absint((string) wp_unslash((string) $_POST[$prefix . 'qty'])) : 0;
            if ($qty_raw <= 0) {
                delete_post_meta($post_id, $meta_prefix . 'qty');
            } else {
                update_post_meta($post_id, $meta_prefix . 'qty', $qty_raw);
            }

            // Text fields: title, subtitle, badge, label, bonus_label
            foreach (['title', 'subtitle', 'badge', 'label', 'bonus_label'] as $text_field) {
                if (isset($_POST[$prefix . $text_field])) {
                    $val = sanitize_text_field((string) wp_unslash((string) $_POST[$prefix . $text_field]));
                    if ($val === '') {
                        delete_post_meta($post_id, $meta_prefix . $text_field);
                    } else {
                        update_post_meta($post_id, $meta_prefix . $text_field, $val);
                    }
                }
            }

            // Bonus selectors textarea (id:, slug:, sku: — one per line)
            if (isset($_POST[$prefix . 'bonus_selectors'])) {
                $selectors_raw = sanitize_textarea_field((string) wp_unslash((string) $_POST[$prefix . 'bonus_selectors']));
                $selectors_raw = trim($selectors_raw);
                if ($selectors_raw === '') {
                    delete_post_meta($post_id, $meta_prefix . 'bonus_selectors');
                } else {
                    update_post_meta($post_id, $meta_prefix . 'bonus_selectors', $selectors_raw);
                }
            }

            // Bonus short titles textarea (one title per line, matched by selector order)
            if (isset($_POST[$prefix . 'bonus_titles'])) {
                $titles_raw = sanitize_textarea_field((string) wp_unslash((string) $_POST[$prefix . 'bonus_titles']));
                $titles_raw = trim($titles_raw);
                if ($titles_raw === '') {
                    delete_post_meta($post_id, $meta_prefix . 'bonus_titles');
                } else {
                    update_post_meta($post_id, $meta_prefix . 'bonus_titles', $titles_raw);
                }
            }

            // Explicit discount %
            if (isset($_POST[$prefix . 'discount'])) {
                $disc_raw = trim((string) wp_unslash((string) $_POST[$prefix . 'discount']));
                if ($disc_raw === '') {
                    delete_post_meta($post_id, $meta_prefix . 'discount');
                } else {
                    update_post_meta($post_id, $meta_prefix . 'discount', max(0.0, (float) $disc_raw));
                }
            }

            // Popular flag (yes / no / '' = inherit)
            if (isset($_POST[$prefix . 'popular'])) {
                $pop = sanitize_key((string) wp_unslash((string) $_POST[$prefix . 'popular']));
                if (!in_array($pop, ['yes', 'no'], true)) {
                    delete_post_meta($post_id, $meta_prefix . 'popular');
                } else {
                    update_post_meta($post_id, $meta_prefix . 'popular', $pop);
                }
            }

            // Default selected flag (yes / no / '' = inherit)
            if (isset($_POST[$prefix . 'default'])) {
                $def = sanitize_key((string) wp_unslash((string) $_POST[$prefix . 'default']));
                if (!in_array($def, ['yes', 'no'], true)) {
                    delete_post_meta($post_id, $meta_prefix . 'default');
                } else {
                    update_post_meta($post_id, $meta_prefix . 'default', $def);
                }
            }
        }

        if (isset($_POST['nvcc_bundle_deals_json'])) {
            $raw_bundle_json = trim((string) wp_unslash((string) $_POST['nvcc_bundle_deals_json']));
            if ($raw_bundle_json === '') {
                delete_post_meta($post_id, '_nvcc_bundle_deals_json');
            } else {
                $decoded_bundle_json = json_decode($raw_bundle_json, true);
                if (is_array($decoded_bundle_json)) {
                    update_post_meta($post_id, '_nvcc_bundle_deals_json', wp_json_encode($decoded_bundle_json, JSON_UNESCAPED_UNICODE));
                }
            }
        }

        if (isset($_POST['nv_pdp_benefits'])) {
            update_post_meta($post_id, '_nv_pdp_benefits', sanitize_textarea_field((string) wp_unslash((string) $_POST['nv_pdp_benefits'])));
        }

        if (isset($_POST['nv_pdp_trust_badges'])) {
            update_post_meta($post_id, '_nv_pdp_trust_badges', sanitize_textarea_field((string) wp_unslash((string) $_POST['nv_pdp_trust_badges'])));
        }

        if (isset($_POST['nv_pdp_faq_items'])) {
            update_post_meta($post_id, '_nv_pdp_faq_items', sanitize_textarea_field((string) wp_unslash((string) $_POST['nv_pdp_faq_items'])));
        }

        if (isset($_POST['nv_pdp_story_blocks'])) {
            $raw_json = trim((string) wp_unslash((string) $_POST['nv_pdp_story_blocks']));
            if ($raw_json === '') {
                delete_post_meta($post_id, '_nv_pdp_story_blocks');
            } else {
                $decoded = json_decode($raw_json, true);
                if (is_array($decoded)) {
                    update_post_meta($post_id, '_nv_pdp_story_blocks', wp_json_encode($decoded, JSON_UNESCAPED_UNICODE));
                }
            }
        }
    }
}

$GLOBALS['nvcc_runtime_instance'] = new Nestly_NVCC_Commerce_Core_Runtime();

if (did_action('plugins_loaded')) {
    nvcc_boot_smart_upsell_module_once();
} else {
    add_action('plugins_loaded', 'nvcc_boot_smart_upsell_module_once', 20);
}

$nvcc_boot_nordic_pricing_module = static function (): void {
    $enabled = (bool) apply_filters('nvcc_enable_nordic_pricing_module', true);
    if (!$enabled) {
        return;
    }

    if (class_exists('Nestly_NVCC_Nordic_Pricing_Runtime')) {
        Nestly_NVCC_Nordic_Pricing_Runtime::init();
    }
};

if (did_action('plugins_loaded')) {
    $nvcc_boot_nordic_pricing_module();
} else {
    add_action('plugins_loaded', $nvcc_boot_nordic_pricing_module, 20);
}
